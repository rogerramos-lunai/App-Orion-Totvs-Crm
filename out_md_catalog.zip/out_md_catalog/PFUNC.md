# PFUNC

**Descrição:** Cadastro de Funcionários

## Colunas

### QTDEFILHOS
- **Descrição:** Quantidade de Filhos do Funcionário
- **Sinônimos/variações:** quantidade de filhos, número de filhos, total de filhos, filhos do funcionário, quantos filhos, filhos registrados, contagem de filhos, filhos dependentes, número de dependentes filhos, filhos cadastrados, quantidade de dependentes filhos, filhos informados, filhos oficiais, filhos declarados

### ABONOPERMANENCIA
- **Descrição:** Informa se o Funcionário recebe Abono de permanência de Estatutário - Funcionários
- **Sinônimos/variações:** abono de permanência, recebe abono permanência, abono estatutário, abono para servidor, benefício abono permanência, abono de servidor, abono de permanência ativo, tem abono permanência, abono de permanência funcionário, abono de permanência estatutário, recebimento de abono permanência, abono por tempo de serviço, abono de permanência sim/não, abono de permanência vigente

### ADESAOPDV
- **Descrição:** Indica se o Funionário possui Adesão ao Programa de Demissão (PDV) - Funcionários
- **Sinônimos/variações:** adesão ao pdv, participa do pdv, adesão programa demissão, adesão ao programa de demissão voluntária, participação pdv, funcionário no pdv, adesão demissão voluntária, adesão ao plano de demissão, adesão ao pdv funcionário, adesão ao programa pdv, adesão ao plano demissão voluntária, participa do programa de demissão, adesão pdv sim/não, adesão ao pdv ativo

### AJUDACUSTO
- **Descrição:** Valor da Ajuda de Custo - Funcionários
- **Sinônimos/variações:** ajuda de custo, valor ajuda custo, auxílio custo, valor auxílio custo, ajuda financeira, ajuda de custo funcionário, valor da ajuda de custo, auxílio financeiro, ajuda custo mensal, ajuda de custo paga, valor auxílio financeiro, ajuda custo trabalhista, ajuda custo benefício, ajuda custo recebido

### ANOCOMPTRANSF
- **Descrição:** Ano da Competência durante o processo de Transferência - Funcionários
- **Sinônimos/variações:** ano competência transferência, ano da competência transferência, ano competência transf, ano da competência no processo de transferência, ano da transferência, ano competência processo transferência, ano competência transf funcionário, ano competência transferência funcionário, ano competência transf ativo, ano competência transferência atual, ano competência transferência registrada, ano competência transferência vigente, ano competência transferência processo, ano competência transferência oficial

### ANOSCONTRIBINSS
- **Descrição:** Anos de Contribuição para INSS PPE - Funcionários
- **Sinônimos/variações:** anos contribuição inss, tempo contribuição inss, anos contribuídos inss, anos de contribuição para inss, tempo de contribuição inss, anos inss, tempo inss contribuído, anos contribuição previdência, anos contribuição inss ppe, anos contribuição previdenciária, anos contribuição inss funcionário, anos contribuição inss registrado, anos contribuição inss oficial, anos contribuição inss total

### ANTIGACARTTRAB
- **Descrição:** Antigo número da Carteira de Trabalho - Funcionários
- **Sinônimos/variações:** antigo número carteira trabalho, número antigo carteira trabalho, carteira trabalho antiga, número carteira trabalho antigo, antiga carteira de trabalho, número ctps antigo, carteira trabalho antiga funcionário, número carteira trabalho prévio, carteira trabalho anterior, número ctps anterior, carteira trabalho antiga registrada, número carteira trabalho antigo funcionário, carteira trabalho antiga oficial, número carteira trabalho antigo cadastrado

### ANTIGACHAPA
- **Descrição:** Antigo código da Chapa do Funcionário - Funcionários
- **Sinônimos/variações:** antigo código chapa, código chapa antigo, chapa antiga, código chapa anterior, chapa antiga funcionário, código chapa prévio, chapa antiga registrada, código chapa antigo funcionário, chapa anterior, código chapa antigo cadastrado, chapa antiga oficial, código chapa antigo registrado, chapa antiga do funcionário, código chapa antigo ativo

### ANTIGADTADM
- **Descrição:** Antiga Data de Admissão - Funcionários
- **Sinônimos/variações:** antiga data admissão, data admissão antiga, data antiga de admissão, admissão anterior, data admissão prévia, data admissão antiga funcionário, data admissão registrada antiga, data admissão antiga oficial, data admissão anterior funcionário, data admissão antiga cadastrada, data admissão prévia funcionário, data admissão antiga válida, data admissão antiga registrada, data admissão antiga do funcionário

### ANTIGADTNASCIM
- **Descrição:** Antiga Data de Nascimento - Funcionários
- **Sinônimos/variações:** antiga data nascimento, data nascimento antiga, data antiga de nascimento, nascimento anterior, data nascimento prévia, data nascimento antiga funcionário, data nascimento registrada antiga, data nascimento antiga oficial, data nascimento anterior funcionário, data nascimento antiga cadastrada, data nascimento prévia funcionário, data nascimento antiga válida, data nascimento antiga registrada, data nascimento antiga do funcionário

### ANTIGADTOPCAO
- **Descrição:** Antiga Data de Opção - Funcionários
- **Sinônimos/variações:** antiga data opção, data opção antiga, data antiga de opção, opção anterior, data opção prévia, data opção antiga funcionário, data opção registrada antiga, data opção antiga oficial, data opção anterior funcionário, data opção antiga cadastrada, data opção prévia funcionário, data opção antiga válida, data opção antiga registrada, data opção antiga do funcionário

### ANTIGASECAO
- **Descrição:** Antigo código de Seção - Funcionários
- **Sinônimos/variações:** antigo código seção, código seção antigo, seção antiga, código seção anterior, seção antiga funcionário, código seção prévio, seção antiga registrada, código seção antigo funcionário, seção anterior, código seção antigo cadastrado, seção antiga oficial, código seção antigo registrado, seção antiga do funcionário, código seção antigo ativo

### ANTIGASERIECART
- **Descrição:** Antigo código de Série da Carteira de Trabalho - Funcionários
- **Sinônimos/variações:** antigo código série carteira, código série carteira antigo, série carteira antiga, código série carteira anterior, série carteira antiga funcionário, código série carteira prévio, série carteira antiga registrada, código série carteira antigo funcionário, série carteira anterior, código série carteira antigo cadastrado, série carteira antiga oficial, código série carteira antigo registrado, série carteira antiga do funcionário, código série carteira antigo ativo

### ANTIGOCI
- **Descrição:** Antigo Código de Contribuinte Individual - Funcionários
- **Sinônimos/variações:** antigo código contribuinte individual, código contribuinte individual antigo, contribuinte individual antigo, código ci antigo, contribuinte individual anterior, código contribuinte individual prévio, contribuinte individual antigo funcionário, código contribuinte individual registrado antigo, contribuinte individual antigo cadastrado, código contribuinte individual oficial antigo, contribuinte individual antigo ativo, código ci antigo funcionário, contribuinte individual antigo registrado, código ci antigo cadastrado

### ANTIGONOME
- **Descrição:** Antigo Nome - Funcionários
- **Sinônimos/variações:** antigo nome, nome anterior, nome antigo funcionário, nome prévio, nome registrado antigo, nome oficial antigo, nome cadastrado antigo, nome antigo do funcionário, nome antigo registrado, nome antigo válido, nome antigo cadastrado, nome antigo oficial, nome antigo histórico, nome antigo usado

### ANTIGOPIS
- **Descrição:** Antigo código de PIS - Funcionários
- **Sinônimos/variações:** antigo código pis, código pis antigo, pis antigo, código pis anterior, pis antigo funcionário, código pis prévio, pis antigo registrado, código pis antigo funcionário, pis anterior, código pis antigo cadastrado, pis antigo oficial, código pis antigo registrado, pis antigo do funcionário, código pis antigo ativo

### ANTIGOTIPOADM
- **Descrição:** Antigo código de Tipo de Admissão - Funcionários
- **Sinônimos/variações:** antigo código tipo admissão, código tipo admissão antigo, tipo admissão antigo, código tipo admissão anterior, tipo admissão antigo funcionário, código tipo admissão prévio, tipo admissão antigo registrado, código tipo admissão antigo funcionário, tipo admissão anterior, código tipo admissão antigo cadastrado, tipo admissão antigo oficial, código tipo admissão antigo registrado, tipo admissão antigo do funcionário, código tipo admissão antigo ativo

### ANTIGOTIPOFUNC
- **Descrição:** Antigo código do Tipo de Funcionário - Funcionários
- **Sinônimos/variações:** antigo código tipo funcionário, código tipo funcionário antigo, tipo funcionário antigo, código tipo funcionário anterior, tipo funcionário antigo funcionário, código tipo funcionário prévio, tipo funcionário antigo registrado, código tipo funcionário antigo funcionário, tipo funcionário anterior, código tipo funcionário antigo cadastrado, tipo funcionário antigo oficial, código tipo funcionário antigo registrado, tipo funcionário antigo do funcionário, código tipo funcionário antigo ativo

### ANTIGOVINCULO
- **Descrição:** Antigo código de Vínculo - Funcionários
- **Sinônimos/variações:** antigo código vínculo, código vínculo antigo, vínculo antigo, código vínculo anterior, vínculo antigo funcionário, código vínculo prévio, vínculo antigo registrado, código vínculo antigo funcionário, vínculo anterior, código vínculo antigo cadastrado, vínculo antigo oficial, código vínculo antigo registrado, vínculo antigo do funcionário, código vínculo antigo ativo

### APMISTO
- **Descrição:** Informa se o Funcionário possui Aviso Misto - Funcionários
- **Sinônimos/variações:** aviso misto, possui aviso misto, tem aviso misto, aviso prévio misto, aviso misto funcionário, aviso misto ativo, aviso misto sim/não, aviso misto registrado, aviso misto cadastrado, aviso misto vigente, aviso misto informado, aviso misto oficial, aviso misto status, aviso misto situação

### APMISTO_DTAVTRAB
- **Descrição:** Data do aviso trabalhado quando possui Aviso Misto - Funcionários
- **Sinônimos/variações:** data aviso trabalhado, data aviso misto trabalhado, data aviso prévio trabalhado, data aviso misto, data aviso trabalhado funcionário, data aviso misto ativo, data aviso trabalhado registrada, data aviso misto cadastrada, data aviso trabalhado oficial, data aviso misto válida, data aviso trabalhado informada, data aviso misto funcionário, data aviso trabalhado sim/não, data aviso misto registrada

### APOSENTADO
- **Descrição:** Informa se o Funcionário é Aposentado - Funcionários
- **Sinônimos/variações:** aposentado, funcionário aposentado, status aposentado, é aposentado, aposentadoria ativa, aposentadoria funcionário, aposentado sim/não, aposentado registrado, aposentado cadastrado, aposentado oficial, aposentado vigente, aposentado informado, aposentado status, aposentado situação

### AREAATUACAOESTAGIO
- **Descrição:** Área de Atuação do Estagiário - Funcionários
- **Sinônimos/variações:** área atuação estagiário, área de atuação do estagiário, setor estagiário, área trabalho estagiário, área estágio, área estagiário, setor atuação estagiário, área atuação estágio, área estagiário funcionário, área atuação estagiário registrada, área atuação estagiário oficial, área atuação estagiário cadastrada, área atuação estagiário vigente, área atuação estagiário informada

### ARREDONDAMENTO
- **Descrição:** Define o valor de Arredondamento de Eventos da Ficha Financeira - Funcionários
- **Sinônimos/variações:** arredondamento, valor arredondamento, arredondamento financeiro, arredondamento eventos, arredondamento ficha financeira, arredondamento salário, arredondamento pagamento, arredondamento proventos, arredondamento funcionário, arredondamento registrado, arredondamento cadastrado, arredondamento oficial, arredondamento vigente, arredondamento informado

### BENEFICIARIO
- **Descrição:** Informa se o Funcionário é Beneficiario - Funcionários
- **Sinônimos/variações:** beneficiário, é beneficiário, status beneficiário, beneficiário funcionário, beneficiário sim/não, beneficiário ativo, beneficiário registrado, beneficiário cadastrado, beneficiário oficial, beneficiário vigente, beneficiário informado, beneficiário situação, beneficiário status, beneficiário atual

### BENEFICIARIOINCAPAZ
- **Descrição:** Informa se o Beneficiário é uma pessoa com doença incapacitante - Funcionários
- **Sinônimos/variações:** beneficiário incapaz, beneficiário com doença incapacitante, beneficiário inválido, beneficiário com incapacidade, beneficiário doença incapacitante, beneficiário incapaz sim/não, beneficiário com deficiência, beneficiário incapaz registrado, beneficiário incapaz cadastrado, beneficiário incapaz oficial, beneficiário incapaz ativo, beneficiário incapaz informado, beneficiário incapaz status, beneficiário incapaz situação

### BENEFPONTOS
- **Descrição:** Nº de pontos disponíveis para o funcionário ref. à Benefícios - Funcionários
- **Sinônimos/variações:** pontos benefícios, número de pontos benefícios, pontos disponíveis benefícios, pontos benefício funcionário, pontos benefício, pontos para benefícios, pontos benefícios cadastrados, pontos benefícios registrados, pontos benefícios oficiais, pontos benefícios vigentes, pontos benefícios informados, pontos benefícios atual, pontos benefícios sim/não, pontos benefícios ativos

### CARREGOUAVISOPREVIO
- **Descrição:** Informa se carregou dados do Aviso Prévio - Funcionários
- **Sinônimos/variações:** carregou aviso prévio, aviso prévio carregado, dados aviso prévio carregados, aviso prévio importado, aviso prévio registrado, aviso prévio cadastrado, aviso prévio informado, aviso prévio ativo, aviso prévio sim/não, aviso prévio status, aviso prévio situação, aviso prévio funcionário, aviso prévio carregado sim/não, aviso prévio disponível

### CHAPA
- **Descrição:** Chapa do Funcionário - Funcionários
- **Sinônimos/variações:** chapa, número da chapa, código chapa, identificação chapa, chapa funcionário, código do funcionário, número chapa funcionário, chapa registrada, chapa cadastrada, chapa oficial, chapa vigente, chapa informada, chapa ativa, chapa atual

### CHAPAANTERIORTRANSF
- **Descrição:** Chapa anterior à transferência - Funcionários
- **Sinônimos/variações:** chapa anterior transferência, chapa antes da transferência, chapa prévia transferência, chapa antiga transferência, chapa anterior à transferência, chapa antes da transf, chapa prévia transf, chapa antiga transf, chapa anterior transferência funcionário, chapa anterior transferência registrada, chapa anterior transferência oficial, chapa anterior transferência cadastrada, chapa anterior transferência ativa, chapa anterior transferência informada

### CHAPAORIGEM
- **Descrição:** Chapa Origem - Funcionários
- **Sinônimos/variações:** chapa origem, número da chapa original, registro inicial, identificação da chapa, código da chapa original, matrícula original, número do crachá inicial, registro de funcionário original, qual é a chapa de origem?, qual a matrícula inicial?, qual o código da chapa original?, qual o registro inicial do funcionário?

### CHAPASUBSTRABTEMP
- **Descrição:** Chapa do ex-Funcionario que o trabalhador temporário esta substituindo - Funcionários
- **Sinônimos/variações:** chapa substituída temporária, chapa do ex-funcionário substituído, registro do substituído temporário, identificação do substituído temporário, número da chapa substituída, matrícula do trabalhador substituído, qual a chapa do substituído temporário?, qual o registro do ex-funcionário substituído?, qual a matrícula do trabalhador temporário substituído?, quem está sendo substituído temporariamente?, qual o código da chapa do substituído?

### CI
- **Descrição:** Código Contribuinte Individual - Funcionários
- **Sinônimos/variações:** código contribuinte individual, número do contribuinte individual, identificação do contribuinte, registro do contribuinte individual, qual o código do contribuinte individual?, qual o número do ci?, identificador do contribuinte individual, registro ci, qual o código do contribuinte?

### CLASSECONTRIB
- **Descrição:** Classe de Contribuição para o INSS - Funcionários
- **Sinônimos/variações:** classe de contribuição inss, categoria de contribuição inss, tipo de contribuição inss, grupo de contribuição inss, qual a classe de contribuição?, qual a categoria inss?, qual o tipo de contribuição para inss?, classe para inss, categoria para inss

### CNPJCEDENTE
- **Descrição:** CNPJ da empresa cedente - Funcionários
- **Sinônimos/variações:** cnpj empresa cedente, cnpj da empresa que cede, cnpj da cedente, identificação da empresa cedente, qual o cnpj da empresa cedente?, qual o cnpj da cedente?, cnpj da empresa que cede o funcionário, cnpj da empresa cedente do funcionário

### CNPJEMPRESAANTERIOR
- **Descrição:** CNPJ empresa anterior - Funcionários
- **Sinônimos/variações:** cnpj empresa anterior, cnpj da empresa anterior, identificação da empresa anterior, qual o cnpj da empresa anterior?, cnpj do empregador anterior, empresa anterior cnpj, qual o cnpj do empregador anterior?, cnpj da última empresa

### CNPJEMPRESACONTRATANTEAPRENDIZ
- **Descrição:** CNPJ da Entidade Qualificadora/ Empregador Cotista - Funcionários
- **Sinônimos/variações:** cnpj empresa contratante aprendiz, cnpj da entidade qualificadora, cnpj do empregador cotista, identificação da empresa contratante do aprendiz, qual o cnpj da empresa contratante do aprendiz?, qual o cnpj da entidade qualificadora?, cnpj do empregador aprendiz, cnpj da empresa cotista

### CNPJEMPRESAORIGEM
- **Descrição:** CNPJ da Empresa de Origem do Dirigente Sindical - Funcionários
- **Sinônimos/variações:** cnpj empresa origem dirigente sindical, cnpj da empresa de origem, identificação da empresa de origem do dirigente, qual o cnpj da empresa de origem?, cnpj da empresa do dirigente sindical, cnpj da origem do dirigente sindical, qual o cnpj da empresa do dirigente?, cnpj da empresa origem

### CNPJEMPRESASUCESSORA
- **Descrição:** CNPJ da empresa sucessora - Funcionários
- **Sinônimos/variações:** cnpj empresa sucessora, cnpj da empresa sucessora, identificação da empresa sucessora, qual o cnpj da empresa sucessora?, cnpj da nova empresa, cnpj da empresa que sucedeu, qual o cnpj da sucessora?, cnpj da empresa sucessora do funcionário

### CNPJMANDATOELETIVO
- **Descrição:** CNPJ do orgão público de origem com mandato eletivo - Funcionários
- **Sinônimos/variações:** cnpj órgão público mandato eletivo, cnpj do órgão público de origem, identificação do órgão público mandato eletivo, qual o cnpj do órgão público?, cnpj do órgão com mandato eletivo, cnpj do órgão público de origem do servidor, qual o cnpj do órgão público de mandato?, cnpj do órgão público

### CNPJRESPONSAVELMATRICULA
- **Descrição:** CNPJ do responsável pela matrícula do servidor/militar - Funcionários
- **Sinônimos/variações:** cnpj responsável pela matrícula, cnpj do responsável pela matrícula do servidor, identificação do responsável pela matrícula, qual o cnpj do responsável pela matrícula?, cnpj do responsável pela matrícula do militar, cnpj do órgão responsável pela matrícula, qual o cnpj do responsável pela matrícula do servidor?, cnpj do responsável pela matrícula

### CODAGENCIAPAGTO
- **Descrição:** Agência do Banco de Pagamento - Tabela de Origem: GAGENCIA - Funcionários
- **Sinônimos/variações:** código agência pagamento, agência do banco de pagamento, número da agência bancária, qual a agência do pagamento?, código da agência bancária, agência para pagamento, agência principal de pagamento, qual o código da agência de pagamento?, agência do banco

### CODAGENCIAPAGTO2
- **Descrição:** Agência do 2º Banco de Pagamento - Tabela de Origem: GAGENCIA - Funcionários
- **Sinônimos/variações:** código 2ª agência pagamento, segunda agência do banco de pagamento, número da 2ª agência bancária, qual a segunda agência do pagamento?, código da segunda agência bancária, segunda agência para pagamento, agência secundária de pagamento, qual o código da 2ª agência de pagamento?, segunda agência do banco

### CODAGENTEINTEGRACAOESTAGIO
- **Descrição:** Código do Agente de Integração - Funcionários
- **Sinônimos/variações:** código agente integração, identificação do agente de integração, código do agente de estágio, qual o código do agente de integração?, código do agente responsável pelo estágio, identificador do agente de integração, qual o código do agente de estágio?, código do agente de integração de estágio

### CODBANCOFGTS
- **Descrição:** Banco de Deposito FGTS - Funcionários
- **Sinônimos/variações:** código banco fgts, banco depósito fgts, identificação do banco fgts, qual o código do banco fgts?, banco para depósito fgts, código do banco do fgts, qual o banco do fgts?, banco fgts

### CODBANCOPAGTO
- **Descrição:** Banco de  Pagamento - Tabela de Origem: GBANCO - Funcionários
- **Sinônimos/variações:** código banco pagamento, banco de pagamento, identificação do banco de pagamento, qual o código do banco de pagamento?, banco para pagamento, código do banco pagador, qual o banco de pagamento?, banco principal de pagamento

### CODBANCOPAGTO2
- **Descrição:** 2º Banco de Pagamento - Tabela de Origem: GBANCO - Funcionários
- **Sinônimos/variações:** código 2º banco pagamento, segundo banco de pagamento, identificação do segundo banco de pagamento, qual o código do segundo banco de pagamento?, banco secundário para pagamento, código do segundo banco pagador, qual o segundo banco de pagamento?, banco de pagamento 2

### CODBANCOPIS
- **Descrição:** Banco PIS - Funcionários
- **Sinônimos/variações:** código banco pis, banco pis, identificação do banco pis, qual o código do banco pis?, banco para pis, código do banco do pis, qual o banco do pis?, banco do pis

### CODCATEGORIA
- **Descrição:** Código da Categoria FGTS/SEFIP - Tabela dinâmica: INT43 - Funcionários
- **Sinônimos/variações:** código categoria fgts, categoria fgts/sefip, identificação da categoria fgts, qual o código da categoria fgts?, categoria para fgts, código da categoria sefip, qual a categoria fgts?, categoria fgts

### CODCATEGORIAEMPRESAORIGEM
- **Descrição:** Código Correspondente à Categoria de Origem do Dirigente Sindical - Funcionários
- **Sinônimos/variações:** código categoria origem dirigente sindical, categoria de origem do dirigente sindical, identificação da categoria de origem, qual o código da categoria de origem?, categoria da empresa de origem do dirigente, código da categoria do dirigente sindical, qual a categoria de origem do dirigente?, categoria origem dirigente sindical

### CODCATEGORIAESOCIAL
- **Descrição:** Código da Categoria do eSocial - Tabela dinâmica: PESOCIALCT - Funcionários
- **Sinônimos/variações:** código categoria esocial, categoria do esocial, identificação da categoria esocial, qual o código da categoria esocial?, categoria para esocial, código da categoria no esocial, qual a categoria do esocial?, categoria esocial

### CODCATEGORIAMANDATOELETIVO
- **Descrição:** Código da Categoria de origem do Servidor Público com mandato eletivo - Funcionários
- **Sinônimos/variações:** código categoria mandato eletivo, categoria do servidor com mandato eletivo, identificação da categoria mandato eletivo, qual o código da categoria mandato eletivo?, categoria do servidor público mandato eletivo, código da categoria do mandato eletivo, qual a categoria do mandato eletivo?, categoria mandato eletivo

### CODCATEGORIATRABCEDIDO
- **Descrição:** Categoria de origem do trabalhador cedido - Funcionários
- **Sinônimos/variações:** código categoria trabalhador cedido, categoria do trabalhador cedido, identificação da categoria do cedido, qual o código da categoria do trabalhador cedido?, categoria do cedido, código da categoria do trabalhador cedido, qual a categoria do trabalhador cedido?, categoria trabalhador cedido

### CODCCUSTO
- **Descrição:** Código do Centro de Custo - Tabela de Origem: PCCUSTO - Funcionários
- **Sinônimos/variações:** código centro de custo, identificação do centro de custo, qual o código do centro de custo?, centro de custo, código do custo, qual o centro de custo?, identificador do centro de custo, código pccusto

### CODCOLFORNEC
- **Descrição:** Coligada do Fornecedor binculado ao Funcionário
- **Sinônimos/variações:** coligada do fornecedor, identificação da coligada do fornecedor, qual a coligada do fornecedor?, coligada vinculada ao fornecedor, coligada do cliente/fornecedor, qual a coligada do fornecedor vinculado?, coligada do fornecedor vinculada ao funcionário, código da coligada do fornecedor

### CODCOLIGADA
- **Descrição:** Código Identificador da Coligada - Tabela de Origem: GCOLIGADA - Funcionários
- **Sinônimos/variações:** código coligada, identificação da coligada, qual o código da coligada?, coligada, código da empresa coligada, qual a coligada?, identificador da coligada, código gcoligada

### CODCOLIGADAORIGEM
- **Descrição:** Código da Coligada de origem - Funcionários
- **Sinônimos/variações:** código coligada de origem, coligada de origem, identificação da coligada de origem, qual o código da coligada de origem?, coligada origem, qual a coligada de origem?, identificador da coligada de origem, código da coligada origem

### CODEQUIPE
- **Descrição:** Código da Equipe do Funcionário - Tabela dinâmica: PEQUIPE - Funcionários
- **Sinônimos/variações:** código equipe, identificação da equipe, qual o código da equipe?, equipe do funcionário, código da equipe do funcionário, qual a equipe?, identificador da equipe, código pequipe

### CODFILIAL
- **Descrição:** Código da Filial - Tabela de Origem: GFILIAL - Funcionários
- **Sinônimos/variações:** código filial, identificação da filial, qual o código da filial?, filial, código da filial do funcionário, qual a filial?, identificador da filial, código gfilial

### CODFORNECEDOR
- **Descrição:** Código do Cliente/Fornecedor vinculado ao Funcionário - Tabela Origem: FCFO
- **Sinônimos/variações:** código fornecedor, identificação do fornecedor, qual o código do fornecedor?, fornecedor vinculado, código cliente/fornecedor, qual o fornecedor vinculado?, identificador do fornecedor, código fcfo

### CODFUNCAO
- **Descrição:** Código da Função - Tabela de Origem: PFUNCAO - Funcionários
- **Sinônimos/variações:** código da função, identificador da função, código do cargo, função do funcionário, qualificação do cargo, código do posto de trabalho, código da posição, função exercida, cargo do empregado, qualificação profissional, código da atividade, função laboral, posição do funcionário, código do trabalho

### CODFUNCAOCONF
- **Descrição:** Código da Função de confiança/Cargo em Comissão - Tabela de Origem: PFUNCAO - Funcionários
- **Sinônimos/variações:** código da função de confiança, cargo em comissão, função comissionada, posição de confiança, cargo de confiança, função comissionada do funcionário, qualificação de confiança, código do cargo em comissão, função especial, cargo temporário de confiança, posição comissionada, função de chefia, cargo de chefia, função comissionada atribuída

### CODGRPQUIOSQUE
- **Descrição:** Código do Grupo de Quiosque - Tabela: PGRPACESSOQUIOSQUE - Funcionários
- **Sinônimos/variações:** código do grupo de quiosque, grupo de quiosque, identificador do quiosque, grupo de acesso ao quiosque, código do quiosque, grupo de trabalho do quiosque, grupo de funcionários do quiosque, código do setor quiosque, grupo de operação do quiosque, grupo de atendimento do quiosque, identificação do grupo quiosque, grupo funcional do quiosque, grupo de usuários do quiosque

### CODHORARIO
- **Descrição:** Código do Horário de Ponto - Tabela: AHORARIO - Funcionários
- **Sinônimos/variações:** código do horário de ponto, horário de trabalho, turno de trabalho, código do turno, programação de ponto, horário de expediente, código do regime de horário, escala de trabalho, horário do funcionário, código da jornada, turno do funcionário, horário registrado, programação de jornada, código do horário

### CODIGORECEITA3533
- **Descrição:** DIRF - Informar remuneração no Cód. da Receita 3533 - Funcionários
- **Sinônimos/variações:** código da receita 3533, remuneração para receita 3533, informar receita 3533, código dirf 3533, remuneração dirf 3533, valor receita 3533, código para dirf 3533, informação receita 3533, remuneração para dirf, código receita fiscal 3533, código receita tributária 3533, código receita para imposto, código receita funcionário

### CODIGOTOMADORTEMP
- **Descrição:** Código do tomador contratante de funcionário temporário - Funcionários
- **Sinônimos/variações:** código do tomador contratante temporário, tomador de serviço temporário, identificador do tomador temporário, código do contratante temporário, empresa tomadora temporária, código do tomador de funcionário temporário, contratante temporário, tomador temporário de funcionário, código do cliente temporário, empresa contratante temporária, identificação do tomador temporário, tomador temporário, código do tomador

### CODINSTITUICAOENSINOESTAGIO
- **Descrição:** Código da Instituição de Ensino do Estágio - Tabela de Origem: VENTIDADES - Funcionários
- **Sinônimos/variações:** código da instituição de ensino do estágio, instituição de ensino do estagiário, código da escola do estágio, identificador da instituição de ensino, escola do estágio, código da entidade de ensino, instituição educacional do estágio, código da faculdade do estágio, instituição de ensino vinculada, código da universidade do estágio, entidade de ensino do estagiário, código da instituição acadêmica

### CODNIVELESTAGIO
- **Descrição:** Nível do Estágio - Tabela dinâmica: NIVELESTAG - Funcionários
- **Sinônimos/variações:** nível do estágio, grau do estágio, categoria do estágio, nível acadêmico do estágio, classificação do estágio, nível do estagiário, grau de escolaridade do estágio, nível educacional do estágio, categoria do estagiário, nível de formação do estágio, nível do curso do estágio, nível do programa de estágio, nível do treinamento

### CODNIVELSAL
- **Descrição:** Código do Nível da Tabela Salarial - Tabela de Origem: VNIVELFUNCAO - Funcionários
- **Sinônimos/variações:** código do nível salarial, nível da tabela salarial, categoria salarial, faixa salarial, nível de salário, código do nível de remuneração, nível de vencimento, categoria de salário, nível da remuneração, faixa de pagamento, nível da carreira salarial, código do nível de pagamento, nível da faixa salarial

### CODOCORRENCIA
- **Descrição:** Código da Ocorrência SEFIP - Tabela Dinâmica: INT44 - Funcionários
- **Sinônimos/variações:** código da ocorrência sefip, tipo de ocorrência sefip, identificador da ocorrência, código do evento sefip, ocorrência sefip, tipo de evento sefip, código da situação sefip, registro de ocorrência sefip, código do fato sefip, ocorrência trabalhista sefip, código do evento trabalhista, tipo de ocorrência trabalhista, código da ocorrência

### CODORGORIDES
- **Descrição:** Órgão Origem / Destino - Funcionários
- **Sinônimos/variações:** código do órgão origem/destino, órgão de origem, órgão de destino, identificador do órgão, código do órgão, órgão responsável, órgão de transferência, código do órgão de movimentação, órgão de alocação, código do setor origem/destino, órgão de origem ou destino, código do departamento origem/destino, órgão de origem ou transferência

### CODPESSOA
- **Descrição:** Identificador da Pessoa - Tabela de Origem: PPESSOA - Funcionários
- **Sinônimos/variações:** identificador da pessoa, código da pessoa, id do funcionário, identificação do empregado, código do colaborador, identificador do trabalhador, id da pessoa, registro da pessoa, código do indivíduo, identificação do funcionário, id do colaborador, registro do empregado, código do trabalhador

### CODRECEBIMENTO
- **Descrição:** Código do Tipo de Recebimento - Tabela Dinâmica: INT04 - Funcionários
- **Sinônimos/variações:** código do tipo de recebimento, tipo de recebimento, categoria de recebimento, forma de pagamento, tipo de pagamento, código do pagamento, categoria de pagamento, tipo de receita, código do crédito, tipo de valor recebido, categoria de receita, código do tipo de crédito, tipo de entrada financeira

### CODREGJURI
- **Descrição:** Código do tipo de Regime Jurídico - Tabela Dinâmica: PPETAB11 - Funcionários
- **Sinônimos/variações:** código do regime jurídico, tipo de regime jurídico, categoria jurídica, regime legal, classificação jurídica, código do regime trabalhista, tipo de vínculo jurídico, regime de contratação, código do regime de trabalho, categoria do regime jurídico, tipo de regime de trabalho, regime jurídico do funcionário, classificação do regime

### CODSAQUEFGTS
- **Descrição:** Código de Saque do FGTS - Tabela Dinâmica: INT17 - Funcionários
- **Sinônimos/variações:** código de saque do fgts, tipo de saque fgts, categoria de saque fgts, motivo do saque fgts, código da liberação fgts, tipo de retirada fgts, código do benefício fgts, motivo para saque fgts, categoria de liberação fgts, tipo de benefício fgts, código do resgate fgts, motivo do resgate fgts, tipo de operação fgts

### CODSECAO
- **Descrição:** Código da Seção - Tabela de Origem: PSECAO - Funcionários
- **Sinônimos/variações:** código da seção, identificador da seção, setor do funcionário, código do departamento, seção do empregado, código do setor, área de trabalho, código da unidade, seção organizacional, código da divisão, setor de atuação, área funcional, código da área

### CODSINDICATO
- **Descrição:** Código do Sindicato - Tabela de Origem: PSINDIC - Funcionários
- **Sinônimos/variações:** código do sindicato, identificador do sindicato, sindicato do funcionário, código da entidade sindical, associação sindical, código da federação sindical, sindicato laboral, código da organização sindical, entidade sindical, código do órgão sindical, sindicato profissional, código da central sindical, representação sindical

### CODSINDICATOFILIACAO
- **Descrição:** Código do Sindicato da Filiação Sindical - Tabela de Origem: PSINDIC - Funcionários
- **Sinônimos/variações:** código do sindicato da filiação, sindicato de filiação, entidade sindical filiada, código da filiação sindical, sindicato associado, código do sindicato associado, filiação sindical do funcionário, código da associação sindical, sindicato vinculado, código do sindicato vinculado, entidade de filiação sindical, código do sindicato filiado, filiação sindical

### CODSITUACAO
- **Descrição:** Código da Situação - Tabela Dinâmica: INT06 - Funcionários
- **Sinônimos/variações:** código da situação, status do funcionário, situação do empregado, estado do vínculo, código do status, situação funcional, estado do funcionário, código do estado, status do vínculo, situação contratual, código da condição, estado do contrato, situação atual

### CODTABELASALARIAL
- **Descrição:** Codigo de Tabela Salarial - Funcionários
- **Sinônimos/variações:** código da tabela salarial, tabela salarial, referência salarial, código da tabela de salários, tabela de remuneração, código da tabela de pagamento, referência de salário, tabela de vencimentos, código da tabela de proventos, tabela de carreira salarial, código da tabela de cargos, tabela salarial do funcionário, referência de remuneração

### CODTIPO
- **Descrição:** Código de Tipo de Funcionário - Tabela de Origem: PTPFUNC
- **Sinônimos/variações:** código do tipo de funcionário, tipo de funcionário, categoria do funcionário, classificação do funcionário, código da categoria, tipo de colaborador, tipo de empregado, código do grupo de funcionário, categoria funcional, tipo de vínculo, classificação funcional, código do tipo de colaborador, tipo de trabalhador

### CODTIPOCONTRATO
- **Descrição:** Código do Tipo de Contrato - Funcionários
- **Sinônimos/variações:** código do tipo de contrato, tipo de contrato, categoria do contrato, modalidade de contrato, classificação do contrato, código da modalidade contratual, tipo de vínculo contratual, código do regime de contrato, categoria do vínculo, tipo de acordo contratual, código do tipo de vínculo, modalidade de vínculo, tipo de contratação

### COLIGADAANTERIORTRANSF
- **Descrição:** Coligada anterior à transferência - Funcionários
- **Sinônimos/variações:** coligada anterior à transferência, empresa anterior à transferência, coligada de origem, empresa de origem, coligada antes da transferência, empresa antes da transferência, coligada anterior, empresa anterior, coligada origem da transferência, empresa origem da transferência, coligada pré-transferência, empresa pré-transferência, coligada antes da movimentação

### COLTOMADORTEMP
- **Descrição:** Coligada do tomador contratante de funcionário temporário - Funcionários
- **Sinônimos/variações:** coligada do tomador temporário, empresa do tomador temporário, coligada do contratante temporário, empresa do contratante temporário, coligada tomadora temporária, empresa tomadora temporária, coligada do tomador de serviço temporário, empresa do tomador de serviço temporário, coligada do cliente temporário, empresa do cliente temporário, coligada contratante temporária, empresa contratante temporária, coligada do tomador

### CONTAFGTS
- **Descrição:** Número da Conta para Crédito do Fgts - Funcionários
- **Sinônimos/variações:** número da conta fgts, conta para crédito do fgts, conta fgts do funcionário, número da conta para fgts, conta vinculada ao fgts, conta para depósito fgts, número da conta do fundo fgts, conta fgts, conta para recolhimento fgts, número da conta fgts do empregado, conta de fgts, conta para crédito do fundo, número da conta fgts vinculada

### CONTAPAGAMENTO
- **Descrição:** Conta para Pagamento - Funcionários
- **Sinônimos/variações:** conta para pagamento, conta bancária para pagamento, conta salário, conta para depósito salarial, conta para crédito de pagamento, conta bancária do funcionário, conta para transferência de pagamento, conta para pagamento de salário, conta para pagamento de funcionário, conta para depósito de salário, conta para crédito bancário, conta para pagamento mensal, conta para recebimento

### CONTAPAGAMENTO2
- **Descrição:** 2ª Conta para Pagamento - Funcionários
- **Sinônimos/variações:** segunda conta para pagamento, 2ª conta para pagamento, conta alternativa para pagamento, conta bancária secundária, conta adicional para pagamento, conta para pagamento extra, conta para pagamento complementar, conta para depósito alternativo, segunda conta salário, conta para crédito secundário, conta para pagamento adicional, conta para pagamento extra salário

### CONTRIBASSISTCNPJ
- **Descrição:** Contribuição Assistencial CNPJ - Funcionários
- **Sinônimos/variações:** cnpj da contribuição assistencial, cnpj da contribuição sindical assistencial, cnpj para contribuição assistencial, cnpj da contribuição assistencial do funcionário, cnpj da contribuição assistencial sindical, cnpj da contribuição assistencial patronal, cnpj da contribuição assistencial obrigatória, cnpj da entidade para contribuição assistencial, cnpj da contribuição assistencial recolhida, cnpj da contribuição assistencial associativa, cnpj da contribuição assistencial descontada, cnpj da contribuição assistencial sindicalizada

### CONTRIBASSISTVALOR
- **Descrição:** Contribuição Assistencial Valor - Funcionários
- **Sinônimos/variações:** valor da contribuição assistencial, quantia da contribuição assistencial, montante da contribuição assistencial, valor descontado da contribuição assistencial, valor pago da contribuição assistencial, quantia recolhida da contribuição assistencial, valor da contribuição sindical assistencial, valor da contribuição assistencial do funcionário, valor da contribuição assistencial obrigatória, valor da contribuição assistencial patronal, valor da contribuição assistencial associativa, valor da contribuição assistencial descontada, valor da contribuição assistencial sindical

### CONTRIBASSOC1OCORRCNPJ
- **Descrição:** Contribuição Associativa(Pri Ocor)CNPJ - Funcionários
- **Sinônimos/variações:** cnpj da contribuição associativa primeira ocorrência, cnpj da contribuição associativa (primeira ocorrência), cnpj da contribuição associativa inicial, cnpj da primeira ocorrência da contribuição associativa, cnpj da contribuição associativa principal, cnpj da contribuição associativa do funcionário primeira ocorrência, cnpj da contribuição associativa obrigatória primeira ocorrência, cnpj da entidade para contribuição associativa primeira ocorrência, cnpj da contribuição associativa recolhida primeira ocorrência, cnpj da contribuição associativa descontada primeira ocorrência, cnpj da contribuição associativa sindical primeira ocorrência, cnpj da contribuição associativa inicial do funcionário, cnpj da contribuição associativa primeira

### CONTRIBASSOC1OCORRVALOR
- **Descrição:** Contribuição Associat(Pri Ocor)Valor - Funcionários
- **Sinônimos/variações:** contribuição associativa principal valor, valor contribuição associativa pri, valor contribuição associat primeira ocorrência, quanto pagou contribuição associativa principal, valor contribuição associativa 1ª ocorrência, valor contribuição associativa inicial, valor contribuição associativa principal, valor contribuição associativa funcionário, valor contribuição associativa pri ocorrência, valor contribuição associativa primeira

### CONTRIBASSOC2OCORRCNPJ
- **Descrição:** Contribuição Associativa(Sec Ocor)CNPJ - Funcionários
- **Sinônimos/variações:** cnpj contribuição associativa secundária, cnpj contribuição associativa 2ª ocorrência, cnpj contribuição associativa sec, cnpj contribuição associativa segunda ocorrência, cnpj da contribuição associativa secundária, cnpj da contribuição associativa 2ª, cnpj da contribuição associativa sec ocorrência, cnpj da contribuição associativa secundária funcionário, cnpj da contribuição associativa 2ª ocorrência

### CONTRIBASSOC2OCORRVALOR
- **Descrição:** Contribuição Associat(Sec Ocor)Valor - Funcionários
- **Sinônimos/variações:** valor contribuição associativa secundária, valor contribuição associativa 2ª ocorrência, valor contribuição associativa sec, quanto pagou contribuição associativa secundária, valor contribuição associativa segunda ocorrência, valor contribuição associativa 2ª, valor contribuição associativa sec ocorrência, valor contribuição associativa funcionário

### CONTRIBCONFEDCNPJ
- **Descrição:** Contribuição Confederativa CNPJ - Funcionários
- **Sinônimos/variações:** cnpj contribuição confederativa, cnpj da contribuição confederativa, cnpj contribuição confederação, cnpj contribuição confederativa funcionário, cnpj da contribuição confederação, cnpj para contribuição confederativa, cnpj da contribuição confederação funcionário, cnpj da contribuição confederativa empresa

### CONTRIBCONFEDVALOR
- **Descrição:** Contribuição Confederativa Valor - Funcionários
- **Sinônimos/variações:** valor contribuição confederativa, quanto pagou contribuição confederativa, valor contribuição confederação, valor contribuição confederativa funcionário, valor contribuição confederação empresa, valor contribuição confederativa mensal, valor contribuição confederativa total, valor contribuição confederativa recolhido

### CONTRIBSINDICAL
- **Descrição:** Contribuição Sindical - Funcionários
- **Sinônimos/variações:** contribuição sindical, valor contribuição sindical, pagamento contribuição sindical, quanto pagou contribuição sindical, contribuição para sindicato, valor desconto sindical, desconto contribuição sindical, contribuição sindical funcionário, valor contribuição sindicato

### COTAPCD
- **Descrição:** Indicar se o funcionário deficiente preenche cota de PCD - Funcionários
- **Sinônimos/variações:** cota pcd preenchida, funcionário deficiente preenche cota pcd, indicar cota pcd, preenche cota para pcd, cota para pessoa com deficiência, funcionário pcd na cota, preenchimento cota pcd, indicação cota pcd, funcionário deficiente cota pcd

### CPFCOORDENADORESTAGIO
- **Descrição:** CPF do Coordenador do Estágio - Funcionários
- **Sinônimos/variações:** cpf coordenador estágio, cpf do coordenador do estágio, cpf responsável estágio, cpf do supervisor de estágio, cpf do coordenador do estagiário, cpf do responsável pelo estágio, cpf do coordenador estágio funcionário, cpf do gestor do estágio

### CPFSUBSTRABTEMP
- **Descrição:** CPF do Trabalhador substituído - Funcionários
- **Sinônimos/variações:** cpf trabalhador substituído, cpf do substituto temporário, cpf do trabalhador substituído temporário, cpf do substituído temporário, cpf do trabalhador substituto, cpf do substituto temporário funcionário

### DATAADMISSAO
- **Descrição:** Data de Admissão - Funcionários
- **Sinônimos/variações:** data de admissão, data ingresso funcionário, data início trabalho, quando foi admitido, data contratação, data início contrato, data entrada funcionário, data admissão funcionário, quando começou a trabalhar

### DATAADMISSAOCEDENTE
- **Descrição:** Data de admissão do trabalhador no empregador de origem (Cedente) - Funcionários
- **Sinônimos/variações:** data admissão cedente, data ingresso no empregador de origem, data início no empregador cedente, data admissão no cedente, data contratação cedente, data início trabalho cedente, quando foi admitido no cedente, data admissão empresa cedente

### DATADEMISSAO
- **Descrição:** Data de Demissão - Funcionários
- **Sinônimos/variações:** data de demissão, data saída funcionário, quando foi demitido, data término contrato, data desligamento, data fim trabalho, data demissão funcionário, quando saiu da empresa

### DATAINCAPACIDADE
- **Descrição:** Data do reconhecimento da incapacidade - Funcionários
- **Sinônimos/variações:** data reconhecimento incapacidade, quando foi reconhecida incapacidade, data início incapacidade, data atestado incapacidade, data incapacidade funcionário, data reconhecimento afastamento, data incapacidade laboral, data início afastamento

### DATAINICIOBENEFICIARIO
- **Descrição:** Data de inicio do cadastro do beneficiario - Funcionários
- **Sinônimos/variações:** data início cadastro beneficiário, quando começou cadastro beneficiário, data início beneficiário, data cadastro beneficiário, data início registro beneficiário, data início inclusão beneficiário, data início do beneficiário, data início do cadastro

### DATAINICIODESCEMPRESTIMO
- **Descrição:** Dt Início Desconto Empréstimo Férias - Funcionários
- **Sinônimos/variações:** data início desconto empréstimo férias, quando começou desconto empréstimo férias, data início desconto empréstimo, data início desconto férias, data início desconto empréstimo funcionário, data início desconto empréstimo férias funcionário, data início desconto empréstimo nas férias

### DATAREINTEGRACAO
- **Descrição:** Data da Reintegração - Funcionários
- **Sinônimos/variações:** data da reintegração, quando foi reintegrado, data retorno ao trabalho, data reintegração funcionário, data reintegração empresa, data reintegração contratual, data reintegração laboral, data reintegração ao emprego

### DATARESCISAO
- **Descrição:** Data de rescisão - Funcionários
- **Sinônimos/variações:** data de rescisão, quando rescindiu contrato, data término contrato, data rescisão contrato, data desligamento, data fim contrato, data rescisão funcionário, data encerramento contrato

### DATARETORNOEFETIVO
- **Descrição:** Data do Efetivo Retorno ao Trabalho - Funcionários
- **Sinônimos/variações:** data retorno efetivo ao trabalho, quando retornou ao trabalho, data retorno funcionário, data retorno após afastamento, data retorno efetivo, data retorno laboral, data retorno após licença, data retorno trabalho

### DEDUZIRRF65
- **Descrição:** Dedução de Irrf para 65 Anos - Funcionários
- **Sinônimos/variações:** deduzir irrf para maiores de 65, dedução irrf 65 anos, desconto irrf para 65 anos, dedução irrf para idosos, deduzir imposto para 65 anos, dedução irrf para aposentados 65, dedução irrf para faixa 65 anos, deduzir irrf idade 65

### DEMISSAODESEMPISULFINAD
- **Descrição:** Demissão por Desempenho Insuficiente ou Inadaptação - Funcionários
- **Sinônimos/variações:** demissão por desempenho insuficiente, demissão por inadaptação, demissão por baixo desempenho, demissão por insuficiência, demissão por desempenho ruim, demissão por insuficiência ou inadaptação, demissão por desempenho insatisfatório, demissão por desempenho insuficiente ou inadaptação

### DESCONSIDERARIRRFSIMPLIFICADO
- **Descrição:** Desconsiderar Desconto Simplificado do IRRF - Funcionários
- **Sinônimos/variações:** desconsiderar desconto simplificado irrf, não aplicar desconto simplificado irrf, ignorar desconto simplificado irrf, não considerar desconto simplificado irrf, desconsiderar irrf simplificado, não aplicar irrf simplificado, ignorar irrf simplificado, não considerar irrf simplificado

### DESCONTAAVISOPREVIO
- **Descrição:** Desconta Aviso Prévio do Funcionário - Funcionários
- **Sinônimos/variações:** descontar aviso prévio, desconto aviso prévio funcionário, desconta aviso prévio, desconto do aviso prévio, descontar valor aviso prévio, desconto aviso prévio rescisão, descontar aviso prévio demissão, desconto aviso prévio

### DESCRICAOSALVARIAVEL
- **Descrição:** Descrição do Salário Variável - Funcionários
- **Sinônimos/variações:** descrição salário variável, descrição do salário variável, descrição do salário variável funcionário, descrição salário variável mensal, descrição salário variável pagamento, descrição salário variável provento, descrição salário variável adicional

### DIASPRORROGACAOBEM
- **Descrição:** Dias de Prorrogação B.E.M. - Funcionários
- **Sinônimos/variações:** dias prorrogação bem, dias de prorrogação bem, quantidade dias prorrogação bem, dias extensão bem, dias prorrogação benefício emergencial, dias prorrogação benefício, dias prorrogação bem funcionário

### DIASUTEISMES
- **Descrição:** Dias Úteis do Mês - Expediente Integral para Vale Transporte - Funcionários
- **Sinônimos/variações:** dias úteis do mês, dias úteis mês, quantidade dias úteis no mês, dias úteis expediente integral, dias úteis para vale transporte, dias úteis mês funcionário, dias úteis mês para vale transporte, dias úteis mês expediente

### DIASUTMEIOEXP
- **Descrição:** Dias Úteis de Meio Expediente - Vale Transporte- Funcionários
- **Sinônimos/variações:** dias úteis meio expediente, dias úteis de meio expediente, dias úteis meio expediente vale transporte, dias úteis meio expediente funcionário, dias úteis meio expediente para vale transporte, dias úteis meio expediente mês, dias úteis meio expediente vale transporte funcionário

### DIASUTPROXMEIO
- **Descrição:** Dias Úteis do Próx. Mês de Meio Expediente - Vale Transporte - Funcionários
- **Sinônimos/variações:** dias úteis próximo mês meio expediente, dias úteis do próximo mês meio expediente, dias úteis próximo mês meio expediente vale transporte, dias úteis próximo mês meio expediente funcionário, dias úteis próximo mês meio expediente para vale transporte, dias úteis próximo mês meio expediente vale transporte funcionário

### DIASUTPROXMES
- **Descrição:** Dias Úteis do Próximo Mês - Vale Transporte - Funcionários
- **Sinônimos/variações:** dias úteis próximo mês, dias úteis do próximo mês, dias úteis próximo mês vale transporte, dias úteis próximo mês funcionário, dias úteis próximo mês para vale transporte, dias úteis próximo mês expediente, dias úteis próximo mês vale transporte funcionário

### DIASUTRESTANTES
- **Descrição:** Dias Úteis Restantes - Vale Transporte- Funcionários
- **Sinônimos/variações:** dias úteis restantes, dias úteis restantes para vale transporte, dias úteis restantes mês, dias úteis restantes funcionário, dias úteis restantes expediente, dias úteis restantes vale transporte funcionário, dias úteis restantes no mês

### DIASUTRESTMEIO
- **Descrição:** Dias Úteis Restantes de Meio Expediente - Funcionários
- **Sinônimos/variações:** dias úteis restantes meio expediente, dias úteis restantes de meio expediente, dias úteis restantes meio expediente funcionário, dias úteis restantes meio expediente vale transporte, dias úteis restantes meio expediente para vale transporte, dias úteis restantes meio expediente mês, dias úteis restantes meio expediente vale transporte funcionário

### DISPENSADOAVISO
- **Descrição:** Dispensado do cumprimento do Aviso Prévio - Funcionários
- **Sinônimos/variações:** dispensado do aviso prévio, isento do aviso prévio, sem cumprimento do aviso, aviso prévio dispensado, excluído do aviso prévio, dispensa do aviso, não cumpriu aviso prévio, aviso prévio não obrigatório, dispensado do aviso, aviso prévio liberado

### DTACORDOBEM
- **Descrição:** Data do Acordo B.E.M. - Funcionários
- **Sinônimos/variações:** data do acordo b.e.m., quando foi o acordo b.e.m., data do acordo benefício, data do acordo bem, registro do acordo b.e.m., data do acordo trabalhista b.e.m., data do acordo especial b.e.m., data do acordo de benefício, quando ocorreu o acordo b.e.m.

### DTADMISSAOEMPRESAORIGEM
- **Descrição:** Data de Admissão do Dirigente Sindical na Empresa de Origem - Funcionários
- **Sinônimos/variações:** data de admissão na empresa origem, início na empresa de origem, data de ingresso na empresa original, admissão na empresa de origem, data de contratação na empresa origem, quando entrou na empresa origem, data de admissão do dirigente sindical, data de início na empresa origem, admissão do dirigente na empresa original

### DTANTECIPACAOBEM
- **Descrição:** Data da Antecipação B.E.M. - Funcionários
- **Sinônimos/variações:** data da antecipação b.e.m., quando foi a antecipação b.e.m., data antecipação benefício, registro da antecipação b.e.m., data da antecipação do benefício, data antecipação bem, quando ocorreu a antecipação b.e.m., data do adiantamento b.e.m.

### DTAPOSENTADORIA
- **Descrição:** Data de aposentadoria - Funcionários
- **Sinônimos/variações:** data de aposentadoria, quando aposentou, data do benefício de aposentadoria, data do início da aposentadoria, registro da aposentadoria, data do afastamento por aposentadoria, data do benefício previdenciário, data do início do benefício, data do desligamento por aposentadoria

### DTAVISOFERIAS
- **Descrição:** Data do Aviso de Férias - Funcionários
- **Sinônimos/variações:** data do aviso de férias, quando foi avisado sobre férias, data do comunicado de férias, registro do aviso de férias, data do aviso para férias, data do aviso prévio de férias, data do comunicado para férias, data do aviso férias, quando avisou as férias

### DTAVISOPREVIO
- **Descrição:** Data do Aviso Prévio - Funcionários
- **Sinônimos/variações:** data do aviso prévio, quando foi o aviso prévio, data do comunicado de aviso prévio, registro do aviso prévio, data do aviso para desligamento, data do aviso prévio dado, data do aviso prévio enviado, data do aviso prévio trabalhista, quando avisou o desligamento

### DTAVISOPREVIOTRAB
- **Descrição:** Data Aviso Prévio Trabalhado - Funcionários
- **Sinônimos/variações:** data do aviso prévio trabalhado, quando cumpriu aviso prévio, data do aviso prévio com trabalho, registro do aviso prévio trabalhado, data do aviso prévio efetivo, data do aviso prévio cumprido, data do aviso prévio com exercício, data do aviso prévio trabalhado pelo funcionário, quando trabalhou o aviso prévio

### DTBASE
- **Descrição:** Data Base - Funcionários
- **Sinônimos/variações:** data base, data referência, data de referência salarial, data base para cálculo, data base do funcionário, data base para reajuste, data base para benefícios, data base para férias, data base para folha

### DTCADASTROPIS
- **Descrição:** Data de Cadastro no PIS - Funcionários
- **Sinônimos/variações:** data de cadastro no pis, quando cadastrou no pis, data de inscrição no pis, registro do cadastro pis, data do pis, data de inclusão no pis, data de registro no pis, data do número do pis, data do cadastro do trabalhador no pis

### DTCANCELAMENTOAVISO
- **Descrição:** Data do cancelamento do Aviso Prévio - Funcionários
- **Sinônimos/variações:** data do cancelamento do aviso prévio, quando cancelou o aviso prévio, data do cancelamento do aviso, registro do cancelamento do aviso prévio, data do cancelamento do aviso trabalhista, data do cancelamento do aviso prévio dado, data do cancelamento do aviso prévio enviado, data do cancelamento do aviso prévio pelo funcionário, quando cancelou o aviso

### DTCANCELAMENTOBEM
- **Descrição:** Data do Cancelamento B.E.M. - Funcionários
- **Sinônimos/variações:** data do cancelamento b.e.m., quando cancelou o benefício b.e.m., data do cancelamento do acordo b.e.m., registro do cancelamento b.e.m., data do cancelamento do benefício especial, data do cancelamento do benefício b.e.m., data do cancelamento do acordo trabalhista b.e.m., data do cancelamento do benefício b.e.m. pelo funcionário

### DTDEMISSAOPREVISTA
- **Descrição:** Data prevista para Demissão - Funcionários
- **Sinônimos/variações:** data prevista para demissão, quando será a demissão, data estimada para desligamento, previsão de demissão, data provável de demissão, data prevista para desligamento, data de demissão planejada, data prevista para saída, quando deve ocorrer a demissão

### DTDESLIGAMENTO
- **Descrição:** Data de Desligamento - Funcionários
- **Sinônimos/variações:** data de desligamento, quando desligou, data do desligamento do funcionário, registro do desligamento, data da saída do funcionário, data do término do vínculo, data do fim do contrato, data do desligamento efetivo, quando ocorreu o desligamento

### DTDESLIGAMENTOJUDICIAL
- **Descrição:** Data de Desligamento conforme mandato Judicial - Funcionários
- **Sinônimos/variações:** data de desligamento judicial, quando foi o desligamento por ordem judicial, data do desligamento conforme decisão judicial, registro do desligamento judicial, data do desligamento por mandato judicial, data do desligamento por ordem da justiça, data do desligamento determinado judicialmente, data do desligamento por sentença judicial, quando ocorreu o desligamento judicial

### DTDESLIGAMENTOREINT
- **Descrição:** Data do Desligamento feito antes da Reintegração - Funcionários
- **Sinônimos/variações:** data do desligamento antes da reintegração, quando desligou antes da reintegração, data do desligamento pré-reintegração, registro do desligamento antes da reintegração, data do desligamento anterior à reintegração, data do desligamento antes do retorno, data do desligamento antes da reintegração judicial, data do desligamento prévio à reintegração, quando ocorreu o desligamento antes da reintegração

### DTEXERCICIO
- **Descrição:** Data em Exercício Estatutário - Funcionários
- **Sinônimos/variações:** data em exercício estatutário, quando iniciou exercício estatutário, data do exercício funcional, registro do exercício estatutário, data do início do exercício, data do exercício no cargo, data do exercício profissional, data do exercício do servidor, quando começou o exercício estatutário

### DTEXERCICIOMANDATOELETIVO
- **Descrição:** Data de Exercício do Servidor no Orgão público de origem com mandato eletivo - Funcionários
- **Sinônimos/variações:** data de exercício do mandato eletivo, quando iniciou mandato eletivo, data do exercício no órgão público com mandato, registro do exercício com mandato eletivo, data do início do mandato eletivo, data do exercício do servidor com mandato, data do exercício em cargo eletivo, data do exercício do mandato público, quando começou o exercício do mandato eletivo

### DTFIMQUARENTENA
- **Descrição:** Data fim da quarentena - Funcionários
- **Sinônimos/variações:** data fim da quarentena, quando termina a quarentena, data do término da quarentena, registro do fim da quarentena, data final da quarentena, data do encerramento da quarentena, data do fim do período de quarentena, quando acaba a quarentena, data do término do isolamento

### DTINICIOABONO
- **Descrição:** Data de inicio do abono permanência estatutário - Funcionários
- **Sinônimos/variações:** data de início do abono permanência, quando começou o abono permanência, data do início do benefício abono, registro do início do abono permanência, data do começo do abono permanência, data do início do abono estatutário, data do início do abono de permanência, quando iniciou o abono permanência, data do início do abono funcional

### DTINICIOLICENCA
- **Descrição:** Data de Início da Licença - Funcionários
- **Sinônimos/variações:** data de início da licença, quando começou a licença, data do início do afastamento, registro do início da licença, data do começo da licença, data do início da licença funcional, data do início da licença médica, quando iniciou a licença, data do início do afastamento do trabalho

### DTINICIOVINCULO
- **Descrição:** Data início do vínculo - Funcionários
- **Sinônimos/variações:** data início do vínculo, quando começou o vínculo, data do início do contrato, registro do início do vínculo, data do começo do vínculo empregatício, data do início da relação de trabalho, data do início da contratação, quando iniciou o vínculo, data do início da prestação de serviço

### DTOPCAOFGTS
- **Descrição:** Data de Opção do Fgts - Funcionários
- **Sinônimos/variações:** data de opção do fgts, quando optou pelo fgts, data da escolha do fgts, registro da opção pelo fgts, data da adesão ao fgts, data da opção pelo fundo de garantia, data da escolha do fundo de garantia, quando fez a opção pelo fgts, data da opção pelo benefício fgts

### DTPAGTOFERIAS
- **Descrição:** Data do Pagamento de Ferias - Funcionários
- **Sinônimos/variações:** data do pagamento de férias, quando pagaram as férias, data do pagamento das férias, registro do pagamento de férias, data do pagamento do benefício férias, data do pagamento do abono férias, data do pagamento do salário de férias, quando foi pago o valor das férias, data do pagamento do descanso remunerado

### DTPAGTORESCISAO
- **Descrição:** Data de Pagamento da Recisão - Funcionários
- **Sinônimos/variações:** data do pagamento da rescisão, quando pagaram a rescisão, data do pagamento da rescisão contratual, registro do pagamento da rescisão, data do pagamento do acerto rescisório, data do pagamento do desligamento, data do pagamento do saldo rescisório, quando foi pago o valor da rescisão, data do pagamento do término do contrato

### DTPREVTERMINOESTAGIO
- **Descrição:** Data Prevista para o Término do Estágio - Funcionários
- **Sinônimos/variações:** data prevista para término do estágio, quando termina o estágio, data estimada para fim do estágio, previsão de término do estágio, data provável de fim do estágio, data prevista para encerramento do estágio, data de conclusão prevista do estágio, quando deve acabar o estágio, data prevista para finalização do estágio

### DTPRORROGACAOBEM
- **Descrição:** Data da Prorrogação B.E.M. - Funcionários
- **Sinônimos/variações:** data da prorrogação b.e.m., quando prorrogou o benefício b.e.m., data da extensão do acordo b.e.m., registro da prorrogação b.e.m., data da prorrogação do benefício especial, data da prorrogação do acordo b.e.m., data da extensão do benefício b.e.m., quando prorrogou o acordo b.e.m., data da prorrogação do benefício b.e.m.

### DTPROXAQUISFERIAS
- **Descrição:** Data do próximo Periodo Aquisitivo de Férias - Funcionários
- **Sinônimos/variações:** data do próximo período aquisitivo de férias, quando começa o próximo período de férias, data do próximo ciclo de férias, registro do próximo período aquisitivo, data do próximo direito a férias, data do próximo período de aquisição de férias, quando inicia o próximo período de férias, data do próximo período para férias, data do próximo período aquisitivo

### DTSALDOFGTS
- **Descrição:** Data do Saldo do Fgts - Funcionários
- **Sinônimos/variações:** data do saldo do fgts, quando foi atualizado o saldo do fgts, data do extrato do fgts, registro da data do saldo fgts, data da atualização do saldo do fgts, data do saldo disponível do fgts, data do saldo do fundo de garantia, quando atualizou o saldo do fgts, data do saldo do benefício fgts

### DTTRANSFERENCIA
- **Descrição:** Data de Transferência - Funcionários
- **Sinônimos/variações:** data de transferência, quando foi a transferência, data do movimento de transferência, registro da data de transferência, data da transferência do funcionário, data da transferência interna, data da mudança de setor, quando ocorreu a transferência, data da transferência funcional

### DTULTIMOMOVIM
- **Descrição:** Data do Último Movimento - Funcionários
- **Sinônimos/variações:** data último movimento, última movimentação, data da última alteração, data do último registro, quando foi o último movimento, data última atualização, última modificação, data do último evento, data do último lançamento, data do último processamento, data do último ajuste, última data movimentada, data do último cadastro, data do último evento registrado

### DTULTIMOMOVIMPGTOEXTRAS
- **Descrição:** Data de Ultimo Movimento para Pagamento - Funcionários
- **Sinônimos/variações:** data último movimento pagamento, última movimentação pagamento, data último pagamento extra, data do último pagamento, quando foi o último pagamento, data último pagamento de extras, data do último pagamento adicional, data do último pagamento extra, data do último pagamento registrado, data da última quitação extra, data do último crédito extra, data do último evento de pagamento, última data pagamento extra, data do último processamento de pagamento

### DTVENCFERIAS
- **Descrição:** Data de Vencimento das Férias - Funcionários
- **Sinônimos/variações:** data vencimento férias, quando vencem as férias, data limite férias, data para gozo das férias, data final das férias, data de vencimento do período de férias, data para tirar férias, data de término das férias, data de validade das férias, data para início das férias, data de expiração das férias, data prevista para férias, data do vencimento do descanso, data para usufruir férias

### DURACAOBEM
- **Descrição:** Duração B.E.M. - Funcionários
- **Sinônimos/variações:** duração b.e.m., tempo de duração do b.e.m., período do b.e.m., tempo do benefício, duração do benefício, tempo de vigência do b.e.m., período de duração do b.e.m., tempo de validade do b.e.m., duração do benefício especial, tempo de duração do benefício especial, período do benefício especial, tempo de duração do benefício empregado, duração do benefício empregado, tempo de vigência do benefício empregado

### ENVIORESCISAOCONSIGNADO
- **Descrição:** Autorização de envio dos dados da rescisão do funcionário para o TOTVS Consignado - Funcionários
- **Sinônimos/variações:** autorização envio rescisão consignado, envio dados rescisão para consignado, autorização envio rescisão, envio rescisão para totvs consignado, autorização para envio de rescisão, envio rescisão consignado autorizado, autorização envio dados rescisão, envio rescisão para consignado, autorização para envio dos dados da rescisão, envio autorizado rescisão consignado, autorização para envio rescisão funcionário, envio rescisão funcionário para consignado, autorização envio rescisão totvs, envio rescisão para sistema consignado

### ESOCIALFUNCAOCONF
- **Descrição:** Indicativo de função de confiança/cargo em comissão - Funcionários
- **Sinônimos/variações:** função de confiança, cargo em comissão, indicativo função confiança, cargo comissionado, função comissionada, é função de confiança?, cargo de confiança, indicador função comissionada, função em comissão, cargo confiança, função especial, cargo comissionado indicado, função de confiança no esocial, cargo em comissão indicado

### ESOCIALNATATIVIDADE
- **Descrição:** Natureza da Atividade do eSocial - Funcionários
- **Sinônimos/variações:** natureza da atividade, tipo de atividade, atividade no esocial, natureza da função, classificação da atividade, qual natureza da atividade, categoria da atividade, tipo de trabalho, natureza do serviço, atividade exercida, natureza da ocupação, classificação da função, natureza da atividade profissional, tipo de atividade exercida

### ESUPERVISOR
- **Descrição:** Informa se o Funcionário é Supervisor - Funcionários
- **Sinônimos/variações:** é supervisor, funcionário supervisor, indicador supervisor, cargo de supervisor, é chefe?, é gestor?, funcionário é supervisor?, é responsável pela equipe, tem função de supervisão, cargo supervisor, é líder de equipe, tem cargo de chefia, é coordenador, é supervisor indicado

### EVTADIANTFERIAS
- **Descrição:** Evento de Adiantamento de Férias - Funcionários
- **Sinônimos/variações:** evento adiantamento férias, adiantamento de férias, evento de férias antecipadas, evento de adiantamento, adiantamento férias registrado, evento pagamento férias antecipadas, evento de adiantamento de férias, evento de férias adiantadas, evento para adiantamento férias, evento de pagamento antecipado de férias, evento de crédito de férias, evento de antecipação de férias, evento para adiantamento

### FALTAALTERFGTS
- **Descrição:** Envio de Informações para o FGTS - Funcionários
- **Sinônimos/variações:** envio informações fgts, falta envio fgts, informações fgts pendentes, envio dados fgts, envio para fgts, falta alterar fgts, pendência fgts, envio fgts pendente, dados fgts não enviados, envio fgts em atraso, informações fgts faltando, envio fgts incompleto, pendência no envio fgts, falta envio para fgts

### FERIASCOLETIVAS
- **Descrição:** Informa se o Funcionário possui Férias Coletivas
- **Sinônimos/variações:** possui férias coletivas, tem férias coletivas, férias coletivas indicadas, funcionário em férias coletivas, participa de férias coletivas, é férias coletiva?, está em férias coletivas, férias coletivas registradas, indicação de férias coletivas, férias coletivas confirmadas, férias coletivas aplicadas, tem direito a férias coletivas, férias coletivas ativas, férias coletivas atribuídas

### FERIASDIASUTEIS
- **Descrição:** Considera periodo de ferias com dias úteis - Funcionários
- **Sinônimos/variações:** considera dias úteis nas férias, férias com dias úteis, conta dias úteis nas férias, férias considerando dias úteis, férias com contagem de dias úteis, considera período útil nas férias, dias úteis para férias, férias com dias úteis contabilizados, consideração de dias úteis nas férias, férias com dias úteis incluídos, contabiliza dias úteis nas férias, férias com dias úteis considerados, considera dias úteis no período de férias

### FERIASFINALIZADASPROXMES
- **Descrição:** Férias finalizadas para o próximo mês - Funcionários
- **Sinônimos/variações:** férias finalizadas próximo mês, férias encerradas próximo mês, férias concluídas próximo mês, férias finalizadas para mês seguinte, férias encerradas para próximo mês, férias finalizadas mês que vem, férias finalizadas mês seguinte, férias concluídas para próximo mês, férias encerradas mês que vem, férias finalizadas no próximo mês, férias encerradas no mês seguinte, férias finalizadas para o próximo mês, férias concluídas mês seguinte, férias finalizadas mês futuro

### FERIASSALDODIASUTEIS
- **Descrição:** Saldo de férias para o periodo com dias úteis - Funcionários
- **Sinônimos/variações:** saldo férias dias úteis, saldo de férias com dias úteis, saldo de férias considerando dias úteis, saldo de férias úteis, saldo de férias em dias úteis, saldo de férias contabilizando dias úteis, saldo de férias com contagem de dias úteis, saldo de férias úteis disponíveis, saldo de férias com dias úteis incluídos, saldo de férias úteis restantes, saldo de férias com dias úteis considerados, saldo de férias úteis acumulados, saldo de férias com dias úteis ativos, saldo de férias úteis pendentes

### FGTSMESANTRECOLGRFP
- **Descrição:** Informa se o FGTS do mês anterior à Rescisão será Recolhido na GRFP - Funcionários
- **Sinônimos/variações:** fgts mês anterior recolhido na grfp, fgts mês anterior será recolhido, recolhimento fgts mês anterior na grfp, fgts do mês anterior à rescisão recolhido, fgts mês anterior recolhimento grfp, fgts mês anterior será pago na grfp, recolhimento fgts anterior na grfp, fgts mês anterior à rescisão será recolhido, fgts mês anterior recolhido via grfp, fgts mês anterior recolhimento confirmado, fgts mês anterior recolhimento garantido, fgts mês anterior recolhimento autorizado, fgts mês anterior recolhimento efetuado, fgts mês anterior recolhimento previsto

### FIMPRAZOCONTR
- **Descrição:** Data final do Prazo do Contrato - Funcionários
- **Sinônimos/variações:** data final prazo contrato, fim do contrato, data término contrato, data final do contrato, prazo final do contrato, quando termina o contrato, data de encerramento do contrato, data limite do contrato, data de validade do contrato, data final da vigência do contrato, data para término do contrato, data final do prazo contratual, data final do vínculo, data final do contrato de trabalho

### FIMPRAZOPRORROGCONTR
- **Descrição:** Data Final da Prorrogação do Contrato - Funcionários
- **Sinônimos/variações:** data final prorrogação contrato, fim da prorrogação do contrato, data término prorrogação, data final do prazo prorrogado, quando termina a prorrogação, data de encerramento da prorrogação, data limite da prorrogação, data final da vigência prorrogada, data para término da prorrogação, data final do contrato prorrogado, data final do prazo estendido, data final do vínculo prorrogado, data final da extensão do contrato, data final da prorrogação contratual

### FIMPROGFERIAS1
- **Descrição:** Data Fim do Programa de Férias ref. ao 1º Período de Gozo - Funcionários
- **Sinônimos/variações:** data fim programa férias 1º período, término do programa de férias 1º período, data final férias 1º período, fim do programa férias primeiro período, data término férias 1º período, quando termina o programa férias 1º período, data final do gozo férias 1º período, fim do gozo férias 1º período, data fim do programa férias inicial, término do gozo férias 1º período, data final do período de férias 1, fim do período de férias 1º, data final do programa férias inicial, data fim do gozo férias 1º período

### FIMPROGFERIAS2
- **Descrição:** Data Fim do Programa de Férias ref. ao 2º Período de Gozo - Não Mais Utilizado pelo Sistema - Funcionários
- **Sinônimos/variações:** data fim programa férias 2º período, término do programa de férias 2º período, data final férias 2º período, fim do programa férias segundo período, data término férias 2º período, quando termina o programa férias 2º período, data final do gozo férias 2º período, fim do gozo férias 2º período, data fim do programa férias secundário, término do gozo férias 2º período, data final do período de férias 2, fim do período de férias 2º, data final do programa férias secundário, data fim do gozo férias 2º período

### FORMAREDUCAOAVISO
- **Descrição:** Forma de redução do aviso: inicio ou fim - Funcionários
- **Sinônimos/variações:** forma de redução do aviso, redução do aviso início ou fim, como é a redução do aviso, redução aviso prévio, início ou fim da redução do aviso, tipo de redução do aviso, modo de redução do aviso, redução do aviso prévio, redução do aviso começa ou termina, forma de aplicar redução do aviso, redução do aviso prévio início/fim, como reduzir o aviso, redução do aviso prévio definida, redução do aviso prévio aplicada

### FUNCAOACUMULAVEL
- **Descrição:** Informar se o Cargo, Emprego ou Função Pública é acumulável - Funcionários
- **Sinônimos/variações:** função acumulável, cargo acumulável, emprego acumulável, função pública acumulável, cargo público acumulável, função pode ser acumulada, cargo pode ser acumulado, acumulação de função permitida, função acumulada, cargo acumulado, função pública pode acumular, acumulação de cargo permitida, função acumulável indicada, cargo acumulável indicado

### GRUPOSALARIAL
- **Descrição:** Faixa Salarial - Tabela de Origem: VFAIXASALARIAL - Funcionários
- **Sinônimos/variações:** faixa salarial, grupo salarial, categoria salarial, nível salarial, classe salarial, grupo de salário, faixa de salário, categoria de salário, nível de remuneração, grupo de remuneração, faixa de vencimento, grupo de vencimento, categoria de vencimento, nível de faixa salarial

### ID
- **Descrição:** Campo de identificador interno - Funcionários
- **Sinônimos/variações:** identificador interno, id do funcionário, código interno, identificação, número identificador, chave interna, código único, id único, identificador, código do registro, número de identificação, chave primária, id do registro, identificador do cadastro

### IDCLASSEVALOR
- **Descrição:** Identificador da Classe de Valor - Integração com Protheus - Funcionários
- **Sinônimos/variações:** identificador classe de valor, id da classe de valor, código classe valor, identificação classe valor, id para integração protheus, identificador valor classe, código da classe de valor, id classe valor integração, identificador para protheus, código para integração protheus, id classe valor, identificador classe valor funcionário, código classe valor funcionário, id classe valor sistema

### IDDADOSRESID
- **Descrição:** ID dados do Residente - Funcionários
- **Sinônimos/variações:** id dados residente, identificador dados residência, id endereço, identificação dados residenciais, código dados residência, id dados residenciais, identificador endereço, código endereço, id dados do residente, identificação do endereço, código do residente, id registro residência, identificador do endereço, id dados residência funcionário

### IDITEMCONTABIL
- **Descrição:** Identificador do Item Contábil - Tabela dinâmica: INTCONTFUN - Funcionários
- **Sinônimos/variações:** identificador item contábil, id item contábil, código item contábil, identificação item contábil, id para contabilidade, código do item contábil, identificador do lançamento contábil, id item contábil funcionário, código item contábil funcionário, identificação do item contábil, id registro contábil, código para contabilidade, identificador para contabilidade, id item contábil tabela intcontfun

### INDADMISSAO
- **Descrição:** Indicativo de Admissão - Funcionários
- **Sinônimos/variações:** indicativo de admissão, indicador admissão, status de admissão, flag de admissão, indica admissão, indicador de contratação, indicativo contratação, status contratação, flag admissão, indicação de admissão, indicador início vínculo, indicativo início contrato, status início trabalho, flag início admissão

### INDICADORSINDICALIZADO
- **Descrição:** Indicador de Sindicalizado - Funcionários
- **Sinônimos/variações:** indicador sindicalizado, é sindicalizado?, status sindicalizado, flag sindicalizado, indica sindicalização, indicativo de sindicalizado, indicador de filiação sindical, é filiado ao sindicato?, status de filiação sindical, flag de filiação sindical, indicação de sindicalização, indicador de associação sindical, é associado ao sindicato?, indicativo de sindicato

### INDICATIVOREMUNERACAOCARGO
- **Descrição:** Indicar se o Servidor optou pela remuneração do cargo efetivo - Funcionários
- **Sinônimos/variações:** indica remuneração do cargo, optou remuneração cargo, remuneração do cargo efetivo, indicador remuneração cargo, remuneração pelo cargo, opção remuneração cargo, indica pagamento pelo cargo, remuneração cargo escolhida, indicativo remuneração cargo, remuneração do cargo selecionada, opção de remuneração do cargo, indica escolha remuneração cargo, remuneração cargo efetivo, indicador opção remuneração cargo

### INDINICIOHOR
- **Descrição:** Índice de Início do Horário - Funcionários
- **Sinônimos/variações:** índice início do horário, início do horário, hora inicial, índice de início horário, marcação início horário, ponto inicial horário, hora de início, índice horário inicial, início da jornada, hora começo do turno, marcação inicial do horário, índice para início do horário, hora início expediente, ponto de início do horário

### INDPAGTOJUIZO
- **Descrição:** Indicativo de Pagamento em Juizo - Funcionários
- **Sinônimos/variações:** pagamento em juízo, indicativo pagamento judicial, pagamento judicial, valor pago em juízo, pagamento bloqueado judicialmente, pagamento sob ordem judicial, pagamento retido em juízo, pagamento judicializado, pagamento em processo judicial, pagamento em juízo do funcionário, indicador de pagamento judicial

### INDSIMPLES
- **Descrição:** Indicador de Contribuição Substituída - Funcionários
- **Sinônimos/variações:** contribuição substituída, indicador contribuição substituída, contribuição simplificada, contribuição substituída pelo simples, indicativo contribuição substituída, contribuição substituída funcionário, contribuição simplificada funcionário, indicador de contribuição simplificada, contribuição substituída indsimples

### INDSITREMUNAPOSDESLIG
- **Descrição:** Indicativo de Situação de Remuneração após o Desligamento - Funcionários
- **Sinônimos/variações:** situação remuneração após desligamento, indicativo remuneração pós-desligamento, remuneração após desligamento, pagamento após desligamento, situação de pagamento pós-desligamento, remuneração após saída, indicador remuneração após desligamento, situação de remuneração funcionário desligado, remuneração pós desligamento

### INFOONUSCESSAO
- **Descrição:** Ônus da cessão/requisição - Funcionários
- **Sinônimos/variações:** ônus da cessão, ônus da requisição, informação ônus cessão, ônus da cessão/requisição, ônus da transferência, ônus da cessão funcionário, ônus da requisição funcionário, informação sobre ônus, ônus da cessão ou requisição

### INICPROGFERIAS1
- **Descrição:** Data de Início do Programa de Férias - 1º Período de Gozo - Funcionários
- **Sinônimos/variações:** início programa férias 1º período, data início férias 1º período, data início programa férias primeiro período, início férias primeiro período, data início gozo férias 1º período, início gozo férias 1º período, programa férias 1º período início, data início férias período 1, início do programa de férias primeiro período

### INICPROGFERIAS2
- **Descrição:** Data de Início do Programa de Férias - 2º Período de Gozo - Não Mais Utilizado pelo Sistema - Funcionários
- **Sinônimos/variações:** início programa férias 2º período, data início férias 2º período, início gozo férias segundo período, data início programa férias segundo período, início férias segundo período, programa férias 2º período início, data início gozo férias 2º período, início do programa de férias segundo período, data início férias período 2

### INSCESTABELECIMENTOATIVPRATICA
- **Descrição:** Incrição do Estabelecimento de Atividades Práticas - Funcionários
- **Sinônimos/variações:** inscrição estabelecimento atividades práticas, registro estabelecimento atividades práticas, inscrição local atividades práticas, código estabelecimento atividades práticas, inscrição estabelecimento prática, registro local atividades práticas, inscrição estabelecimento funcionário, código estabelecimento prática, inscrição para atividades práticas

### INTEGRCONTABIL
- **Descrição:** Integração Contabil - Tabela dinâmica: INTCONTFUN - Funcionários
- **Sinônimos/variações:** integração contábil, integração contabilidade, integração contábil funcionário, dados integração contábil, integração contábil rm, integração contábil tabela dinâmica, integração contábil intcontfun, informação integração contábil, integração contábil sistema

### INTEGRGERENCIAL
- **Descrição:** Integracao Gerencial - Tabela dinâmica: INTGERFUNC - Funcionários
- **Sinônimos/variações:** integração gerencial, integração gerencial funcionário, dados integração gerencial, integração gerencial rm, integração gerencial tabela dinâmica, integração gerencial intgerfunc, informação integração gerencial, integração gerencial sistema, integração gerencial dados

### ISENTOIRRF
- **Descrição:** Isento IRRF - Funcionários
- **Sinônimos/variações:** isento irrf, isenção irrf, isento imposto renda retido na fonte, isenção imposto de renda, funcionário isento irrf, isento irrf funcionário, isento imposto renda, indicador isenção irrf, isento irrf no pagamento

### JORNADA
- **Descrição:** Jornada em Horas- Não Mais Utilizado pelo Sistema - Funcionários
- **Sinônimos/variações:** jornada em horas, horas trabalhadas, carga horária diária, tempo de trabalho diário, jornada diária, horas de trabalho, jornada funcionário, horas trabalhadas por dia, tempo jornada

### JORNADAMENSAL
- **Descrição:** Jornada Mensal de Trabalho em minutos - Funcionários
- **Sinônimos/variações:** jornada mensal em minutos, minutos trabalhados no mês, carga horária mensal, tempo mensal de trabalho, jornada mensal funcionário, minutos trabalhados mensalmente, total minutos mês, jornada mensal em minutos funcionário, tempo mensal jornada

### JUSTIFICATIVAPRORROGTEMP
- **Descrição:** Justificativa para a prorrogação do contrato de trabalho do funcionário temporário - Funcionários
- **Sinônimos/variações:** justificativa prorrogação contrato temporário, motivo prorrogação contrato temporário, justificativa extensão contrato temporário, motivo extensão contrato temporário, justificativa prorrogação trabalho temporário, motivo prorrogação trabalho temporário, justificativa para prorrogar contrato temporário, motivo para prorrogação contrato temporário, justificativa prorrogação temporário

### JUSTIFICATIVATRABTEMP
- **Descrição:** Justificativa para a contratação de trabalho temporário - Funcionários
- **Sinônimos/variações:** justificativa contratação trabalho temporário, motivo contratação temporário, justificativa trabalho temporário, motivo contratação trabalho temporário, justificativa para contratação temporária, motivo para contratação temporária, justificativa contratação temporário funcionário, motivo contratação temporário funcionário

### LOCALTRABCODMUNCIPIO
- **Descrição:** Local de Trabalho (Código Município) - Funcionários
- **Sinônimos/variações:** local de trabalho código município, código município local trabalho, local trabalho município, código município trabalho, local de trabalho município, código do município trabalho, local trabalho código município, município local trabalho, código município do local de trabalho

### MATRICULAANTERIOR
- **Descrição:** Matrícula anterior - Funcionários
- **Sinônimos/variações:** matrícula anterior, registro anterior, matrícula antiga, registro antigo, matrícula prévia, registro prévio, matrícula anterior funcionário, registro anterior funcionário, matrícula antiga funcionário

### MATRICULABENEFICIARIO
- **Descrição:** Matrícula de Beneficiário - Funcionários
- **Sinônimos/variações:** matrícula beneficiário, registro beneficiário, matrícula do beneficiário, registro do beneficiário, matrícula funcionário beneficiário, registro funcionário beneficiário, matrícula do dependente, registro do dependente, matrícula beneficiário funcionário

### MATRICULACEDENTE
- **Descrição:** Matrícula do trabalhador no empregador de origem (Cedente) - Funcionários
- **Sinônimos/variações:** matrícula cedente, registro cedente, matrícula trabalhador cedente, registro trabalhador cedente, matrícula empregador de origem, registro empregador de origem, matrícula cedente funcionário, registro cedente funcionário, matrícula do cedente

### MATRICULAEMPRESAORIGEM
- **Descrição:** Matrícula do Trabalhador na Empresa de Origem - Funcionários
- **Sinônimos/variações:** matrícula empresa de origem, registro empresa origem, matrícula trabalhador empresa origem, registro trabalhador empresa origem, matrícula na empresa de origem, registro na empresa de origem, matrícula funcionário empresa origem, registro funcionário empresa origem, matrícula empresa origem

### MATRICULAESOCIAL
- **Descrição:** Matrícula do trabalhador no eSocial - Funcionários
- **Sinônimos/variações:** matrícula esocial, registro esocial, matrícula no esocial, registro no esocial, matrícula funcionário esocial, registro funcionário esocial, matrícula sistema esocial, registro sistema esocial, matrícula esocial funcionário

### MATRICULAMANDATOELETIVO
- **Descrição:** Matrícula do servidor no orgão público de origem com mandato eletivo - Funcionários
- **Sinônimos/variações:** matrícula mandato eletivo, registro mandato eletivo, matrícula servidor mandato eletivo, registro servidor mandato eletivo, matrícula órgão público mandato eletivo, registro órgão público mandato eletivo, matrícula servidor público mandato, registro servidor público mandato, matrícula mandato eletivo funcionário

### MEDIASALMATERN
- **Descrição:** Média de Salário Maternidade - Funcionários
- **Sinônimos/variações:** média salário maternidade, média salário maternidade funcionário, média salário maternidade pago, valor médio salário maternidade, média remuneração maternidade, média salário licença maternidade, média pagamento maternidade, média salário maternidade mensal, média salário maternidade recebido

### MEMBROCIPA
- **Descrição:** Indica se o Funcionário é Membro da Cipa
- **Sinônimos/variações:** membro da cipa, participante da cipa, funcionário membro cipa, indica membro cipa, participação na cipa, membro comissão cipa, funcionário na cipa, indicação de membro cipa, membro da comissão interna

### MEMBROSINDICAL
- **Descrição:** Indica se o Funcionário é Membro Sindical
- **Sinônimos/variações:** membro sindical, participante sindicato, funcionário membro sindicato, indica membro sindicato, participação sindical, membro do sindicato, funcionário sindicalizado, indicação de membro sindical, membro da entidade sindical

### MESCOMPTRANSF
- **Descrição:** Mês da Competência durante transferência - Funcionários
- **Sinônimos/variações:** mês da competência transferência, mês competência transferência, mês competência durante transferência, mês competência funcionário transferido, mês competência transferência funcionário, mês competência transferência trabalho, mês competência transferência dados, mês competência transferência registro

### MESESDISSIDIOCOLETIVO
- **Descrição:** Meses de Dissídio Coletivo - Funcionários
- **Sinônimos/variações:** meses de dissídio coletivo, duração dissídio coletivo em meses, meses com dissídio coletivo, tempo dissídio coletivo meses, meses aplicados dissídio coletivo, meses referente a dissídio coletivo, meses dissídio coletivo funcionário, meses dissídio coletivo contrato, meses dissídio coletivo vigência

### MESESGRATIFICACAO
- **Descrição:** Meses de Gratificação - Funcionários
- **Sinônimos/variações:** meses de gratificação, duração gratificação em meses, meses com gratificação, tempo gratificação meses, meses recebendo gratificação, meses referente a gratificação, meses gratificação funcionário, meses gratificação contrato, meses vigência gratificação

### MESESHORAEXTRAS
- **Descrição:** Meses de Horas Extras - Funcionários
- **Sinônimos/variações:** meses de horas extras, duração horas extras em meses, meses com horas extras, tempo horas extras meses, meses recebendo horas extras, meses referente a horas extras, meses horas extras funcionário, meses horas extras contrato, meses vigência horas extras

### MODALIDADECONTRATACAO
- **Descrição:** Modalidade de Contratação - Funcionários
- **Sinônimos/variações:** modalidade de contratação, tipo de contratação, forma de contratação, modalidade contrato, tipo contrato, forma contrato, modalidade contratação funcionário, tipo contratação funcionário, forma contratação funcionário

### MOTIVOADMISSAO
- **Descrição:** Motivo de Admissão - Tabela Dinâmica: INT22 - Funcionários
- **Sinônimos/variações:** motivo de admissão, razão admissão, justificativa admissão, motivo contratação, razão contratação, justificativa contratação, motivo ingresso, razão ingresso, motivo admissão funcionário

### MOTIVOAVISOPREVIOTRAB
- **Descrição:** Motivo do Aviso Prévio Trabalhado - Tabela Dinâmica: INT28 - Funcionários
- **Sinônimos/variações:** motivo aviso prévio trabalhado, razão do aviso prévio trabalhado, causa do aviso prévio, motivo do aviso prévio, justificativa do aviso prévio trabalhado, por que houve aviso prévio trabalhado, motivo do aviso prévio na rescisão, motivo do aviso prévio cumprido, motivo do aviso prévio pelo funcionário, motivo do aviso prévio pelo empregador

### MOTIVOCANCELAMENTOAVISO
- **Descrição:** Motivo cancelamento do Aviso Prévio - Funcionários
- **Sinônimos/variações:** motivo cancelamento do aviso prévio, razão do cancelamento do aviso, causa do cancelamento do aviso prévio, por que cancelou o aviso prévio, motivo para cancelar aviso prévio, justificativa do cancelamento do aviso, motivo do cancelamento do aviso prévio trabalhado, motivo do cancelamento do aviso prévio pelo funcionário, motivo do cancelamento do aviso prévio pelo empregador

### MOTIVOCONTPRAZODETERMINADO
- **Descrição:** Motivo da contratação por prazo determinado - Funcionários
- **Sinônimos/variações:** motivo contratação prazo determinado, razão da contratação temporária, causa da contratação por tempo determinado, por que contratação por prazo determinado, motivo do contrato temporário, justificativa da contratação por prazo, motivo da contratação com prazo fixo, motivo do contrato por prazo determinado

### MOTIVODEMISSAO
- **Descrição:** Motivo de Demissão - Tabela Dinâmica: INT23 - Funcionários
- **Sinônimos/variações:** motivo da demissão, razão da demissão, causa da demissão, por que o funcionário foi demitido, motivo do desligamento, justificativa da demissão, motivo da rescisão, motivo do término do contrato, motivo da saída do funcionário

### MOTIVOSAIDATRANSFERENCIA
- **Descrição:** Motivo da saída por transferência - Funcionários
- **Sinônimos/variações:** motivo saída por transferência, razão da saída por transferência, causa da transferência, por que saiu por transferência, motivo da mudança por transferência, justificativa da saída por transferência, motivo da transferência do funcionário, motivo da saída para outra unidade

### MOTIVOTRABTEMP
- **Descrição:** Motivo de Contratação do Trabalhador Temporário - Funcionários
- **Sinônimos/variações:** motivo contratação trabalhador temporário, razão da contratação temporária, causa da contratação temporária, por que contratação temporária, motivo do trabalho temporário, justificativa da contratação temporária, motivo do contrato temporário, motivo da contratação de temporário

### MOTIVOTRANSFERENCIA
- **Descrição:** Motivo da transferência - Funcionários
- **Sinônimos/variações:** motivo da transferência, razão da transferência, causa da transferência, por que houve transferência, motivo da mudança de setor, justificativa da transferência, motivo da transferência interna, motivo da movimentação do funcionário

### MUDOUADMISSAO
- **Descrição:** Infoma se o Funcionário mudou a data de Admissão
- **Sinônimos/variações:** mudou data de admissão, alterou data de admissão, modificou data de admissão, houve mudança na admissão, data de admissão alterada, mudança na data de contratação, alteração na data de ingresso, mudança na admissão do funcionário

### MUDOUCARTTRAB
- **Descrição:** Informa se o Funcionário mudou o número da Carteira de Trabalho
- **Sinônimos/variações:** mudou número da carteira de trabalho, alterou carteira de trabalho, modificou número da ctps, mudança na carteira de trabalho, alteração no número da ctps, mudou dados da carteira de trabalho, mudança no registro da carteira, alteração na carteira profissional

### MUDOUCHAPA
- **Descrição:** Informa se o Funcionário  mudou a Chapa - Funcionários
- **Sinônimos/variações:** mudou chapa, alterou número da chapa, modificou chapa do funcionário, mudança na chapa, alteração do código da chapa, mudou identificação da chapa, mudança no número da chapa, alteração do registro da chapa

### MUDOUCI
- **Descrição:** Informa se o Funcionário mudou o Código de Contribuinte Individual
- **Sinônimos/variações:** mudou código de contribuinte individual, alterou código ci, modificou código de contribuinte, mudança no código de contribuinte individual, alteração no código ci, mudou registro de contribuinte, mudança no código do trabalhador, alteração no código individual

### MUDOUDTNASCIM
- **Descrição:** Informa se o Funcionário mudou a Data de Nascimento
- **Sinônimos/variações:** mudou data de nascimento, alterou data de nascimento, modificou nascimento, mudança na data de nascimento, alteração da data de nascimento, mudou aniversário, mudança no nascimento do funcionário, alteração na data de nascimento

### MUDOUDTOPCAO
- **Descrição:** Informa se o Funcionário mudou a data de Opção
- **Sinônimos/variações:** mudou data de opção, alterou data de opção, modificou data de opção, mudança na data de opção, alteração da data de opção, mudou data de escolha, mudança na data de opção do funcionário, alteração na data de opção

### MUDOUENDERECO
- **Descrição:** Informa se o Funcionário mudou de Endereço
- **Sinônimos/variações:** mudou endereço, alterou endereço, modificou endereço residencial, mudança de endereço, alteração do endereço, mudou local de residência, mudança no endereço do funcionário, alteração no endereço cadastrado

### MUDOUNOME
- **Descrição:** Informa se o Funcionário mudou o Nome
- **Sinônimos/variações:** mudou nome, alterou nome, modificou nome do funcionário, mudança no nome, alteração do nome, mudou nome completo, mudança no nome cadastrado, alteração no nome do colaborador

### MUDOUPIS
- **Descrição:** Informa se o Funcionário mudou o número do PIS - Funcionários
- **Sinônimos/variações:** mudou número do pis, alterou número do pis, modificou pis, mudança no número do pis, alteração do número do pis, mudou registro do pis, mudança no pis do funcionário, alteração no número do pis

### MUDOUSECAO
- **Descrição:** Informa se o Funcionário Mudou de Seção - Funcionários
- **Sinônimos/variações:** mudou seção, alterou seção, modificou seção do funcionário, mudança na seção, alteração da seção, mudou departamento, mudança na área de trabalho, alteração na seção do colaborador

### NAOCALCULARECIBOFERIAS
- **Descrição:** Indicativo para não calcular o Recibo de Férias, e fazer somente o controle cadastral. - Funcionários
- **Sinônimos/variações:** não calcular recibo de férias, indicativo para não calcular férias, não gerar recibo de férias, controle cadastral de férias, não processar recibo de férias, não calcular pagamento de férias, não emitir recibo de férias, controle sem cálculo de férias, não calcular férias para o funcionário

### NATUREZAESTAGIO
- **Descrição:** Natureza do Estágio - Funcionários
- **Sinônimos/variações:** natureza do estágio, tipo de estágio, categoria do estágio, classificação do estágio, modalidade do estágio, característica do estágio, natureza da atividade de estágio, tipo de vínculo de estágio

### NDIASLICREM1
- **Descrição:** Número de Dias de Licença Remunerada - Funcionários
- **Sinônimos/variações:** número de dias de licença remunerada, quantidade de dias licença remunerada, dias de licença com remuneração, total de dias licença remunerada, dias de afastamento remunerado, dias de licença paga, número de dias afastamento remunerado, dias de licença remunerada 1

### NDIASLICREM2
- **Descrição:** Número de Dias de Licença Remunerada 2 - Funcionários
- **Sinônimos/variações:** número de dias de licença remunerada 2, quantidade de dias licença remunerada 2, dias de licença com remuneração 2, total de dias licença remunerada 2, dias de afastamento remunerado 2, dias de licença paga 2, número de dias afastamento remunerado 2, dias de licença remunerada adicional

### NOME
- **Descrição:** Nome do Funcionário
- **Sinônimos/variações:** nome do funcionário, nome completo, nome do colaborador, nome do empregado, nome do trabalhador, nome cadastrado, nome do profissional, nome registrado, nome do usuário

### NOMECOORDENADORESTAGIO
- **Descrição:** Nome do Coordenador do Estágio - Funcionários
- **Sinônimos/variações:** nome do coordenador do estágio, nome do supervisor do estágio, nome do responsável pelo estágio, nome do gestor do estágio, nome do orientador do estágio, nome do líder do estágio, nome do coordenador responsável, nome do coordenador do programa de estágio

### NROATESTADOOBITO
- **Descrição:** Número que identifica o registro do Atestado de Óbito - Funcionários
- **Sinônimos/variações:** número do atestado de óbito, registro do atestado de óbito, identificação do atestado de óbito, número do documento de óbito, registro do documento de óbito, identificador do atestado de óbito, número do comprovante de óbito, registro do atestado de falecimento

### NRODEPIRRF
- **Descrição:** Número de Dependentes de IRRF - Funcionários
- **Sinônimos/variações:** número de dependentes irrf, quantidade de dependentes para irrf, número de dependentes para imposto de renda, dependentes para irrf, número de dependentes tributários, quantidade de dependentes irrf, número de dependentes para retenção irrf, dependentes para imposto de renda retido na fonte

### NRODEPSALFAM
- **Descrição:** Número de Dependentes de Salário Família - Funcionários
- **Sinônimos/variações:** número de dependentes salário família, quantidade de dependentes para salário família, dependentes para salário família, número de dependentes para benefício salário família, quantidade de dependentes salário família, número de dependentes para auxílio família, dependentes para benefício salário família, número de dependentes para salário-família

### NRODIASABONO
- **Descrição:** Número de Dias de Abono - Funcionários
- **Sinônimos/variações:** número de dias de abono, quantidade de dias de abono, dias de abono concedidos, total de dias de abono, dias de abono salarial, número de dias de abono remunerado, dias de abono para o funcionário, quantidade de dias de abono salarial

### NRODIASABONOCORRIDOS
- **Descrição:** Número de dias corridos do abono - Funcionários
- **Sinônimos/variações:** número de dias corridos do abono, dias corridos de abono, quantidade de dias corridos de abono, total de dias corridos de abono, dias corridos do abono salarial, número de dias corridos para abono, dias corridos de abono concedidos, quantidade de dias corridos para abono

### NRODIASADIANTFER
- **Descrição:** Número de Dias de Adiantamento de Férias - Funcionários
- **Sinônimos/variações:** número de dias de adiantamento de férias, quantidade de dias adiantados de férias, dias de férias adiantados, total de dias de adiantamento de férias, dias antecipados de férias, número de dias antecipados de férias, dias de férias pagos antecipadamente, quantidade de dias de férias adiantadas

### NRODIASAVISO
- **Descrição:** Número de Dias para Aviso - Funcionários
- **Sinônimos/variações:** número de dias para aviso, quantidade de dias de aviso, dias para aviso prévio, total de dias de aviso, dias de aviso prévio, número de dias do aviso prévio, prazo em dias para aviso, quantidade de dias para aviso prévio

### NRODIASFERIAS
- **Descrição:** Número de Dias de Férias - Funcionários
- **Sinônimos/variações:** dias de férias, número de dias de férias, quantidade de dias de férias, total de dias de férias, dias disponíveis de férias, dias para férias, dias de descanso, período de férias, dias de licença, quantidade de dias de descanso, dias de férias do funcionário, dias de férias acumulados, dias de férias concedidos, dias de férias registrados

### NRODIASFERIASCORRIDOS
- **Descrição:** Números de dias corridos das férias - Funcionários
- **Sinônimos/variações:** dias corridos de férias, número de dias corridos de férias, quantidade de dias corridos de férias, total de dias corridos de férias, dias corridos para férias, dias corridos de descanso, período corrido de férias, dias corridos acumulados, dias corridos concedidos, dias corridos registrados, dias corridos do funcionário, dias corridos de licença, dias corridos no período de férias

### NRODIASFERIASJORNRED
- **Descrição:** Dias de férias devido à jornada reduzida - Funcionários
- **Sinônimos/variações:** dias de férias jornada reduzida, número de dias férias jornada reduzida, dias de férias por jornada reduzida, quantidade de dias férias jornada reduzida, dias de férias proporcional jornada reduzida, dias de férias para jornada reduzida, dias de férias reduzidos, dias de férias jornada parcial, dias de férias jornada menor, dias de férias jornada reduzida do funcionário, dias de férias jornada especial, dias de férias jornada limitada

### NROFICHAREG
- **Descrição:** Número da Ficha de Registro - Funcionários
- **Sinônimos/variações:** número da ficha de registro, número da ficha, registro do funcionário, número do registro, identificação da ficha, código da ficha de registro, número da carteira de registro, número da ficha funcional, registro funcional, número da ficha do empregado, número da ficha cadastral, número da ficha trabalhista

### NROINSCRITEMP
- **Descrição:** Número de Inscrição Trabalhador Substituído - Funcionários
- **Sinônimos/variações:** número de inscrição trabalhador substituído, número inscrição substituído, inscrição do trabalhador substituído, registro do trabalhador substituído, número do substituído, inscrição empregado substituído, número de registro do substituído, identificação do trabalhador substituído, número de inscrição do empregado substituído, registro do substituído, número de inscrição temporária

### NROLEIANISTIA
- **Descrição:** Número da Lei de Anistia - Funcionários
- **Sinônimos/variações:** número da lei de anistia, identificação da lei de anistia, número da legislação de anistia, código da lei de anistia, referência da lei de anistia, número da norma de anistia, número do ato de anistia, número do decreto de anistia, número do processo de anistia, número da portaria de anistia

### NROPERIODOTRANSF
- **Descrição:** Número do Período durante transferência - Funcionários
- **Sinônimos/variações:** número do período de transferência, identificação do período de transferência, número do período durante transferência, período de transferência, número do ciclo de transferência, número do intervalo de transferência, número do tempo de transferência, número do estágio de transferência, número do prazo de transferência, número do período trabalhado na transferência

### NROPROCESSOJUDICIAL
- **Descrição:** Número do Processo Judicial - Funcionários
- **Sinônimos/variações:** número do processo judicial, identificação do processo judicial, número do processo na justiça, número do processo legal, número do processo trabalhista judicial, número do processo judicial do funcionário, número do processo em tribunal, número do processo em justiça, número do processo judicial ativo, número do processo judicial registrado

### NROPROCESSOTRAB
- **Descrição:** Número que identifica o processo trabalhista - Funcionários
- **Sinônimos/variações:** número do processo trabalhista, identificação do processo trabalhista, número do processo trabalhista do funcionário, número do processo trabalhista ativo, número do processo trabalhista judicial, número do processo trabalhista registrado, número do processo trabalhista em tribunal, número do processo trabalhista legal, número do processo trabalhista em justiça

### NROPROCESSOTRABADMISSAO
- **Descrição:** Número que identifica o processo trabalhista, quando a admissão se der por decisão judicial - Funcionários
- **Sinônimos/variações:** número do processo trabalhista por admissão judicial, número do processo trabalhista admissão judicial, identificação do processo trabalhista admissão judicial, número do processo trabalhista com admissão judicial, número do processo trabalhista decisão judicial admissão, número do processo trabalhista admissão por decisão judicial, número do processo trabalhista admissão judicial do funcionário, número do processo trabalhista admissão judicial registrada, número do processo trabalhista admissão judicial ativa

### NRPROCJUD
- **Descrição:** Preencher com o número do processo judicial - Funcionários
- **Sinônimos/variações:** número do processo judicial, identificação do processo judicial, número do processo na justiça, número do processo legal, número do processo judicial do funcionário, número do processo judicial ativo, número do processo judicial registrado, número do processo judicial em tribunal, número do processo judicial em justiça

### NUMEROAPOLICEESTAGIO
- **Descrição:** Nr. Apólice de Seguro - Funcionários
- **Sinônimos/variações:** número da apólice de seguro, número da apólice, identificação da apólice de seguro, número do seguro, número da apólice do funcionário, número da apólice de estágio, número do contrato de seguro, número da apólice registrada, número da apólice vigente, número da apólice de proteção

### NUMEROCARTAOSUS
- **Descrição:** Número do Cartão SUS - Funcionários
- **Sinônimos/variações:** número do cartão sus, identificação do cartão sus, número do cartão do sistema único de saúde, número do cartão de saúde, número do cartão sus do funcionário, número do cartão sus registrado, número do cartão sus ativo, número do cartão sus válido, número do cartão sus oficial

### NUMVEZESDESCEMPRESTIMO
- **Descrição:** Nº de vezes para Desconto do Empréstimo nas Férias - Funcionários
- **Sinônimos/variações:** número de vezes para desconto do empréstimo, quantidade de descontos do empréstimo, número de parcelas para desconto do empréstimo, número de vezes desconto empréstimo férias, quantidade de vezes desconto empréstimo, número de descontos para empréstimo, número de vezes para desconto em folha, número de vezes desconto empréstimo funcionário, número de vezes desconto empréstimo registrado

### OBSCANCELAMENTOAVISO
- **Descrição:** Observação cancelamento Aviso Prévio - Funcionários
- **Sinônimos/variações:** observação cancelamento aviso prévio, nota sobre cancelamento do aviso prévio, comentário cancelamento aviso prévio, descrição do cancelamento do aviso prévio, observação sobre cancelamento do aviso, informação cancelamento aviso prévio, detalhes do cancelamento do aviso prévio, observação cancelamento aviso, anotação cancelamento aviso prévio

### OBSERVACAOAVISOPREVIO
- **Descrição:** Observação do aviso prévio - Funcionários
- **Sinônimos/variações:** observação do aviso prévio, nota sobre aviso prévio, comentário do aviso prévio, descrição do aviso prévio, informação do aviso prévio, detalhes do aviso prévio, observação sobre aviso prévio, anotação do aviso prévio, observação aviso

### OBSERVACAORESCISAO
- **Descrição:** Observação sobre o desligamento do trabalhador - Funcionários
- **Sinônimos/variações:** observação sobre rescisão, nota sobre desligamento, comentário da rescisão, descrição da rescisão, informação sobre desligamento, detalhes da rescisão, observação do desligamento, anotação da rescisão, observação sobre término de contrato

### OBSERVACAOSUCESSAO
- **Descrição:** Observação da sucessão - Funcionários
- **Sinônimos/variações:** observação da sucessão, nota sobre sucessão, comentário da sucessão, descrição da sucessão, informação sobre sucessão, detalhes da sucessão, observação sobre transferência, anotação da sucessão, observação sobre continuidade

### OBSFERIAS
- **Descrição:** Observação de Férias - Funcionários
- **Sinônimos/variações:** observação de férias, nota sobre férias, comentário de férias, descrição das férias, informação sobre férias, detalhes das férias, observação sobre período de férias, anotação de férias, observação sobre descanso

### OPBANCARIA
- **Descrição:** Operação Bancária - Funcionários
- **Sinônimos/variações:** operação bancária, tipo de operação bancária, código da operação bancária, transação bancária, operação financeira bancária, operação bancária principal, operação bancária do funcionário, operação bancária registrada, operação bancária ativa

### OPBANCARIA2
- **Descrição:** 2ª Operação bancária - Funcionários
- **Sinônimos/variações:** segunda operação bancária, 2ª operação bancária, operação bancária adicional, operação bancária secundária, operação bancária complementar, operação bancária extra, operação bancária do funcionário 2, operação bancária registrada 2, operação bancária alternativa

### PERCENTADIANT
- **Descrição:** Percentual de Adiantamento - Funcionários
- **Sinônimos/variações:** percentual de adiantamento, porcentagem de adiantamento, percentual de adiantamento salarial, percentual de adiantamento do salário, percentual de adiantamento do funcionário, percentual de adiantamento registrado, porcentagem de adiantamento salarial, percentual de adiantamento concedido, percentual de adiantamento autorizado

### PERCENTUALREDUCAOBEM
- **Descrição:** Percentual de Redução B.E.M. - Funcionários
- **Sinônimos/variações:** percentual de redução b.e.m., porcentagem de redução b.e.m., percentual de redução do benefício, percentual de redução do bem, percentual de desconto b.e.m., percentual de redução concedida, percentual de redução aplicada, percentual de redução autorizada, percentual de redução do funcionário

### PERIODORESCISAO
- **Descrição:** Período da Rescisao - Funcionários
- **Sinônimos/variações:** período da rescisão, intervalo da rescisão, tempo da rescisão, período do desligamento, período do término do contrato, período de encerramento, período de finalização do contrato, período da rescisão contratual, período do afastamento

### PISPARAFGTS
- **Descrição:** PIS para FGTS - Funcionários
- **Sinônimos/variações:** pis para fgts, número do pis para fgts, identificação do pis para fgts, código pis para fgts, número do pis fgts, registro pis para fgts, número do pis para fundo de garantia, número do pis fgts do funcionário, número do pis para fgts registrado

### PISPASEP
- **Descrição:** Nº do PIS/PASEP - Funcionários
- **Sinônimos/variações:** número do pis/pasep, identificação do pis/pasep, número do pis, número do pasep, registro pis/pasep, número do pis ou pasep, número do pis/pasep do funcionário, número do pis/pasep registrado, número do pis/pasep ativo

### POSICAOABONO
- **Descrição:** Posição do abono - Funcionários
- **Sinônimos/variações:** posição do abono, status do abono, situação do abono, posição do abono salarial, posição do abono do funcionário, posição do abono registrado, posição do abono concedido, posição do abono autorizado, posição do abono atual

### POSSUIALVARAMENOR16
- **Descrição:** Tem alvará judicial p/func menor 16 anos - Funcionários
- **Sinônimos/variações:** tem alvará judicial para menor de 16 anos, possui alvará para menor de 16 anos, alvará judicial para funcionário menor de 16, alvará para menor de 16 anos, existe alvará judicial menor 16 anos, tem autorização judicial para menor de 16, possui autorização para menor de 16 anos, tem alvará judicial ativo menor 16 anos, alvará judicial válido para menor de 16 anos

### PREFIXOPERIODOESOCIAL
- **Descrição:** Prefixo Periodo para o eSocial - Funcionários
- **Sinônimos/variações:** prefixo do período para esocial, código do período para esocial, identificação do período para esocial, prefixo do período esocial, prefixo para envio ao esocial, prefixo do período trabalhado esocial, prefixo do período cadastrado esocial, prefixo do período informado esocial, prefixo do período registrado esocial

### PREVDISP
- **Descrição:** Previsão de Disponibilidade - Funcionários
- **Sinônimos/variações:** previsão de disponibilidade, data prevista de disponibilidade, previsão para disponibilidade, previsão de liberação, previsão de disponibilidade do funcionário, data prevista para disponibilidade, previsão de disponibilidade registrada, previsão de disponibilidade atual, previsão de disponibilidade futura

### QUER1APARC13O
- **Descrição:** Informa se o Funcionário solicitou 1ª Parcela de 13º nas Férias
- **Sinônimos/variações:** 1ª parcela 13º nas férias, primeira parcela do décimo terceiro, solicitação 1ª parcela 13º, pedido 13º nas férias, quer 1ª parcela do 13º, recebe 1ª parcela do décimo terceiro, 13º antecipado nas férias, 13º nas férias solicitado, 1ª parcela do 13º salário nas férias, quer receber 13º nas férias

### QUERABONO
- **Descrição:** Indicativo de Abono - Funcionários
- **Sinônimos/variações:** quer abono, solicitação de abono, indicativo de abono, abono salarial, quer receber abono, pedido de abono, tem direito a abono, abono para funcionário, abono solicitado, abono ativo

### QUERADIANTAMENTO
- **Descrição:** Quer adiantamento nas férias - Funcionários
- **Sinônimos/variações:** quer adiantamento nas férias, pedido de adiantamento férias, solicitação adiantamento férias, adiantamento nas férias, quer receber adiantamento férias, adiantamento férias solicitado, adiantamento férias ativo, deseja adiantamento férias, adiantamento férias funcionário, adiantamento férias pedido

### RECCREATEDBY
- **Descrição:** Usuário criador do registro - Funcionários
- **Sinônimos/variações:** usuário criador do registro, quem criou o registro, registro criado por, autor da criação, criador do cadastro, responsável pela criação, usuário que criou, registro criado por usuário, quem registrou, criador do registro

### RECCREATEDON
- **Descrição:** Data de criação do registro - Funcionários
- **Sinônimos/variações:** data de criação do registro, quando foi criado o registro, data do cadastro, registro criado em, data de inclusão, data do registro, data de criação, data do cadastro do funcionário, registro criado na data, data inicial do registro

### RECEBSEGDESEMP
- **Descrição:** Estava recebendo seguro desemprego - Funcionários
- **Sinônimos/variações:** recebia seguro desemprego, estava recebendo seguro desemprego, recebimento seguro desemprego, seguro desemprego ativo, benefício seguro desemprego, recebe seguro desemprego, seguro desemprego funcionário, recebimento do seguro desemprego, seguro desemprego em vigência, recebendo seguro desemprego

### RECMODIFIEDBY
- **Descrição:** Autor da última modificação no registro - Funcionários
- **Sinônimos/variações:** autor da última modificação, quem modificou o registro, última alteração feita por, modificado por usuário, responsável pela última modificação, usuário que alterou, último editor do registro, modificador do registro, registro alterado por, quem atualizou o registro

### RECMODIFIEDON
- **Descrição:** Data da última modificação no registro - Funcionários
- **Sinônimos/variações:** data da última modificação, quando foi alterado o registro, data da última alteração, registro modificado em, data da atualização, data da modificação, última data de alteração, registro atualizado em, data da última edição, data da última atualização

### REGATUAL
- **Descrição:** Informa se é o Registro Atual - Funcionários
- **Sinônimos/variações:** registro atual, é o registro vigente, registro em vigor, registro ativo, registro principal, registro válido, registro corrente, registro em uso, registro atualizado, registro definitivo

### REGIMEREVEZAMENTO
- **Descrição:** Regime de Revezamento - Funcionários
- **Sinônimos/variações:** regime de revezamento, tipo de revezamento, modalidade de revezamento, escala de revezamento, sistema de revezamento, turno de revezamento, regime de trabalho revezamento, revezamento de funcionários, regime de rodízio, revezamento na função

### REPOEVAGA
- **Descrição:** Informa se haverá reposição de Vaga na cadeira de Rescisão - Funcionários
- **Sinônimos/variações:** haverá reposição de vaga, reposição de vaga na rescisão, vaga será reposta, substituição de vaga, vaga na rescisão será preenchida, repõe vaga na rescisão, vaga reposta após rescisão, reposição de funcionário, vaga substituída, vaga reposta

### RESCISAOCALCULADA
- **Descrição:** Informa se a Rescisão foi calculada - Funcionários
- **Sinônimos/variações:** rescisão calculada, rescisão já calculada, cálculo da rescisão feito, rescisão processada, rescisão concluída, rescisão finalizada, rescisão apurada, rescisão computada, rescisão realizada, rescisão pronta

### RESCISAOPRECISARECALC
- **Descrição:** Informa se a Rescisão precisa de Recálculo - Funcionários
- **Sinônimos/variações:** rescisão precisa de recálculo, necessita recálculo da rescisão, rescisão a recalcular, rescisão com recálculo pendente, recalcular rescisão, rescisão necessita revisão, rescisão em revisão, rescisão com ajuste necessário, rescisão para recalcular, rescisão com erro para corrigir

### RESIDENCIAPROPRIA
- **Descrição:** Indicar se a residência pertence ao trabalhador - Funcionários
- **Sinônimos/variações:** residência própria, moradia do trabalhador, casa própria, imóvel próprio, residência do funcionário, moradia própria, habitação própria, residência pertencente ao trabalhador, moradia em nome do funcionário, imóvel do trabalhador

### RESIDENCIARECURSOSFGTS
- **Descrição:** Indicar se foi adquirido o imóvel próprio foi adquirido com recursos do FGTS - Funcionários
- **Sinônimos/variações:** imóvel adquirido com fgts, residência com recursos do fgts, compra de imóvel com fgts, financiamento fgts para imóvel, uso do fgts na residência, imóvel financiado pelo fgts, aquisição de imóvel via fgts, moradia com fgts, imóvel próprio com fgts, residência financiada com fgts

### SALARIO
- **Descrição:** Salário - Funcionários
- **Sinônimos/variações:** salário, remuneração, pagamento mensal, vencimento, provento, salário base, rendimento mensal, salário bruto, salário líquido, valor do salário, salário do funcionário, salário mensal, remuneração mensal, pagamento do colaborador

### SALDOFERANTAUX
- **Descrição:** Saldo de Férias Anterior Auxiliar - Funcionários
- **Sinônimos/variações:** saldo de férias anterior auxiliar, saldo férias auxiliar, férias anteriores auxiliar, saldo de férias prévio auxiliar, férias acumuladas auxiliar, saldo férias auxiliar anterior, saldo férias auxiliar prévio, saldo de férias auxiliar, férias pendentes auxiliar, saldo de férias auxiliar funcionário

### SALDOFERIAS
- **Descrição:** Saldo de Férias - Funcionários
- **Sinônimos/variações:** saldo de férias, férias disponíveis, dias de férias restantes, saldo de dias de férias, férias acumuladas, saldo férias atual, férias pendentes, dias de férias a usufruir, saldo de férias do funcionário, saldo de férias vigente

### SALDOFERIASANT
- **Descrição:** Saldo de Férias Anterior - Funcionários
- **Sinônimos/variações:** saldo de férias anterior, férias acumuladas anteriores, saldo férias prévio, férias pendentes anteriores, saldo de férias passado, saldo férias anterior ao atual, férias anteriores acumuladas, saldo férias anterior funcionário, saldo férias prévio funcionário, saldo de férias anterior ao período

### SALDOFGTS
- **Descrição:** Saldo do Fgts - Funcionários
- **Sinônimos/variações:** saldo do fgts, valor do fgts, saldo disponível fgts, fundos fgts, saldo conta fgts, saldo fgts do funcionário, saldo acumulado fgts, saldo fgts atual, saldo fgts bruto, saldo fgts líquido

### SALDOFGTSREAL
- **Descrição:** Saldo FGTS Real - Funcionários
- **Sinônimos/variações:** saldo fgts real, saldo efetivo fgts, valor real do fgts, saldo atualizado fgts, saldo fgts líquido real, saldo fgts correto, saldo fgts atual real, saldo fgts líquido, saldo fgts disponível real, saldo fgts exato

### SEQUENCIATRANSF
- **Descrição:** Número sequêncial para transferências - Funcionários
- **Sinônimos/variações:** número sequencial transferência, sequência de transferência, identificador transferência, código sequencial transferência, número da transferência, sequência para transferências, ordem sequencial transferência, sequência de movimentação, número único transferência, sequência registro transferência

### SITUACAOFGTS
- **Descrição:** Situação do FGTS - Tabela Dinâmica: INT14 - Funcionários
- **Sinônimos/variações:** situação do fgts, status do fgts, condição do fgts, estado do fgts, situação da conta fgts, status do fundo fgts, situação do saldo fgts, condição do saldo fgts, status fgts funcionário, situação atual do fgts

### SITUACAOINSS
- **Descrição:** Situação do INSS - Funcionários
- **Sinônimos/variações:** situação do inss, status do inss, condição do inss, estado do inss, situação previdenciária, status da contribuição inss, condição da contribuição inss, situação do benefício inss, status inss funcionário, situação atual do inss

### SITUACAOIRRF
- **Descrição:** Situação do IRRF - Funcionários
- **Sinônimos/variações:** situação do irrf, status do irrf, condição do irrf, estado do irrf, situação do imposto retido, status do imposto de renda, condição do irrf funcionário, situação tributária irrf, status do desconto irrf, situação atual do irrf

### SITUACAORAIS
- **Descrição:** Situação da RAIS - Tabela Dinâmica: INT12 - Funcionários
- **Sinônimos/variações:** situação da rais, status da rais, condição da rais, estado da rais, situação do registro rais, status do cadastro rais, condição do funcionário na rais, situação do empregado rais, status rais funcionário, situação atual da rais

### SUCESSAOVINCULO
- **Descrição:** Indicativo sucessão de vínculo - Funcionários
- **Sinônimos/variações:** indicativo sucessão de vínculo, sucessão de vínculo, continuidade do vínculo, vínculo sucessor, vínculo continuado, indicador de sucessão, sucessão contratual, vínculo sucessão funcionário, continuidade do contrato, sucessão de contrato

### TEMAVISOPREVIO
- **Descrição:** Existência de Aviso Prévio - Funcionários
- **Sinônimos/variações:** existe aviso prévio, tem aviso prévio, aviso prévio ativo, aviso prévio existente, aviso prévio aplicado, aviso prévio funcionário, aviso prévio registrado, aviso prévio em vigor, aviso prévio presente, aviso prévio declarado

### TEMCLAUASSEG
- **Descrição:** Indica se contém cláusula asseguratória para contrato com prazo determinado - Funcionários
- **Sinônimos/variações:** tem cláusula asseguratória, cláusula asseguratória presente, cláusula asseguratória contrato, cláusula asseguratória ativa, cláusula asseguratória para contrato, cláusula asseguratória prazo determinado, cláusula asseguratória funcionário, contrato com cláusula asseguratória, cláusula asseguratória vigente, cláusula asseguratória aplicada

### TEMDEDUCAOCPMF
- **Descrição:** Tem Dedução de CPMF - Funcionários
- **Sinônimos/variações:** tem dedução de cpmf, dedução cpmf aplicada, desconto cpmf, cpmf descontada, dedução de imposto cpmf, cpmf retida, tem desconto cpmf, dedução cpmf funcionário, cpmf descontada no salário, desconto de cpmf ativo

### TEMMAIS65ANOS
- **Descrição:** Indicativo de De Idade Sup. a 65 Anos - Funcionários
- **Sinônimos/variações:** idade superior a 65 anos, funcionário acima de 65, tem mais de 65 anos, idade maior que 65, idade acima de 65 anos, funcionário idoso, idade avançada, idade superior a sessenta e cinco, funcionário com mais de 65 anos, idade limite 65 anos

### TEMPOPARCIAL
- **Descrição:** Contrato de trabalho em regime de tempo parcial - Funcionários
- **Sinônimos/variações:** contrato tempo parcial, regime de tempo parcial, trabalho meio período, funcionário meio expediente, contrato parcial, jornada parcial, trabalho em tempo parcial, horário reduzido, regime parcial, contrato de meio período

### TEMPRAZOCONTR
- **Descrição:** Existência de Prazo no Contrato - Funcionários
- **Sinônimos/variações:** contrato com prazo, prazo no contrato, contrato temporário, existência de prazo contratual, contrato por prazo determinado, vigência do contrato, contrato com data limite, contrato prazo certo, contrato com duração limitada, contrato temporário definido

### TETORGPS
- **Descrição:** Sujeito ao teto do RGPS estatutário - Funcionários
- **Sinônimos/variações:** sujeito ao teto rgps, limite do rgps, teto previdenciário rgps, restrição teto rgps, teto do regime geral, limite máximo rgps, teto estatutário rgps, regra do teto rgps, incidência do teto rgps, teto previdenciário estatutário

### TIPOADESAOBEM
- **Descrição:** Tipo de Adesão B.E.M. - Funcionários
- **Sinônimos/variações:** tipo de adesão b.e.m., modalidade de adesão bem, forma de adesão b.e.m., adesão ao bem, categoria adesão bem, tipo adesão benefício emergencial, adesão ao benefício emergencial, classificação adesão bem, tipo de participação bem, adesão programa bem

### TIPOADMISSAO
- **Descrição:** Tipo de Admissão - Funcionários
- **Sinônimos/variações:** tipo de admissão, modalidade de admissão, forma de ingresso, categoria de admissão, tipo de contratação, modo de admissão, classificação da admissão, tipo ingresso funcionário, tipo de entrada, natureza da admissão

### TIPOAPOSENTADORIA
- **Descrição:** Tipo de aposentadoria - Funcionários
- **Sinônimos/variações:** tipo de aposentadoria, modalidade de aposentadoria, categoria aposentadoria, forma de aposentadoria, tipo de benefício previdenciário, classificação aposentadoria, tipo de saída por aposentadoria, modalidade de saída aposentadoria, tipo aposentadoria funcionário, tipo de benefício de aposentadoria

### TIPOAVISOPREVIO
- **Descrição:** Tipo de Aviso Prévio - Funcionários
- **Sinônimos/variações:** tipo de aviso prévio, modalidade de aviso prévio, forma de aviso prévio, categoria aviso prévio, tipo de comunicação prévia, aviso prévio trabalhista, tipo de notificação prévia, modalidade aviso prévio demissão, tipo de aviso antecipado, aviso prévio empregado

### TIPOCONTPRAZODETERMINADO
- **Descrição:** Tipo de contrato do prazo determinado - Funcionários
- **Sinônimos/variações:** tipo contrato prazo determinado, modalidade contrato temporário, categoria contrato com prazo, forma contrato prazo certo, tipo de contrato temporário, contrato por prazo determinado, classificação contrato temporário, tipo de vínculo temporário, contrato prazo fixo, tipo contrato com duração limitada

### TIPOCONTRATOPRAZO
- **Descrição:** Tipo do contrato com prazo - Funcionários
- **Sinônimos/variações:** tipo contrato com prazo, modalidade contrato temporário, categoria contrato com duração, forma contrato prazo determinado, tipo vínculo com prazo, contrato por prazo certo, classificação contrato temporário, tipo de contrato limitado, contrato prazo fixo, tipo contrato temporário

### TIPODEMISSAO
- **Descrição:** Tipo de Demissão - Tabela Dinâmica: INT05 - Funcionários
- **Sinônimos/variações:** tipo de demissão, modalidade de desligamento, forma de demissão, categoria de saída, tipo de rescisão, classificação da demissão, motivo da demissão, tipo desligamento funcionário, modalidade saída do empregado, tipo de término de contrato

### TIPOPLANOSEGREGACAOMASSA
- **Descrição:** Tipo de plano de segregação da massa do estatutário - Funcionários
- **Sinônimos/variações:** tipo plano segregação massa, modalidade segregação da massa, categoria plano segregação, forma segregação estatutário, tipo de segregação da massa, classificação plano segregação, plano segregação estatutário, tipo segregação de massa, modalidade segregação estatutária, tipo plano de segregação

### TIPOPROVIMENTO
- **Descrição:** Tipo de provimento estatutário - Funcionários
- **Sinônimos/variações:** tipo de provimento, modalidade de provimento, categoria de provimento, forma de provimento, tipo de nomeação, classificação do provimento, tipo de cargo provido, modalidade de ocupação, tipo de designação, tipo de preenchimento de cargo

### TIPOREDUCAOAVISO
- **Descrição:** Tipo de redução do aviso: dias ou jornada - Funcionários
- **Sinônimos/variações:** tipo redução do aviso, modalidade redução aviso prévio, forma de redução do aviso, categoria redução aviso, tipo diminuição do aviso, redução de dias ou jornada, tipo de corte no aviso prévio, modalidade redução do prazo aviso, tipo de redução aviso demissão, redução aviso prévio

### TIPOREGIMEJORNADA
- **Descrição:** Tipo de Regime da Jornada - Funcionários
- **Sinônimos/variações:** tipo regime da jornada, modalidade jornada de trabalho, categoria regime de trabalho, forma regime jornada, tipo de jornada, classificação da jornada, regime de horas trabalhadas, tipo regime horário, modalidade jornada laboral, tipo regime de expediente

### TIPOREGIMEPREVIDENCIARIOCEDIDO
- **Descrição:** Tipo de regime previdenciário do trabalhador cedido - Funcionários
- **Sinônimos/variações:** tipo regime previdenciário cedido, modalidade previdência trabalhador cedido, categoria regime previdenciário cedido, forma regime previdenciário cedido, tipo previdência trabalhador cedido, classificação regime previdenciário cedido, regime previdenciário do cedido, tipo de previdência cedido, modalidade previdência cedido, tipo regime previdenciário trabalhador cedido

### TIPOREGIMETRABALHISTA
- **Descrição:** Tipo de regime trabalhista do funcionário - Funcionários
- **Sinônimos/variações:** tipo regime trabalhista, modalidade regime de trabalho, categoria regime trabalhista, forma regime trabalhista, tipo regime laboral, classificação regime de trabalho, tipo regime empregado, modalidade regime trabalhista, tipo regime de vínculo, regime trabalhista do funcionário

### TIPOREGIMETRABALHISTACEDIDO
- **Descrição:** Tipo de regime trabalhista do trabalhador cedido - Funcionários
- **Sinônimos/variações:** tipo regime trabalhista cedido, modalidade regime trabalho cedido, categoria regime trabalhista cedido, forma regime trabalhista cedido, tipo regime laboral cedido, classificação regime trabalho cedido, regime trabalhista do cedido, tipo regime vínculo cedido, modalidade regime trabalhista do cedido, tipo regime empregado cedido

### TIPOREGPREVDIRIGENTESINDICAL
- **Descrição:** Tipo de regime previdenciário dirigente sindical - Funcionários
- **Sinônimos/variações:** tipo regime previdenciário dirigente sindical, modalidade previdência dirigente sindical, categoria regime previdenciário sindical, forma regime previdenciário dirigente, tipo previdência dirigente sindical, classificação regime previdenciário sindical, regime previdenciário para dirigente sindical, tipo previdência sindical, modalidade previdência dirigente, tipo regime previdenciário sindical

### TIPOREGPREVMANDATOELETIVO
- **Descrição:** Tipo de regime previdenciário para servidor público com mandato eletivo - Funcionários
- **Sinônimos/variações:** tipo regime previdenciário mandato eletivo, modalidade previdência servidor mandato, categoria regime previdenciário mandato, forma regime previdenciário mandato eletivo, tipo previdência servidor público mandato, classificação regime previdenciário mandato, regime previdenciário para mandato eletivo, tipo previdência mandato eletivo, tipo regime previdenciário servidor mandato

### TIPOREGTRABDIRIGENTESINDICAL
- **Descrição:** Tipo de regime trabalhista dirigente sindical - Funcionários
- **Sinônimos/variações:** tipo regime trabalhista dirigente sindical, modalidade regime trabalho dirigente sindical, categoria regime trabalhista sindical, forma regime trabalhista dirigente, tipo regime laboral dirigente sindical, classificação regime trabalho sindical, regime trabalhista para dirigente sindical, tipo regime vínculo sindical, modalidade regime trabalhista sindical, tipo regime empregado dirigente sindical

### TIPOREGTRABMANDATOELETIVO
- **Descrição:** Tipo de regime trabalhista para servidor público com mandato eletivo - Funcionários
- **Sinônimos/variações:** tipo regime trabalhista mandato eletivo, modalidade regime trabalho mandato, categoria regime trabalhista mandato eletivo, forma regime trabalhista mandato, tipo regime laboral mandato eletivo, classificação regime trabalho mandato, regime trabalhista para mandato eletivo, tipo regime vínculo mandato, modalidade regime trabalhista mandato, tipo regime empregado mandato eletivo

### TIPOREINTEGRACAO
- **Descrição:** Tipo da Reintegração - Funcionários
- **Sinônimos/variações:** tipo de reintegração, modalidade de reintegração, categoria reintegração, forma de reintegração, tipo de retorno ao trabalho, classificação reintegração, tipo de readmissão, modalidade retorno funcionário, tipo reintegração trabalhista, tipo reintegração do empregado

### TPCONTABANCARIA
- **Descrição:** Tipo de conta bancária - Funcionários
- **Sinônimos/variações:** tipo de conta bancária, modalidade conta bancária, categoria conta bancária, forma conta bancária, tipo conta salário, classificação conta bancária, tipo de conta corrente, modalidade conta poupança, tipo conta para pagamento, tipo conta financeira

### TPCONTABANCARIA2
- **Descrição:** 2º Tipo de conta bancária - Funcionários
- **Sinônimos/variações:** 2º tipo de conta bancária, segunda conta bancária, modalidade segunda conta, categoria conta bancária secundária, tipo conta bancária adicional, forma segunda conta bancária, tipo conta para pagamento 2, conta bancária alternativa, tipo conta bancária extra, segunda modalidade de conta

### TPINCLUSAOCONTRATO
- **Descrição:** Tipo de inclusão de contrato temporário - Funcionários
- **Sinônimos/variações:** tipo inclusão contrato temporário, modalidade inclusão contrato, categoria inclusão contrato temporário, forma inclusão contrato, tipo de registro contrato temporário, classificação inclusão contrato, tipo de vínculo temporário, modalidade inclusão vínculo temporário, tipo inclusão contrato de trabalho, tipo inclusão contrato funcionário

### TPINSCRICAOTEMP
- **Descrição:** Tipo Inscrição Trabalhador Substituído - Funcionários
- **Sinônimos/variações:** tipo inscrição trabalhador substituído, modalidade inscrição temporária, categoria inscrição trabalhador substituto, forma inscrição temporária, tipo registro trabalhador substituído, classificação inscrição temporária, tipo inscrição temporária, modalidade inscrição substituto, tipo inscrição temporária trabalhador, tipo inscrição temporária funcionário

### TPREGIMEPREV
- **Descrição:** Tipo de regime previdenciário - Funcionários
- **Sinônimos/variações:** tipo regime previdenciário, modalidade regime previdenciário, categoria regime previdenciário, forma regime previdenciário, tipo previdência social, classificação regime previdenciário, tipo de previdência, modalidade previdência, tipo regime de aposentadoria, tipo regime previdenciário empregado

### TRABALHOUNADEMISSAO
- **Descrição:** Indica se trabalhou no dia da demissão - Funcionários
- **Sinônimos/variações:** trabalhou no dia da demissão, atividade no dia da demissão, trabalho no dia da saída, presença no dia da demissão, exerceu função no dia da demissão, trabalho no último dia, atividade no último dia, trabalhou até a demissão, trabalho no dia do desligamento, atividade no dia do desligamento

### TRANSFERENCIASUCESSAO
- **Descrição:** Transferência por sucessão - Funcionários
- **Sinônimos/variações:** transferência por sucessão, sucessão trabalhista, transferência por mudança de empresa, transferência por continuidade, transferência por sucessão empresarial, mudança por sucessão, transferência de vínculo por sucessão, transferência por continuidade de contrato, transferência por sucessão de empregados, transferência por sucessão trabalhista

### ULTIMORECALCULODATA
- **Descrição:** Data do Último Recálculo - Funcionários
- **Sinônimos/variações:** data do último recálculo, última data de recálculo, quando foi o último recálculo, data do último ajuste, data do último cálculo, data da última atualização, última data de revisão, data do último processamento, data do último recálculo salarial, data do último recálculo do funcionário

### ULTIMORECALCULOHORA
- **Descrição:** Hora/Data do Último Recálculo - Funcionários
- **Sinônimos/variações:** hora do último recálculo, data e hora do último recálculo, quando foi o último recálculo, momento do último recálculo, horário do último ajuste, data e hora da última atualização, hora da última revisão, registro do último recálculo, timestamp do último recálculo, hora do último recálculo do funcionário

### USACONTROLEDESALDO
- **Descrição:** Se Será Feito Controle de Saldo de Verba - Funcionários
- **Sinônimos/variações:** controle de saldo ativo, usa controle de saldo, controle de saldo de verba, controle de saldo habilitado, verba com controle de saldo, funcionário com controle de saldo, controle de saldo aplicado, saldo de verba controlado, controle de saldo utilizado, controle de saldo de funcionário

### USASALCOMPOSTO
- **Descrição:** Informa se o Funcionário utiliza Salário Composto - Funcionários
- **Sinônimos/variações:** usa salário composto, salário composto ativo, funcionário com salário composto, salário composto utilizado, salário composto habilitado, utiliza salário composto, salário composto aplicado, salário com composição, salário composto do funcionário, salário composto em uso

### USAVALETRANSP
- **Descrição:** Usa Vale Transporte - Funcionários
- **Sinônimos/variações:** usa vale transporte, vale transporte ativo, funcionário com vale transporte, vale transporte utilizado, vale transporte habilitado, utiliza vale transporte, vale transporte aplicado, benefício vale transporte, vale transporte do funcionário, vale transporte em uso

### UTILIZAPONTOAHGORA
- **Descrição:** O funcionário utiliza ponto ahgora? - Funcionários
- **Sinônimos/variações:** utiliza ponto ahgora, ponto ahgora ativo, registro no ponto ahgora, funcionário usa ponto ahgora, ponto ahgora utilizado, controle ponto ahgora, ponto ahgora habilitado, uso do ponto ahgora, ponto eletrônico ahgora, ponto ahgora do funcionário

### VALORREDUZIDOBEM
- **Descrição:** Valor reduzido B.E.M. - Funcionários
- **Sinônimos/variações:** valor reduzido b.e.m., valor descontado b.e.m., redução do valor b.e.m., quantia reduzida b.e.m., valor abatido b.e.m., valor menor b.e.m., valor ajustado b.e.m., valor reduzido benefício, valor reduzido do funcionário, valor b.e.m. aplicado

### VINCULORAIS
- **Descrição:** Vínculo com o Rais - Tabela Dinâmica: INT13 - Funcionários
- **Sinônimos/variações:** vínculo com o rais, registro rais, vínculo rais, informação rais, dados para rais, vínculo para rais, vínculo na rais, vínculo do funcionário rais, vínculo rais tabela dinâmica, vínculo rais int13

## Notas de uso
- Este arquivo é parte do catálogo semântico para `file_search`/Vector Store.
- Objetivo: permitir que o agente descubra quais colunas/tabelas atendem uma pergunta humana.