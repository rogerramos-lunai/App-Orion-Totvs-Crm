# PEVENTO

**Descrição:** Cadastro de Eventos

## Colunas

### APLICACAO
- **Descrição:** Código do sistema pertencente da linha RM - Evento
- **Sinônimos/variações:** código do sistema, sistema rm, identificador do sistema, aplicação do evento, sistema pertencente, qual sistema, origem do evento, sistema linha rm, sistema do evento, sistema associado

### BASESALCOMPOSTO
- **Descrição:** Salário Composto para Base de Cálculo do Evento
- **Sinônimos/variações:** salário composto, base de cálculo composta, salário para cálculo, base salarial composta, base para cálculo do evento, salário para evento, valor base composto, base salarial para cálculo, remuneração composta, base de cálculo do salário

### CCUSTO
- **Descrição:** Código do centro de custo do Evento
- **Sinônimos/variações:** centro de custo, código do centro de custo, centro de despesa, custo do evento, centro de custo do evento, qual centro de custo, identificador do centro de custo, centro de custo associado, código custo, centro financeiro

### CGCREDITO
- **Descrição:** Nº da Conta Gerencial para Crédito - Evento
- **Sinônimos/variações:** conta gerencial crédito, número da conta crédito, conta para crédito, conta gerencial para crédito, conta crédito do evento, conta gerencial crédito evento, número conta crédito, conta crédito gerencial, conta crédito associada, conta gerencial crédito código

### CGDEBITO
- **Descrição:** Nº da Conta Gerencial para Débito - Evento
- **Sinônimos/variações:** conta gerencial débito, número da conta débito, conta para débito, conta gerencial para débito, conta débito do evento, conta gerencial débito evento, número conta débito, conta débito gerencial, conta débito associada, conta gerencial débito código

### CHAVE
- **Descrição:** Quais chaves pertencem o Evento
- **Sinônimos/variações:** chaves do evento, quais chaves pertencem, identificadores do evento, chave associada, chaves vinculadas, códigos chave, chave do registro, chave identificadora, quais chaves, chave do evento

### CODCOLIGADA
- **Descrição:** Código Identificador da Coligada - Evento
- **Sinônimos/variações:** código da coligada, identificador da coligada, coligada do evento, qual coligada, código empresa coligada, empresa coligada, identificação da coligada, coligada associada, código grupo empresarial, código da empresa

### CODEVENTODIF
- **Descrição:** Evento de Diferença de Salário
- **Sinônimos/variações:** evento diferença salário, evento de diferença, diferença salarial, evento diferença, evento ajuste salarial, evento diferença de salário, evento ajuste, evento diferença pagamento, evento diferença remuneração, evento diferença valor

### CODEVENTODIFNEGATIVA
- **Descrição:** Evento de Diferença de Salário Negativa
- **Sinônimos/variações:** evento diferença negativa, evento diferença salário negativa, diferença salarial negativa, evento ajuste negativo, evento diferença negativa salário, evento diferença valor negativo, evento diferença desconto, evento ajuste desconto, evento diferença negativa pagamento

### CODEVENTOINSUF
- **Descrição:** Evento de Insuficiência de Saldos
- **Sinônimos/variações:** evento insuficiência saldos, evento saldo insuficiente, evento insuficiência, evento falta de saldo, evento saldo negativo, evento insuficiência financeira, evento insuficiência de saldo

### CODIGO
- **Descrição:** Código Identificador do Evento
- **Sinônimos/variações:** código do evento, identificador do evento, código identificador, código do registro, id do evento, qual código do evento, código único do evento, identificação do evento, código evento, código principal

### CODIGOCALCULO
- **Descrição:** Código de Cálculo do Evento
- **Sinônimos/variações:** código de cálculo, identificador cálculo, código cálculo do evento, código do cálculo, qual código cálculo, código para cálculo, código cálculo, código cálculo associado, código cálculo evento, código cálculo financeiro

### CODRATEIO
- **Descrição:** Código do Rateio que o Evento Segue
- **Sinônimos/variações:** código do rateio, identificador do rateio, rateio do evento, qual código rateio, código rateio, rateio associado, código rateio evento, identificação do rateio, código distribuição, rateio financeiro

### CODRUBRICA
- **Descrição:** Codigo de rubrica para utilização de TRCT - Evento
- **Sinônimos/variações:** código da rubrica, identificador da rubrica, rubrica para trct, código rubrica evento, qual código rubrica, código da rubrica trct, rubrica associada, código rubrica, rubrica para cálculo, código rubrica para trct

### CODTPBENEFICIO
- **Descrição:** Tipo de Benefício PPE - Evento
- **Sinônimos/variações:** tipo de benefício, código tipo benefício, benefício ppe, tipo benefício evento, qual tipo benefício, tipo benefício, código benefício, tipo benefício associado, tipo benefício ppe evento, identificador benefício

### CODTPDESCONTO
- **Descrição:** Tipo de Desconto PPE - Evento
- **Sinônimos/variações:** tipo de desconto, código tipo desconto, desconto ppe, tipo desconto evento, qual tipo desconto, tipo desconto, código desconto, tipo desconto associado, tipo desconto ppe evento, identificador desconto

### COMPLHISTORICO
- **Descrição:** Complemento do Histórico para fins Contpabeis - Evento
- **Sinônimos/variações:** complemento do histórico, complemento para contábil, histórico contábil, complemento histórico evento, descrição complementar, informação adicional histórico, complemento para contabilidade, detalhe do histórico, complemento para fins contábeis, texto complementar histórico

### COMPOECOMISSAO
- **Descrição:** Indicativo de Composição de Comissão
- **Sinônimos/variações:** compõe comissão, indicativo comissão, composição de comissão, evento comissão, participa da comissão, comissão incluída, comissão evento, composição comissão evento, indicador comissão, evento compõe comissão

### COMPOEREMBASE
- **Descrição:** Compõe Remuneração Base de Professor
- **Sinônimos/variações:** compõe remuneração base, remuneração base professor, inclui na base de remuneração, compõe base professor, remuneração base, base de cálculo professor, evento remuneração base, compõe base salarial professor, base para professor, remuneração base docente

### COMPOETETOREMUNERATORIO
- **Descrição:** Rubrica compõe o teto remuneratório específico (art. 37, XI, da CF/1988)
- **Sinônimos/variações:** compõe teto remuneratório, rubrica teto remuneratório, teto remuneratório específico, compõe limite salarial, teto salarial, limite remuneratório, rubrica teto, teto cf 1988 art 37 xi, compõe teto cf, teto remuneratório evento

### CONTACREDITO
- **Descrição:** Número da Conta para Crédito  - Evento
- **Sinônimos/variações:** conta para crédito, número da conta crédito, conta crédito evento, conta crédito, conta para lançamento crédito, conta crédito financeira, conta crédito associada, número conta crédito, conta crédito contábil, conta crédito do evento

### CONTADEBITO
- **Descrição:** Número da Conta para Débito - Evento
- **Sinônimos/variações:** conta para débito, número da conta débito, conta débito evento, conta débito, conta para lançamento débito, conta débito financeira, conta débito associada, número conta débito, conta débito contábil, conta débito do evento

### CONTAREVERSAO
- **Descrição:** Conta Reversão - Evento
- **Sinônimos/variações:** conta reversão, conta para reversão, conta estorno, conta para estorno, conta reversão evento, conta estorno evento, conta para reverter, conta reversão contábil, conta de reversão, conta para estorno financeiro

### CONTPARCIAL
- **Descrição:** Indicativo para Contab. Parcial - Evento
- **Sinônimos/variações:** contabilização parcial, indicativo contábil parcial, conta parcial, contabilização parcial evento, evento contábil parcial, indicador contábil parcial, conta para contábil parcial, contabilização parcial associada

### DEDUTIVELIRRF
- **Descrição:** Dedutível de Irrf - Evento
- **Sinônimos/variações:** dedutível irrf, evento dedutível irrf, dedução irrf, dedutível imposto de renda, dedução imposto renda, evento dedução irrf, dedutível irrf evento, evento dedutível imposto renda, dedução irrf para cálculo

### DEDUTIVELIRRF13
- **Descrição:** Evento dedutível em IRRF de 13º  - Evento
- **Sinônimos/variações:** dedutível irrf 13º, evento dedutível irrf 13º, dedução irrf 13º, dedutível imposto 13º, dedução imposto 13º, evento dedução irrf 13º, dedutível irrf décimo terceiro, dedução irrf décimo terceiro, evento dedutível irrf 13, dedução irrf 13º salário

### DEDUTIVELIRRFFERIAS
- **Descrição:** Evento dedutível em IRRF de férias - Evento
- **Sinônimos/variações:** dedutível irrf férias, evento dedutível irrf férias, dedução irrf férias, dedutível imposto férias, dedução imposto férias, evento dedução irrf férias, dedutível irrf período férias, dedução irrf período férias, dedução irrf férias evento

### DESCONTOPERDOADO
- **Descrição:** Se o Evento Será Descontado no mês seguinte
- **Sinônimos/variações:** desconto no mês seguinte, evento desconto perdoado, desconto será descontado depois, desconto postergado, desconto no próximo mês, desconto adiado, desconto diferido, desconto perdoado evento, desconto será cobrado depois, desconto no mês posterior

### DESCRICAO
- **Descrição:** Descrição do Evento
- **Sinônimos/variações:** descrição do evento, nome do evento, detalhes do evento, descrição, texto do evento, descrição detalhada, nome descrição, descrição do registro, descrição do lançamento, descrição do item

### ESTCALCFERIAS
- **Descrição:** Indicativo de Estorno da Base de Férias - Evento
- **Sinônimos/variações:** estorno base férias, indicativo estorno férias, estorno cálculo férias, evento estorno férias, estorno base cálculo férias, estorno férias evento, indicador estorno férias, estorno base para férias, estorno cálculo base férias, estorno para férias

### ESTCALCSALFAM
- **Descrição:** Indicativo de Estorno de Base de Salário Família - Evento
- **Sinônimos/variações:** estorno salário família, estorno base salário família, cancelar salário família, reversão salário família, estorno benefício salário família, estorno valor salário família, estorno cálculo salário família, estorno evento salário família, estorno base cálculo salário família, estorno salário família evento, estorno base salário família evento, estorno base do salário família

### ESTCALCULO
- **Descrição:** Indicativo de Estorno da Base de Cálculo - Evento
- **Sinônimos/variações:** estorno base cálculo, estorno cálculo, cancelar base cálculo, reversão base cálculo, estorno valor base cálculo, estorno evento cálculo, estorno base cálculo evento, estorno base cálculo do evento, estorno base cálculo do salário, estorno base cálculo do pagamento

### ESTCALCVALETR
- **Descrição:** Indicativo de Estorno da Base de Vale-Transporte - Evento
- **Sinônimos/variações:** estorno vale-transporte, estorno base vale-transporte, cancelar vale-transporte, reversão vale-transporte, estorno valor vale-transporte, estorno cálculo vale-transporte, estorno evento vale-transporte, estorno base cálculo vale-transporte, estorno vale-transporte evento, estorno base vale-transporte evento

### ESTFGTS
- **Descrição:** Estorna FGTS - Evento
- **Sinônimos/variações:** estorno fgts, cancelar fgts, reversão fgts, estorno valor fgts, estorno base fgts, estorno contribuição fgts, estorno evento fgts, estorno fgts evento, estorno base cálculo fgts, estorno fgts cálculo

### ESTFGTS13
- **Descrição:** Indicativo de Estorno da Base de Fgts de 13º  - Evento
- **Sinônimos/variações:** estorno fgts 13º, estorno base fgts 13º, cancelar fgts 13º, reversão fgts 13º, estorno valor fgts 13º, estorno contribuição fgts 13º, estorno evento fgts 13º, estorno base cálculo fgts 13º, estorno fgts 13º evento, estorno fgts décimo terceiro

### ESTINSS
- **Descrição:** Estorna INSS - Evento
- **Sinônimos/variações:** estorno inss, cancelar inss, reversão inss, estorno valor inss, estorno contribuição inss, estorno base inss, estorno evento inss, estorno inss evento, estorno base cálculo inss, estorno inss cálculo

### ESTINSS13
- **Descrição:** Indicativo de Estorno de Inss no 13º Salário - Evento
- **Sinônimos/variações:** estorno inss 13º, estorno base inss 13º, cancelar inss 13º, reversão inss 13º, estorno valor inss 13º, estorno contribuição inss 13º, estorno evento inss 13º, estorno base cálculo inss 13º, estorno inss 13º evento, estorno inss décimo terceiro

### ESTIRRF
- **Descrição:** Estorna IRRF - Evento
- **Sinônimos/variações:** estorno irrf, cancelar irrf, reversão irrf, estorno valor irrf, estorno imposto irrf, estorno base irrf, estorno evento irrf, estorno irrf evento, estorno base cálculo irrf, estorno irrf cálculo

### ESTIRRF13
- **Descrição:** Indicativo de Estorno da Base de Irrf de 13º  - Evento
- **Sinônimos/variações:** estorno irrf 13º, estorno base irrf 13º, cancelar irrf 13º, reversão irrf 13º, estorno valor irrf 13º, estorno imposto irrf 13º, estorno evento irrf 13º, estorno base cálculo irrf 13º, estorno irrf 13º evento, estorno irrf décimo terceiro

### ESTIRRFFERIAS
- **Descrição:** Estorna Somente em Irrf de Férias - Evento
- **Sinônimos/variações:** estorno irrf férias, estorno imposto férias, cancelar irrf férias, reversão irrf férias, estorno valor irrf férias, estorno irrf em férias, estorno irrf somente férias, estorno irrf evento férias, estorno base irrf férias, estorno irrf cálculo férias

### ESTPIS
- **Descrição:** Estorna PIS - Evento
- **Sinônimos/variações:** estorno pis, cancelar pis, reversão pis, estorno valor pis, estorno contribuição pis, estorno base pis, estorno evento pis, estorno pis evento, estorno base cálculo pis, estorno pis cálculo

### EVENTOEXIBIDOENTRADADADOSWEB
- **Descrição:** Exibir Evento na Entrada de Movimento através do RM Portal - Evento
- **Sinônimos/variações:** exibir evento no portal, mostrar evento na entrada web, evento exibido no rm portal, mostrar evento no portal, exibir evento na entrada de dados, evento visível no portal, exibir evento na entrada de movimento, mostrar evento na entrada de movimento, evento visível na entrada web, exibir evento no rm portal

### EVTALANCAR
- **Descrição:** Indicativo de Evento a Lançar - Evento
- **Sinônimos/variações:** evento a lançar, indicar evento para lançamento, evento para lançamento, evento pendente de lançamento, evento a ser lançado, evento para processar, evento para contabilizar, evento para registrar, evento para incluir, evento para inserir

### EXTDECISAOINSS
- **Descrição:** Extensão da Decisão/Sentença - Evento
- **Sinônimos/variações:** extensão decisão inss, extensão sentença inss, documento decisão inss, documento sentença inss, extensão processo inss, extensão decisão previdência, extensão sentença previdência, extensão decisão judicial inss, extensão sentença judicial inss, extensão decisão administrativa inss

### FORCARINCIRRF
- **Descrição:** Forçar TAG codIncIRRF para o eSocial - Evento
- **Sinônimos/variações:** forçar código irrf, forçar tag codincirrf, forçar código incidência irrf, forçar código irrf esocial, forçar incidência irrf, forçar código irrf no esocial, forçar tag irrf, forçar código imposto irrf, forçar código irrf evento, forçar código irrf tributação

### FORMCOMPLHIST
- **Descrição:** Fórmula para compor Complemento de Histórico - Evento
- **Sinônimos/variações:** fórmula complemento histórico, fórmula para histórico, fórmula compor histórico, fórmula complemento de histórico, fórmula para complemento histórico, fórmula para texto histórico, fórmula para descrição histórica, fórmula para histórico do evento, fórmula para complemento do evento, fórmula para texto do evento

### FORMULACRITICA
- **Descrição:** Código da Fórmula para processo de crítica do Evento
- **Sinônimos/variações:** código fórmula crítica, fórmula para crítica, código fórmula para validação, fórmula para processo de crítica, código fórmula validação evento, fórmula para checagem, código fórmula para análise, fórmula para controle de erro, código fórmula para verificação, fórmula para crítica do evento

### FORMULAEVTRELAC
- **Descrição:** Fórmula para evento relacionado - Evento
- **Sinônimos/variações:** fórmula evento relacionado, fórmula para evento relacionado, fórmula para vínculo de evento, fórmula para relação de evento, fórmula para evento associado, fórmula para evento dependente, fórmula para evento complementar, fórmula para evento vinculado, fórmula para associação de evento

### FORMULAHORA
- **Descrição:** Código da Fórmula de Hora - Evento
- **Sinônimos/variações:** código fórmula hora, fórmula para cálculo de hora, código fórmula para horas, fórmula para horas trabalhadas, código fórmula para tempo, fórmula para cálculo de tempo, código fórmula para jornada, fórmula para horas evento, código fórmula para horas extras, fórmula para horas normais

### FORMULAREF
- **Descrição:** Código da Fórmula de Referência - Evento
- **Sinônimos/variações:** código fórmula referência, fórmula para referência, código fórmula para referência, fórmula para base de referência, código fórmula para base referência, fórmula para referência do evento, código fórmula para referência evento, fórmula para cálculo de referência, código fórmula para cálculo referência, fórmula para referência salarial

### FORMULAVALOR
- **Descrição:** Código da Fórmula de Valor - Evento
- **Sinônimos/variações:** código fórmula valor, fórmula para cálculo de valor, código fórmula para valor, fórmula para valor do evento, código fórmula para valor evento, fórmula para cálculo do valor, código fórmula para cálculo valor, fórmula para valor monetário, código fórmula para valor monetário, fórmula para valor financeiro

### GRUPOAAS
- **Descrição:** Código do Grupo ASS - Evento
- **Sinônimos/variações:** código grupo ass, grupo ass, código do grupo ass, grupo de ass, grupo ass evento, código grupo ass evento, grupo ass código, grupo ass identificação, grupo ass interno

### ID
- **Descrição:** Campo de identificador interno do Evento
- **Sinônimos/variações:** identificador evento, id evento, código evento, identificação evento, id interno evento, código interno evento, identificador interno, id único evento, código único evento, identificação única evento

### IDANOTACAO
- **Descrição:** Código de Identificação da aba Anotações do Evento
- **Sinônimos/variações:** código anotação, identificador anotação, id aba anotações, código aba anotações, identificação anotação evento, id nota evento, código nota evento, identificador nota evento, id anotação evento, código anotação evento

### IDCLASSEVALOR
- **Descrição:** Identificador da Classe de Valor - Evento
- **Sinônimos/variações:** identificador classe valor, id classe valor, código classe valor, identificação classe valor, id categoria valor, código categoria valor, identificador categoria valor, id tipo valor, código tipo valor, identificação tipo valor

### IDITEMCONTABIL
- **Descrição:** Identificador do Item Contábil - Evento
- **Sinônimos/variações:** identificador item contábil, id item contábil, código item contábil, identificação item contábil, id conta contábil, código conta contábil, identificador conta contábil, id lançamento contábil, código lançamento contábil, identificação lançamento contábil

### INATIVO
- **Descrição:** Indicativo de Evento Inativo/ativo - Evento
- **Sinônimos/variações:** evento inativo, indicativo inativo, status inativo, evento ativo/inativo, indicador ativo, evento desativado, evento ativo, status ativo, flag inativo, flag ativo

### INCACUMULADOR
- **Descrição:** Informar os Acumuladores do Evento
- **Sinônimos/variações:** acumuladores do evento, informar acumuladores, acumuladores, acumulação evento, acumulador evento, informar acumulador, acumuladores para evento, acumulação para evento, acumuladores associados, acumuladores vinculados

### INCCONTRIBSINDICAL
- **Descrição:** Incidência de Contribuição Sindical - Evento
- **Sinônimos/variações:** incidência contribuição sindical, contribuição sindical, incidência sindical, contribuição para sindicato, incidência para contribuição sindical, contribuição sindical evento, incidência contribuição sindicato, contribuição sindicato, incidência para sindicato, contribuição sindical obrigatória

### INCCPSUSPENSAO
- **Descrição:** Incidência de suspensão para a contribuição previdenciária - Evento
- **Sinônimos/variações:** incidência suspensão previdência, suspensão contribuição previdenciária, incidência suspensão inss, suspensão contribuição inss, incidência suspensão previdência social, suspensão contribuição previdência social, incidência suspensão previdenciária, suspensão contribuição previdenciária evento, incidência suspensão contribuição, suspensão contribuição previdência

### INCCPSUSPENSAODESC
- **Descrição:** Incidência de suspensão para a contribuição previdenciária para eventos do tipo desconto
- **Sinônimos/variações:** incidência suspensão contribuição previdenciária desconto, suspensão contribuição previdenciária desconto, contribuição previdenciária suspensa desconto, desconto com suspensão previdenciária, evento com suspensão de contribuição previdenciária, contribuição previdenciária para desconto suspensa, suspensão inss desconto, incidência suspensão inss desconto, evento desconto com suspensão previdenciária, contribuição previdenciária desconto suspenso, desconto com inss suspenso, suspensão desconto previdenciário

### INCDSR
- **Descrição:** Incidência de DSR - Evento
- **Sinônimos/variações:** incidência dsr, evento com dsr, incide dsr, dsr no evento, descanso semanal remunerado, incidência descanso semanal remunerado, evento com descanso semanal remunerado, dsr aplicado, pagamento de dsr, incidência de dsr no evento, dsr incluído, dsr considerado

### INCFGTS
- **Descrição:** Incidência de Fgts - Evento
- **Sinônimos/variações:** incidência fgts, evento com fgts, incide fgts, fgts no evento, fundo de garantia, incidência fundo de garantia, evento com fundo de garantia, fgts aplicado, pagamento de fgts, fgts considerado, incidência de fgts no evento, fgts incluído

### INCFGTS13
- **Descrição:** Incide FGTS de 13º - Evento
- **Sinônimos/variações:** incidência fgts 13º, fgts décimo terceiro, incide fgts 13º salário, fgts no 13º salário, fundo de garantia 13º, incidência fgts décimo terceiro, evento fgts 13º, fgts aplicado no 13º, pagamento fgts 13º, fgts 13º incluído, incidência fgts no décimo terceiro

### INCFGTS13SUSPENSA
- **Descrição:** Suspensão de incidência de FGTS de 13º - Evento
- **Sinônimos/variações:** suspensão fgts 13º, fgts 13º suspenso, suspensão incidência fgts décimo terceiro, fgts décimo terceiro suspenso, suspensão fundo de garantia 13º, evento com suspensão fgts 13º, fgts 13º salário suspenso, suspensão fgts no 13º, incidência suspensa fgts 13º, fgts 13º não incidido, suspensão fgts décimo terceiro

### INCFGTSSUSPENSA
- **Descrição:** Incidência de FGTS suspensa em decorrência de decisão judicial - Evento
- **Sinônimos/variações:** suspensão fgts judicial, fgts suspenso por decisão judicial, suspensão incidência fgts judicial, fgts bloqueado judicialmente, evento com fgts suspenso judicial, fgts suspenso em decisão judicial, incidência fgts suspensa judicialmente, fgts não incidido por decisão judicial, suspensão fgts por ordem judicial, fgts suspenso judicial, evento fgts suspenso judicial

### INCIDECUSTOFUNCIONARIO
- **Descrição:** Incide no Custo do funcionário - Evento
- **Sinônimos/variações:** incidência custo funcionário, evento no custo do funcionário, incide no custo do funcionário, custo do empregado, evento que impacta custo do funcionário, incidência no custo trabalhista, custo funcionário considerado, evento que gera custo para funcionário, incidência custo trabalhista, custo do colaborador, evento custo funcionário

### INCINFREND
- **Descrição:** Incidência no Informe de Rendimentos - Evento
- **Sinônimos/variações:** incidência informe de rendimentos, evento no informe de rendimentos, incide no informe de rendimentos, informe de rendimentos considerado, evento para informe de rendimentos, dados para informe de rendimentos, incidência para declaração de rendimentos, evento para declaração de rendimentos, informe de rendimentos evento, incidência no ir, evento para ir

### INCINSS
- **Descrição:** Incidência de Inss - Evento
- **Sinônimos/variações:** incidência inss, evento com inss, incide inss, inss no evento, contribuição previdenciária, incidência contribuição inss, evento com contribuição inss, inss aplicado, pagamento inss, inss considerado, incidência de inss no evento, inss incluído

### INCINSS13
- **Descrição:** Incidência de Inss no 13º Salário - Evento
- **Sinônimos/variações:** incidência inss 13º, inss décimo terceiro, incide inss 13º salário, inss no 13º salário, contribuição inss 13º, incidência inss décimo terceiro, evento inss 13º, inss aplicado no 13º, pagamento inss 13º, inss 13º incluído, incidência inss no décimo terceiro

### INCINSS13SUSPENSA
- **Descrição:** Suspensão de incidência de INSS de 13º - Evento
- **Sinônimos/variações:** suspensão inss 13º, inss 13º suspenso, suspensão incidência inss décimo terceiro, inss décimo terceiro suspenso, suspensão contribuição inss 13º, evento com suspensão inss 13º, inss 13º salário suspenso, suspensão inss no 13º, incidência suspensa inss 13º, inss 13º não incidido, suspensão inss décimo terceiro

### INCINSSEXCLUSIVAEMPREGADOR
- **Descrição:** Incidência de INSS exclusida do empregador - Evento
- **Sinônimos/variações:** incidência inss exclusiva empregador, inss só do empregador, contribuição inss exclusiva do empregador, evento inss empregador, inss patronal, incidência inss patronal, inss exclusiva para empregador, contribuição inss patronal, evento com inss patronal, inss empregador considerado, incidência inss do empregador

### INCINSSEXCLUSIVAEMPREGADOR13
- **Descrição:** Incidência de INSS décimo terceiro exclusiva do empregador - Evento
- **Sinônimos/variações:** incidência inss 13º exclusiva empregador, inss 13º só do empregador, contribuição inss 13º exclusiva do empregador, evento inss 13º empregador, inss patronal 13º, incidência inss patronal 13º, inss 13º exclusiva para empregador, contribuição inss patronal 13º, evento com inss patronal 13º, inss empregador 13º considerado, incidência inss do empregador 13º

### INCINSSEXCLUSIVAEMPREGADOR13DS
- **Descrição:** Incidência de INSS décimo terceiro exclusiva do empregador para eventos do tipo desconto - Evento
- **Sinônimos/variações:** incidência inss 13º desconto exclusiva empregador, inss 13º desconto só do empregador, contribuição inss 13º desconto exclusiva do empregador, evento inss 13º desconto empregador, inss patronal 13º desconto, incidência inss patronal 13º desconto, inss 13º desconto exclusiva para empregador, contribuição inss patronal 13º desconto, evento com inss patronal 13º desconto, inss empregador 13º desconto considerado, incidência inss do empregador 13º desconto

### INCINSSEXCLUSIVAEMPREGADORDESC
- **Descrição:** Incidência de INSS exclusiva do empregador - Evento
- **Sinônimos/variações:** incidência inss exclusiva empregador desconto, inss desconto só do empregador, contribuição inss desconto exclusiva do empregador, evento inss desconto empregador, inss patronal desconto, incidência inss patronal desconto, inss desconto exclusiva para empregador, contribuição inss patronal desconto, evento com inss patronal desconto, inss empregador desconto considerado, incidência inss do empregador desconto

### INCINSSEXCLUSIVASEGURADO
- **Descrição:** Incidência de INSS exclusida do segurado - Evento
- **Sinônimos/variações:** incidência inss exclusiva segurado, inss só do segurado, contribuição inss exclusiva do segurado, evento inss segurado, inss do empregado, incidência inss empregado, inss exclusiva para segurado, contribuição inss empregado, evento com inss empregado, inss segurado considerado, incidência inss do segurado

### INCINSSEXCLUSIVASEGURADO13
- **Descrição:** Incidência de INSS exclusiva do segurado de 13º Salário - Evento
- **Sinônimos/variações:** incidência inss 13º exclusiva segurado, inss 13º só do segurado, contribuição inss 13º exclusiva do segurado, evento inss 13º segurado, inss do empregado 13º, incidência inss empregado 13º, inss 13º exclusiva para segurado, contribuição inss empregado 13º, evento com inss empregado 13º, inss segurado 13º considerado, incidência inss do segurado 13º

### INCINSSREGIMEPROPRIOPREV
- **Descrição:** Código de incidência da rubrica para as contribuições do Regime Próprio de Previdência Social - Evento
- **Sinônimos/variações:** código incidência regime próprio previdência, incidência inss regime próprio, evento regime próprio previdência, contribuição regime próprio, código inss regime próprio, incidência previdência própria, evento previdência própria, código contribuição regime próprio, incidência inss rpps, evento rpps, código rpps

### INCINSSSALMAT13SUSPENSA
- **Descrição:** Suspensão de incidência de INSS Salário Maternidade 13º - Evento
- **Sinônimos/variações:** suspensão inss salário maternidade 13º, inss salário maternidade 13º suspenso, suspensão incidência inss salário maternidade 13º, inss 13º salário maternidade suspenso, evento suspensão inss salário maternidade 13º, inss salário maternidade 13º não incidido, suspensão inss 13º maternidade, incidência suspensa inss salário maternidade 13º, inss salário maternidade 13º bloqueado, suspensão inss maternidade 13º

### INCINSSSALMATSUSPENSA
- **Descrição:** Suspensão de incidência de INSS Salário Maternidade - Evento
- **Sinônimos/variações:** suspensão inss salário maternidade, inss salário maternidade suspenso, suspensão incidência inss salário maternidade, inss salário maternidade não incidido, evento suspensão inss salário maternidade, inss maternidade suspenso, suspensão inss maternidade, incidência suspensa inss salário maternidade, inss salário maternidade bloqueado

### INCINSSSUSPENSA
- **Descrição:** Incidência de INSS suspensa em decorrência de decisão judicial - Evento
- **Sinônimos/variações:** suspensão inss judicial, inss suspenso por decisão judicial, suspensão incidência inss judicial, inss bloqueado judicialmente, evento com inss suspenso judicial, inss suspenso em decisão judicial, incidência inss suspensa judicialmente, inss não incidido por decisão judicial, suspensão inss por ordem judicial, inss suspenso judicial, evento inss suspenso judicial

### INCINSSSUSPENSAO
- **Descrição:** Incidência de suspensão para a contribuição previdenciária - Evento
- **Sinônimos/variações:** incidência suspensão contribuição previdenciária, suspensão contribuição previdenciária, evento suspensão inss, suspensão inss, contribuição previdenciária suspensa, suspensão inss no evento, incidência suspensão inss, evento com suspensão previdenciária, suspensão inss aplicada, suspensão inss no desconto

### INCIRRF
- **Descrição:** Incidência de Irrf - Evento
- **Sinônimos/variações:** incidência irrf, evento com irrf, incide irrf, irrf no evento, imposto de renda retido na fonte, incidência imposto de renda, evento imposto de renda, irrf aplicado, pagamento irrf, irrf considerado, incidência de irrf no evento, irrf incluído

### INCIRRF13
- **Descrição:** Incidência de Irrf no 13º Salário - Evento
- **Sinônimos/variações:** incidência irrf 13º, irrf décimo terceiro, incide irrf 13º salário, irrf no 13º salário, imposto de renda 13º, incidência irrf décimo terceiro, evento irrf 13º, irrf aplicado no 13º, pagamento irrf 13º, irrf 13º incluído, incidência irrf no décimo terceiro

### INCIRRF13SUSPENSA
- **Descrição:** Suspensão de incidência de IRRF de 13º - Evento
- **Sinônimos/variações:** suspensão irrf 13º, irrf 13º suspenso, suspensão incidência irrf décimo terceiro, irrf décimo terceiro suspenso, suspensão imposto de renda 13º, evento com suspensão irrf 13º, irrf 13º salário suspenso, suspensão irrf no 13º, incidência suspensa irrf 13º, irrf 13º não incidido, suspensão irrf décimo terceiro

### INCIRRFFERIAS
- **Descrição:** Incidência de Irrf nas Férias - Evento
- **Sinônimos/variações:** incidência irrf férias, irrf nas férias, imposto de renda férias, incide irrf nas férias, evento irrf férias, irrf aplicado nas férias, pagamento irrf férias, irrf férias considerado, incidência irrf no período de férias, irrf férias incluído

### INCIRRFFERIASSUSPENSA
- **Descrição:** Suspensão de incidência de IRRF Férias - Evento
- **Sinônimos/variações:** suspensão irrf férias, irrf férias suspenso, suspensão incidência irrf férias, imposto de renda férias suspenso, evento com suspensão irrf férias, irrf férias não incidido, suspensão irrf no período de férias, incidência suspensa irrf férias, irrf férias bloqueado

### INCIRRFFORCADA
- **Descrição:** Código de incidência tributária do eSocial - Evento
- **Sinônimos/variações:** código incidência tributária esocial, incidência tributária esocial, evento código tributário esocial, código tributação esocial, incidência tributária evento, código tributário esocial, evento tributação esocial, código tributário fiscal, incidência tributária fiscal, código tributário

### INCIRRFISENCAO
- **Descrição:** Código de Isenção do eSocial - Evento
- **Sinônimos/variações:** código isenção esocial, isenção irrf esocial, evento isenção irrf, código isenção tributária, isenção imposto de renda, evento isenção tributária, código isenção fiscal, isenção irrf, evento isenção, código isenção

### INCIRRFPLRSUSPENSA
- **Descrição:** Suspensão de incidência de IRRF PLR - Evento
- **Sinônimos/variações:** suspensão irrf plr, irrf plr suspenso, suspensão incidência irrf plr, imposto de renda plr suspenso, evento com suspensão irrf plr, irrf plr não incidido, suspensão irrf participação lucros, incidência suspensa irrf plr, irrf plr bloqueado

### INCIRRFSUSPENSA
- **Descrição:** Incidência de IRRF suspensa em decorrência de decisão judicial - Evento
- **Sinônimos/variações:** incidência irrf suspensa, irrf suspenso, imposto retido suspenso, suspensão irrf, irrf bloqueado, imposto retido judicial, irrf decisão judicial, suspensão imposto retido na fonte, incidência irrf decisão judicial, irrf não aplicado por decisão, imposto retido suspenso judicialmente

### INCIRRFSUSPENSAO
- **Descrição:** Incidência de suspensão para o IRRF - Evento
- **Sinônimos/variações:** incidência suspensão irrf, suspensão irrf, bloqueio irrf, imposto retido suspenso, paralisação irrf, suspensão imposto retido na fonte, irrf não cobrado, evento sem irrf, suspensão tributária irrf, imposto retido suspenso evento

### INCPENSAO
- **Descrição:** Evento incide em pensão - Evento
- **Sinônimos/variações:** incidência pensão, evento com pensão, desconto pensão, pensão aplicada, incide pensão, evento para pensão, pensão descontada, pensão incidente, evento com desconto de pensão, pensão obrigatória

### INCPENSAO13SAL
- **Descrição:** Evento incide em pensão de 13º salário - Evento
- **Sinônimos/variações:** incidência pensão 13º salário, pensão sobre 13º, desconto pensão 13º, pensão no décimo terceiro, evento com pensão 13º, pensão incidente no 13º salário, pensão sobre gratificação natalina, desconto pensão décimo terceiro, incide pensão no 13º, pensão 13º salário

### INCPENSAOFERIAS
- **Descrição:** Evento incide em pensão de férias - Evento
- **Sinônimos/variações:** incidência pensão férias, pensão sobre férias, desconto pensão férias, evento com pensão férias, pensão incidente nas férias, pensão nas férias, incide pensão férias, pensão sobre abono férias, desconto pensão no período de férias, pensão férias

### INCPENSAOPARTICIP
- **Descrição:** Evento incide em pensão de part. lucros - Evento
- **Sinônimos/variações:** incidência pensão participação lucros, pensão sobre participação nos lucros, desconto pensão participação lucros, evento com pensão participação lucros, pensão incidente em plr, pensão sobre participação de lucros, incide pensão participação lucros, pensão participação lucros, pensão sobre bônus, desconto pensão participação

### INCPIS
- **Descrição:** Incidência de PIS - Evento
- **Sinônimos/variações:** incidência pis, evento com pis, desconto pis, pis aplicado, incide pis, contribuição pis, evento sujeito a pis, pis incidente, tributação pis, pis cobrado

### INCPISPASEP
- **Descrição:** Incidência de suspensão para o PIS/PASEP - Evento
- **Sinônimos/variações:** incidência suspensão pis/pasep, suspensão pis/pasep, evento sem pis/pasep, pis/pasep suspenso, bloqueio pis/pasep, suspensão contribuição pis/pasep, pis/pasep não cobrado, evento sem contribuição pis/pasep, suspensão tributária pis/pasep, pis/pasep suspenso evento

### INCRAIS
- **Descrição:** Incidência de Rais - Evento
- **Sinônimos/variações:** incidência rais, evento com rais, rais aplicado, declaração rais, incide rais, evento sujeito a rais, rais incidente, informação rais, evento para rais, rais cobrado

### INCREGIMEPROPRIOPREVIDENCIA
- **Descrição:** Código de incidência da rubrica para as contribuições do Regime Próprio de Previdência Social/regime militar provento - Evento
- **Sinônimos/variações:** código incidência regime próprio previdência, incidência regime próprio previdência, contribuição regime próprio, evento regime próprio previdência, código contribuição regime militar, incidência previdência regime próprio, evento previdência militar, código rubrica regime próprio, incidência previdência militar, contribuição regime militar

### INCREGIMEPROPRIOPREVIDENCIADSC
- **Descrição:** Código de incidência da rubrica para as contribuições do Regime Próprio de Previdência Social/regime militar desconto - Evento
- **Sinônimos/variações:** código incidência desconto regime próprio previdência, desconto regime próprio previdência, desconto previdência regime próprio, código desconto regime militar, incidência desconto previdência militar, evento desconto regime próprio, desconto contribuição regime próprio, código desconto rubrica regime próprio, desconto previdência militar, desconto regime militar

### INCSALARIO
- **Descrição:** Incidência de Salário - Evento
- **Sinônimos/variações:** incidência salário, evento com salário, salário aplicado, remuneração incidente, incide salário, salário base, evento salário, salário para cálculo, salário considerado, salário tributável

### INCSALFAMILIA
- **Descrição:** Incidência em Salário-Família - Evento
- **Sinônimos/variações:** incidência salário-família, evento salário-família, salário-família aplicado, benefício salário-família, incide salário-família, salário-família incidente, evento para salário-família, salário-família considerado, salário-família cálculo, salário-família

### INCSALMATERNSUSPENSA
- **Descrição:** Incidência de Salário Maternidade Suspensa - Evento
- **Sinônimos/variações:** incidência salário maternidade suspensa, salário maternidade suspenso, evento sem salário maternidade, suspensão salário maternidade, salário maternidade bloqueado, salário maternidade não aplicado, evento salário maternidade suspenso, salário maternidade suspenso judicial, salário maternidade suspenso evento, suspensão benefício maternidade

### INCSINDSUSPENSA
- **Descrição:** Incidência de Contribuição Sindical Suspensa - Evento
- **Sinônimos/variações:** incidência contribuição sindical suspensa, contribuição sindical suspensa, suspensão contribuição sindical, evento sem contribuição sindical, contribuição sindical bloqueada, suspensão desconto sindical, evento contribuição sindical suspenso, contribuição sindical suspensa judicial, contribuição sindical suspensa evento, suspensão desconto sindicato

### INCSUBSTITUICAO
- **Descrição:** Evento Incide em Adicional de Substituição - Evento
- **Sinônimos/variações:** incidência adicional de substituição, evento adicional substituição, adicional substituição aplicado, incide adicional substituição, evento com substituição, adicional por substituição, evento para substituição, adicional substituição cálculo, adicional substituição, substituição incidente

### INCTERCOFERIAS
- **Descrição:** Incidência no Terço de Férias - Evento
- **Sinônimos/variações:** incidência terço de férias, evento terço férias, terço férias aplicado, incide terço férias, terço constitucional férias, evento para terço férias, terço férias cálculo, terço férias incidente, terço férias, adicional terço férias

### INCVALETRANSP
- **Descrição:** Incidência em Vale-Transporte - Evento
- **Sinônimos/variações:** incidência vale-transporte, evento vale-transporte, vale-transporte aplicado, incide vale-transporte, benefício vale-transporte, evento para vale-transporte, vale-transporte cálculo, vale-transporte incidente, vale-transporte, desconto vale-transporte

### ISENTOIRRF
- **Descrição:** Isento de IRRF - Evento
- **Sinônimos/variações:** isento irrf, evento isento irrf, sem irrf, não tributado irrf, isenção irrf, evento sem imposto retido, isento imposto retido na fonte, evento sem irrf, isenção imposto retido, isento de imposto retido

### NAOCALCDIFERENCA
- **Descrição:** Indicativo para desconsiderar o evento no cálculo da diferença - Evento
- **Sinônimos/variações:** não calcular diferença, evento sem cálculo de diferença, ignorar diferença, não considerar diferença, evento sem diferença, não calcular ajuste, ignorar ajuste diferença, evento sem ajuste diferença, não aplicar diferença, não calcular variação

### NAOEBASECALCACORDOINTERNAC
- **Descrição:** Não é base de cálculo em função de acordos internacionais de previdência social - Evento
- **Sinônimos/variações:** não base cálculo acordos internacionais, evento fora base cálculo internacional, não considerar base cálculo internacional, excluído base cálculo internacional, não base cálculo previdência internacional, evento não base internacional, não base cálculo acordo previdenciário, exclusão base cálculo internacional, não base cálculo acordo internacional, evento sem base cálculo internacional

### NATREM
- **Descrição:** Natureza da remuneração - Evento
- **Sinônimos/variações:** natureza da remuneração, tipo de remuneração, categoria remuneração, classificação remuneração, natureza pagamento, tipo pagamento, natureza do valor, classificação do valor, natureza do provento, tipo de provento

### NATRUBRICA
- **Descrição:** Natureza da rubrica - Evento
- **Sinônimos/variações:** natureza da rubrica, tipo de rubrica, classificação rubrica, categoria rubrica, natureza do evento, tipo do evento, classificação do evento, categoria do evento, natureza do lançamento, tipo do lançamento

### NROHISTPADRAO
- **Descrição:** Número do Histórico Padrão para fins Contábeis - Evento
- **Sinônimos/variações:** número histórico padrão, código histórico padrão, identificador histórico padrão, histórico contábil padrão, número do histórico contábil, código do histórico contábil, referência histórico padrão, identificação histórico padrão, histórico padrão contábil, número padrão contábil

### NRPROCESSOFGTS
- **Descrição:** Número do Processo Administrativo/Judicial de FGTS  - Evento
- **Sinônimos/variações:** número processo fgts, processo administrativo fgts, processo judicial fgts, identificação processo fgts, número do processo fgts, processo fgts, referência processo fgts, processo fgts judicial, processo fgts administrativo, número processo fundo fgts

### NRPROCESSOINSS
- **Descrição:** Número do Processo Administrativo/Judicial de INSS  - Evento
- **Sinônimos/variações:** número processo inss, processo administrativo inss, processo judicial inss, identificação processo inss, número do processo inss, processo inss, referência processo inss, processo inss judicial, processo inss administrativo, número processo previdência

### NRPROCESSOIRRF
- **Descrição:** Número do Processo Administrativo/Judicial de IRRF - Evento
- **Sinônimos/variações:** número processo irrf, processo administrativo irrf, processo judicial irrf, identificação processo irrf, número do processo irrf, processo irrf, referência processo irrf, processo irrf judicial, processo irrf administrativo, número processo imposto retido

### NRPROCESSOSALMATERN
- **Descrição:** Número do Processo Administrativo/Judicial Salário Maternidade - Evento
- **Sinônimos/variações:** número processo salário maternidade, processo administrativo salário maternidade, processo judicial salário maternidade, identificação processo salário maternidade, número do processo salário maternidade, processo salário maternidade, referência processo salário maternidade, processo salário maternidade judicial, processo salário maternidade administrativo, número processo benefício maternidade

### NRPROCESSOSIND
- **Descrição:** Número do Processo Administrativo/Judicial Sindical- Evento
- **Sinônimos/variações:** número processo sindical, processo administrativo sindical, processo judicial sindical, identificação processo sindical, número do processo sindical, processo sindical, referência processo sindical, processo sindical judicial, processo sindical administrativo, número processo contribuição sindical

### ORDEMCALCULO
- **Descrição:** Ordem cálculo dentro de uma prioridade - Evento
- **Sinônimos/variações:** ordem de cálculo, prioridade cálculo, sequência cálculo, posição cálculo, ordem processamento, prioridade processamento, sequência processamento, posição processamento, ordem execução cálculo, prioridade execução

### PAGOBRIGATORIO
- **Descrição:** Evento de Provento/Desconto Obrigatório
- **Sinônimos/variações:** pagamento obrigatório, provento obrigatório, desconto obrigatório, evento obrigatório, pagamento fixo, desconto fixo, valor obrigatório, evento de pagamento obrigatório, evento de desconto obrigatório, pagamento compulsório, desconto compulsório, evento obrigatório de provento, evento obrigatório de desconto

### PERCALCRATEIO
- **Descrição:** Período de cálculo do rateio de Eventos
- **Sinônimos/variações:** período cálculo rateio, período de rateio, intervalo cálculo rateio, tempo cálculo rateio, período para rateio, período cálculo eventos, período cálculo proporcional, período cálculo divisão, período cálculo distribuição, período cálculo parcelamento, período cálculo fracionado, período cálculo rateio eventos

### PORCINCID
- **Descrição:** Porcentagem de Incidência - Evento
- **Sinônimos/variações:** porcentagem de incidência, percentual de incidência, taxa de incidência, percentual evento, porcentagem evento, percentual de cálculo, percentual aplicado, percentual de base, porcentagem aplicada, percentual de incidência do evento, taxa percentual do evento

### PRIORIDADE
- **Descrição:** Prioridade do Evento - Evento
- **Sinônimos/variações:** prioridade do evento, ordem de prioridade, nível de prioridade, classificação de prioridade, importância do evento, precedência do evento, ordem de execução, prioridade para cálculo, prioridade na execução, prioridade de processamento, nível de execução

### PROPORCADMISSAO
- **Descrição:** Proporcionalizar de Acordo com a Admissão - Evento
- **Sinônimos/variações:** proporcional admissão, proporcionalizar pela admissão, proporcional conforme admissão, proporcionalidade admissão, rateio por admissão, proporcionalidade data admissão, proporcional admissão funcionário, proporcionalidade início contrato, proporcionalidade contratação, proporcionalidade data contratação

### PROPORCDEMISSAO
- **Descrição:** Proporcionalizar de acordo com demissão - Evento
- **Sinônimos/variações:** proporcional demissão, proporcionalizar pela demissão, proporcional conforme demissão, proporcionalidade demissão, rateio por demissão, proporcionalidade data demissão, proporcional demissão funcionário, proporcionalidade término contrato, proporcionalidade desligamento, proporcionalidade data desligamento

### PROPORCFERIAS
- **Descrição:** Proporcionalizar de Acordo com as Férias - Evento
- **Sinônimos/variações:** proporcional férias, proporcionalizar pelas férias, proporcional conforme férias, proporcionalidade férias, rateio por férias, proporcionalidade período férias, proporcional férias funcionário, proporcionalidade afastamento férias, proporcionalidade gozo férias, proporcionalidade licença férias

### PROPORCLICENCA
- **Descrição:** Proporcionalizar de Acordo com a Licença - Evento
- **Sinônimos/variações:** proporcional licença, proporcionalizar pela licença, proporcional conforme licença, proporcionalidade licença, rateio por licença, proporcionalidade período licença, proporcional licença funcionário, proporcionalidade afastamento, proporcionalidade licença médica, proporcionalidade afastamento licença

### PROPPORTOMADOR
- **Descrição:** Segue Rateio de Tomador de Serviço - Evento
- **Sinônimos/variações:** rateio tomador serviço, segue rateio tomador, rateio por tomador, rateio tomador de serviço, proporcional tomador, rateio conforme tomador, rateio tomador evento, rateio serviço tomador, rateio tomador contrato, rateio tomador funcionário

### PROVDESCBASE
- **Descrição:** Tipo do Evento - Provento/Desconto/Base de Cálculo
- **Sinônimos/variações:** tipo do evento, tipo provento, tipo desconto, base de cálculo, categoria do evento, classificação do evento, tipo cálculo, tipo provento/desconto, tipo base cálculo, tipo evento provento, tipo evento desconto

### QUADROREM
- **Descrição:** Remunerações Quadro de Pessoal - Evento
- **Sinônimos/variações:** remunerações quadro pessoal, quadro de remuneração, remuneração quadro, remuneração quadro de pessoal, remuneração equipe, remuneração grupo pessoal, quadro de pessoal remuneração, remuneração funcionários, remuneração quadro funcional, remuneração quadro empregados

### RECCREATEDBY
- **Descrição:** Usuário criador do registro - Evento
- **Sinônimos/variações:** usuário criador, criador do registro, responsável criação, usuário que criou, autor criação, quem criou registro, usuário inclusão, criador do evento, usuário responsável criação, autor do registro

### RECCREATEDON
- **Descrição:** Data de criação do registro - Evento
- **Sinônimos/variações:** data criação, data do registro, data inclusão, data criação registro, data criação evento, data cadastro, data de criação, data do cadastro, data inclusão registro, data registro

### RECMODIFIEDBY
- **Descrição:** Autor da última modificação no registro - Evento
- **Sinônimos/variações:** último modificador, autor última modificação, usuário que modificou, responsável modificação, quem alterou registro, usuário alteração, autor modificação, último usuário modificação, modificador do registro, responsável alteração

### RECMODIFIEDON
- **Descrição:** Data da última modificação no registro - Evento
- **Sinônimos/variações:** data última modificação, data modificação, data alteração, data última alteração, data modificação registro, data alteração registro, data atualização, data última atualização, data modificação evento, data alteração evento

### RENDNAOTRIBACORDOINTERNAC
- **Descrição:** Rendimento não tributável em função de acordos internacionais de bitributação - Evento
- **Sinônimos/variações:** rendimento não tributável, rendimento isento, rendimento acordo internacional, rendimento sem tributação, rendimento acordo bitributação, rendimento não tributado, rendimento acordo internacional bitributação, rendimento isento acordo internacional, rendimento sem imposto, rendimento acordo tributação internacional

### SEGUERATEIOMOVENSINO
- **Descrição:** Segue rateio do movimento de ensino - Evento
- **Sinônimos/variações:** segue rateio movimento ensino, rateio movimento ensino, rateio ensino, rateio movimento educacional, rateio evento ensino, rateio conforme movimento ensino, rateio movimento escolar, rateio movimento formação, rateio movimento acadêmico, rateio evento educacional

### SEGUERATEIOMOVENSINOCONTAB
- **Descrição:** Segue rateio movimento de ensino da contabilização - Evento
- **Sinônimos/variações:** segue rateio movimento ensino contabilização, rateio movimento ensino contábil, rateio ensino contabilização, rateio movimento educacional contábil, rateio evento ensino contábil, rateio movimento escolar contábil, rateio movimento acadêmico contábil, rateio contabilização ensino, rateio contabilização educacional, rateio contábil movimento ensino

### SEGUERATEIOMOVTEMPCONTAB
- **Descrição:** Segue rateio movimento temporário na contabilização - Evento
- **Sinônimos/variações:** segue rateio movimento temporário contabilização, rateio movimento temporário contábil, rateio temporário contabilização, rateio evento temporário contábil, rateio movimento temporário, rateio contabilização temporária, rateio contábil movimento temporário, rateio evento temporário, rateio contabilização temporária evento, rateio temporário evento

### SEGUERATEIOSALCMP
- **Descrição:** Segue rateio de salário composto - Evento
- **Sinônimos/variações:** segue rateio salário composto, rateio salário composto, rateio salário, rateio composto, rateio salário combinado, rateio salário múltiplo, rateio salário complexo, rateio salário composto evento, rateio salário composto cálculo, rateio salário composto proporcional

### TEMINTCONTCC
- **Descrição:** Existe Integração Contábil para Conta Crédito - Evento
- **Sinônimos/variações:** integração contábil conta crédito, integração conta crédito, integração contábil crédito, integração conta contábil crédito, integração contábil conta de crédito, integração contábil crédito evento, integração contábil crédito conta, integração contábil crédito funcionário, integração contábil crédito financeiro, integração contábil crédito lançamento

### TEMINTCONTCD
- **Descrição:** Existe Integração Contábil para Conta Dédito - Evento
- **Sinônimos/variações:** integração contábil conta débito, integração conta débito, integração contábil débito, integração conta contábil débito, integração contábil conta de débito, integração contábil débito evento, integração contábil débito conta, integração contábil débito funcionário, integração contábil débito financeiro, integração contábil débito lançamento

### TEMINTCONTGC
- **Descrição:** Existe Integração Contábil para Conta Gerenial de Crédito - Evento
- **Sinônimos/variações:** integração contábil conta gerencial crédito, integração gerencial crédito, integração contábil gerencial crédito, integração conta gerencial crédito, integração gerencial conta crédito, integração contábil crédito gerencial, integração gerencial crédito evento, integração gerencial crédito conta, integração gerencial crédito funcionário, integração gerencial crédito financeiro

### TEMINTCONTGD
- **Descrição:** Existe Integração Contábil para Conta Gerencial de Dédito - Evento
- **Sinônimos/variações:** integração contábil conta gerencial débito, integração gerencial débito, integração contábil gerencial débito, integração conta gerencial débito, integração gerencial conta débito, integração contábil débito gerencial, integração gerencial débito evento, integração gerencial débito conta, integração gerencial débito funcionário, integração gerencial débito financeiro

### TEMINTFUNCCC
- **Descrição:** Existe Integração de Funcionário para Conta de Crédito - Evento
- **Sinônimos/variações:** integração funcionário conta crédito, integração funcionário crédito, integração contábil funcionário crédito, integração funcionário conta contábil crédito, integração funcionário crédito evento, integração funcionário crédito conta, integração funcionário crédito financeiro, integração funcionário crédito lançamento, integração funcionário crédito registro, integração funcionário crédito cálculo

### TEMINTFUNCCD
- **Descrição:** Existe Integração de Funcionário para Conta de Dédito - Evento
- **Sinônimos/variações:** integração funcionário conta débito, integração funcionário débito, integração contábil funcionário débito, integração funcionário conta contábil débito, integração funcionário débito evento, integração funcionário débito conta, integração funcionário débito financeiro, integração funcionário débito lançamento, integração funcionário débito registro, integração funcionário débito cálculo

### TEMINTFUNCGC
- **Descrição:** Existe Integração Gerencial de Funcionários para Conta de Crédito - Evento
- **Sinônimos/variações:** integração gerencial funcionário conta crédito, integração gerencial funcionário crédito, integração contábil gerencial funcionário crédito, integração gerencial funcionário conta contábil crédito, integração gerencial funcionário crédito evento, integração gerencial funcionário crédito conta, integração gerencial funcionário crédito financeiro, integração gerencial funcionário crédito lançamento, integração gerencial funcionário crédito registro, integração gerencial funcionário crédito cálculo

### TEMINTFUNCGD
- **Descrição:** Existe Integração Gerencial de Funcionários para Conta de Dédito - Evento
- **Sinônimos/variações:** integração gerencial funcionário conta débito, integração gerencial funcionário débito, integração contábil gerencial funcionário débito, integração gerencial funcionário conta contábil débito, integração gerencial funcionário débito evento, integração gerencial funcionário débito conta, integração gerencial funcionário débito financeiro, integração gerencial funcionário débito lançamento, integração gerencial funcionário débito registro, integração gerencial funcionário débito cálculo

### TIPOPREVIDENCIACOMPLEMENTAR
- **Descrição:** Tipo de Previdência Complementar - Evento
- **Sinônimos/variações:** tipo previdência complementar, categoria previdência complementar, tipo plano previdenciário, tipo previdência privada, tipo previdência adicional, tipo previdência extra, tipo previdência complementar evento, tipo previdência complementar funcionário, tipo previdência complementar plano, tipo previdência complementar benefício

### TOTALIZADOR
- **Descrição:** Totalizador do Evento
- **Sinônimos/variações:** totalizador do evento, totalizador, soma do evento, total do evento, valor totalizador, totalizador cálculo, totalizador provento, totalizador desconto, totalizador base, totalizador cálculo evento

### TPPROCESSOFGTS
- **Descrição:** Código Correspondente ao Tipo de Processo de FGTS (A - Administrativo, J - Judicial) - Evento
- **Sinônimos/variações:** tipo de processo fgts, processo fgts, código processo fgts, classificação fgts, categoria processo fgts, tipo ação fgts, processo administrativo fgts, processo judicial fgts, modalidade processo fgts, natureza processo fgts, qual tipo de processo fgts, tipo de ação fgts, processo fgts administrativo ou judicial, tipo processo fgts evento, código tipo processo fgts

### TPPROCESSOINSS
- **Descrição:** Código Correspondente ao Tipo de Processo de INSS (A - Administrativo, J - Judicial) - Evento
- **Sinônimos/variações:** tipo de processo inss, processo inss, código processo inss, classificação inss, categoria processo inss, tipo ação inss, processo administrativo inss, processo judicial inss, modalidade processo inss, natureza processo inss, qual tipo de processo inss, tipo de ação inss, processo inss administrativo ou judicial, tipo processo inss evento, código tipo processo inss

### TPPROCESSOIRRF
- **Descrição:** Código Correspondente ao Tipo de Processo de IRRF (A - Administrativo, J - Judicial) - Evento
- **Sinônimos/variações:** tipo de processo irrf, processo irrf, código processo irrf, classificação irrf, categoria processo irrf, tipo ação irrf, processo administrativo irrf, processo judicial irrf, modalidade processo irrf, natureza processo irrf, qual tipo de processo irrf, tipo de ação irrf, processo irrf administrativo ou judicial, tipo processo irrf evento, código tipo processo irrf

### TPPROCESSOSALMATERN
- **Descrição:** Código Correspondente ao Tipo de Processo de Salário Maternidade (A - Administrativo, J - Judicial) - Evento
- **Sinônimos/variações:** tipo de processo salário maternidade, processo salário maternidade, código processo salário maternidade, classificação salário maternidade, categoria processo salário maternidade, tipo ação salário maternidade, processo administrativo salário maternidade, processo judicial salário maternidade, modalidade processo salário maternidade, natureza processo salário maternidade, qual tipo de processo salário maternidade, tipo de ação salário maternidade, processo salário maternidade administrativo ou judicial, tipo processo salário maternidade evento, código tipo processo salário maternidade

### TPPROCESSOSIND
- **Descrição:** Código Correspondente ao Tipo de Processo Sindical (A - Administrativo, J - Judicial) - Evento
- **Sinônimos/variações:** tipo de processo sindical, processo sindical, código processo sindical, classificação sindical, categoria processo sindical, tipo ação sindical, processo administrativo sindical, processo judicial sindical, modalidade processo sindical, natureza processo sindical, qual tipo de processo sindical, tipo de ação sindical, processo sindical administrativo ou judicial, tipo processo sindical evento, código tipo processo sindical

### VALHORDIAREF
- **Descrição:** Valor/Hora/Dia/Referência - Evento
- **Sinônimos/variações:** valor hora, valor dia, valor referência, valor por hora, valor por dia, valor base diária, valor base horária, valor de referência, quanto vale por hora, quanto vale por dia, valor hora evento, valor dia evento, valor referência evento, valor hora/dia, valor hora ou dia

