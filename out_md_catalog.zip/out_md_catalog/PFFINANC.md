# PFFINANC

**Descrição:** Ficha Financeira (Envelope de Pagamento) do Funcionário

## Colunas

### ALTERADOMANUAL
- **Descrição:** Evento alterado manualmente - Ficha Financeira (Envelope de Pagamento) do Funcionário
- **Sinônimos/variações:** alterado manualmente, modificação manual, evento alterado manualmente, alteração manual do evento, mudança manual, edição manual, registro alterado manualmente, alteração feita manualmente, evento modificado manualmente, alteração manual no envelope, alteração manual na ficha financeira

### ANOCOMP
- **Descrição:** Ano de Competência - Ficha Financeira (Envelope de Pagamento) do Funcionário
- **Sinônimos/variações:** ano de competência, ano referência, ano do pagamento, ano do evento, ano contabilizado, ano base, ano do cálculo, ano da competência, ano do lançamento, ano do registro, ano para competência

### CHAPA
- **Descrição:** Chapa do Funcionário - Ficha Financeira (Envelope de Pagamento) do Funcionário
- **Sinônimos/variações:** chapa do funcionário, número da chapa, identificação do funcionário, código do funcionário, registro do funcionário, matrícula do funcionário, número de identificação, código chapa, identificador do colaborador, matrícula, registro do colaborador

### CODCOLIGADA
- **Descrição:** Código Identificador da Coligada - Ficha Financeira (Envelope de Pagamento) do Funcionário
- **Sinônimos/variações:** código da coligada, identificador da coligada, código da empresa, empresa coligada, código do grupo, identificação da coligada, código da filial, código da unidade, empresa associada, código do estabelecimento, identificador da empresa

### CODEVENTO
- **Descrição:** Código do Evento - Ficha Financeira (Envelope de Pagamento) do Funcionário
- **Sinônimos/variações:** código do evento, identificador do evento, código do lançamento, código do pagamento, código do provento, código do desconto, código do cálculo, código do item financeiro, código do registro, identificação do evento, código do movimento

### DISSIDIO
- **Descrição:** Indica se a verba foi lançada por um dissidio - Ficha Financeira (Envelope de Pagamento) do Funcionário
- **Sinônimos/variações:** dissídio, verba por dissídio, lançamento por dissídio, evento de dissídio, verba dissídio, indicador de dissídio, evento lançado por dissídio, verba lançada por dissídio, dissídio aplicado, evento com dissídio, verba dissídio aplicada

### DISSIDIOALTMANUAL
- **Descrição:** Campo para controle de Dissídio - Ficha Financeira (Envelope de Pagamento) do Funcionário
- **Sinônimos/variações:** controle de dissídio, dissídio alterado manualmente, controle manual de dissídio, dissídio modificado manualmente, controle manual do dissídio, alteração manual do dissídio, controle de dissídio manual, dissídio ajustado manualmente, controle manual para dissídio, dissídio com alteração manual, controle manual para verba de dissídio

### DTPAGTO
- **Descrição:** Data de Pagamento - Ficha Financeira (Envelope de Pagamento) do Funcionário
- **Sinônimos/variações:** data de pagamento, data do pagamento, dia do pagamento, quando foi pago, data do repasse, data do crédito, data do depósito, data de quitação, data do recebimento, data do pagamento efetuado, data do pagamento realizado

### HORA
- **Descrição:** Quantidade de Horas - Ficha Financeira (Envelope de Pagamento) do Funcionário
- **Sinônimos/variações:** quantidade de horas, horas trabalhadas, total de horas, número de horas, horas contabilizadas, horas registradas, horas lançadas, horas do período, horas no evento, horas para cálculo, horas consideradas

### MESCOMP
- **Descrição:** Mês de Competência - Ficha Financeira (Envelope de Pagamento) do Funcionário
- **Sinônimos/variações:** mês de competência, mês referência, mês do pagamento, mês do evento, mês contabilizado, mês base, mês do cálculo, mês da competência, mês do lançamento, mês do registro, mês para competência

### NROPERIODO
- **Descrição:** Número do Período - Ficha Financeira (Envelope de Pagamento) do Funcionário
- **Sinônimos/variações:** número do período, período, período de pagamento, número do ciclo, código do período, identificador do período, período financeiro, período contabilizado, período do evento, número do intervalo, período de competência

### ORIGEMMOV
- **Descrição:** Origem do Movimento - Ficha Financeira (Envelope de Pagamento) do Funcionário
- **Sinônimos/variações:** origem do movimento, fonte do movimento, origem do lançamento, origem do evento, procedência do movimento, origem do registro, origem da movimentação, origem do pagamento, origem do crédito, origem do débito, origem do cálculo

### RECCREATEDBY
- **Descrição:** Usuário criador do registro - Ficha Financeira (Envelope de Pagamento) do Funcionário
- **Sinônimos/variações:** usuário criador, quem criou o registro, autor da criação, criador do registro, usuário que criou, responsável pela criação, quem registrou, usuário de criação, criador do lançamento, autor do registro, quem gerou o registro

### RECCREATEDON
- **Descrição:** Data de criação do registro - Ficha Financeira (Envelope de Pagamento) do Funcionário
- **Sinônimos/variações:** data de criação, quando foi criado, data do registro, data do lançamento, data de geração, data do cadastro, data do registro criado, data do evento criado, data do registro inicial, data do registro gerado, data do cadastro inicial

### RECMODIFIEDBY
- **Descrição:** Autor da última modificação no registro - Ficha Financeira (Envelope de Pagamento) do Funcionário
- **Sinônimos/variações:** último modificador, quem modificou por último, autor da última modificação, responsável pela última alteração, usuário que alterou, quem editou por último, modificador do registro, último editor, autor da modificação, quem atualizou o registro, usuário da última modificação

### RECMODIFIEDON
- **Descrição:** Data da última modificação no registro - Ficha Financeira (Envelope de Pagamento) do Funcionário
- **Sinônimos/variações:** data da última modificação, quando foi modificado, data da alteração, data da última edição, data da atualização, data da modificação do registro, data da última mudança, data da última revisão, data da última alteração, data da última atualização, data da última edição do registro

### REF
- **Descrição:** Referência do Evento - Ficha Financeira (Envelope de Pagamento) do Funcionário
- **Sinônimos/variações:** referência do evento, referência, referência financeira, referência do pagamento, referência do lançamento, referência do cálculo, referência do registro, referência do crédito, referência do débito, referência do movimento, referência do provento

### VALOR
- **Descrição:** Valor do Evento - Ficha Financeira (Envelope de Pagamento) do Funcionário
- **Sinônimos/variações:** valor do evento, valor, quantia do evento, valor pago, valor do pagamento, valor do lançamento, valor financeiro, valor creditado, valor debitado, valor calculado, valor registrado

### VALORORIGINAL
- **Descrição:** Valor Original - Ficha Financeira (Envelope de Pagamento) do Funcionário
- **Sinônimos/variações:** valor original, valor base, valor inicial, valor bruto, valor antes de ajustes, valor sem alterações, valor primário, valor de origem, valor sem descontos, valor sem modificações, valor original do evento

### VERBADIFERENCA
- **Descrição:** Indica se é uma verba relacionada a cálculo de diferença salarial - Ficha Financeira (Envelope de Pagamento) do Funcionário
- **Sinônimos/variações:** verba diferença salarial, verba de diferença, verba para cálculo de diferença, verba relacionada a diferença salarial, verba de ajuste salarial, verba para diferença de salário, verba para cálculo de ajuste, verba de diferença de pagamento, verba para diferença, verba de ajuste de salário

### VERBAFERIAS
- **Descrição:** Indica o recálculo do evento de férias - Ficha Financeira (Envelope de Pagamento) do Funcionário
- **Sinônimos/variações:** verba de férias, recalculo de férias, verba para férias, evento de férias, verba relacionada a férias, verba de recálculo de férias, verba férias, verba para pagamento de férias, verba de ajuste de férias, verba de férias recalculada, verba referente a férias

### VERBARESILICAO
- **Descrição:** Verba de resilição - Ficha Financeira (Envelope de Pagamento) do Funcionário
- **Sinônimos/variações:** verba de resilição, verba de rescisão, evento de resilição, verba para resilição, verba relacionada a resilição, verba de desligamento, verba de término de contrato, verba de rescisão contratual, verba para rescisão, verba de encerramento, verba de resilição contratual
